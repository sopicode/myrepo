var webpack = require('webpack');
const path = require("path");

module.exports = {
  "entry": {
    "main": [
      "./src\\polyfills.ts",
      "./src\\main.ts"
	  ]
  },
  "output": {
    "libraryTarget": 'umd',
	  "umdNamedDefine": true,
	  "globalObject": 'this'
  },
  "optimization":{
	  "runtimeChunk": false
  },
  "plugins" : [
    new webpack.ProvidePlugin({
      '$' : 'jquery',
      'jQuery' : 'jquery'
    })
  ]
};


