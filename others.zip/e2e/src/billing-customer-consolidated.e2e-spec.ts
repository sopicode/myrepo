import { AppPage } from './app.po';
import { browser } from 'protractor';
describe('To test customer & consolidated billing section', () => {
    let page: AppPage;

    beforeEach(() => {
        page = new AppPage();
    });

    it('should validate  the mandatory information- Customer & Consolidated Billing Page', async() => {
        page.navigateTo();
        browser.sleep(10000);
        page.goToSection(2);
        //Check the mandatory fields are filled with data
        expect(await page.getExpandableContainerText(0)).toEqual('MORGAN COUNTY BUILDING AUTHORITY');
        expect(await page.getExpandableContainerText(1)).toEqual('3588590010');
        expect(await page.getExpandableContainerText(4)).toEqual('GA');
        expect(await page.getExpandableContainerText(7)).toEqual('150 E WASHINGTON ST');
    });

    it('should validate the value for the jump menu- Customer & Consolidated Billing', async() => {
        page.navigateTo();
        browser.sleep(10000);
        page.goToSection(2);
        expect(await page.getJumpMenuText(0)).toEqual('Customer & Consolidated Billing');
    });

    it('should validate the value of - Is consolidated billing', async() => {
        page.navigateTo();
        browser.sleep(10000);
        page.goToSection(2);
        expect(await page.getRadioSelectedText(0)).toEqual('No');
    });

});
