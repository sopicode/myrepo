import { browser, by, element } from 'protractor';

export class AppPage {
  navigateTo() {
    return browser.get('/');
  }

  getParagraphText() {
    return element(by.css('app-root h1')).getText();
  }

  getRadioSelectedText(indx: number) {
    let radioGroup = element.all(by.css('mat-radio-group')).get(indx);
    let selectedRadioButton = radioGroup.element(by.css('.mat-radio-checked'));
    return selectedRadioButton.element(by.css('.mat-radio-label-content')).getText();
  }

  getJumpMenuText(indx: number) {
    let footerText = element(by.xpath('//billing-footer//button/span'));
    return footerText.getText();
  }

  getExpandableContainerText(indx: number) {
    let expandableContainerText = element.all(by.css('billing-expandable-container > div > textarea')).get(indx);
    return expandableContainerText.getText();
  }

  getMatChipText(indx: number){
    let chipText = element.all(by.css('mat-chip-list >div> mat-chip')).get(indx);
    return chipText.getText();
  }

  goToSection(indx: number) {
    let footerText = element(by.xpath('//billing-footer//button/span'));
    footerText.click();
    browser.sleep(1000);
    let footerSection : any;
    switch (indx) {
      case 1:
        footerSection = element(by.xpath('//*[@id="cdk-overlay-1"]/div/div/div[1]/button'));
        footerSection.click();
        browser.sleep(10000);
        break;
      case 2:
        footerSection = element(by.xpath('//*[@id="cdk-overlay-1"]/div/div/div[2]/button'));
        footerSection.click();
        browser.sleep(10000);
        break;
      case 3:
        footerSection = element(by.xpath('//*[@id="cdk-overlay-1"]/div/div/div[3]/button'));
        footerSection.click();
        browser.sleep(10000);
        break;
      case 4:
        footerSection = element(by.xpath('//*[@id="cdk-overlay-1"]/div/div/div[4]/button'));
        footerSection.click();
        browser.sleep(10000);
        break;
      case 5:
        footerSection = element(by.xpath('//*[@id="cdk-overlay-1"]/div/div/div[5]/button'));
        footerSection.click();
        browser.sleep(10000);
        break;
      case 6:
        footerSection = element(by.xpath('//*[@id="cdk-overlay-1"]/div/div/div[6]/button'));
        footerSection.click();
        browser.sleep(10000);
        break;
      case 7:
        footerSection = element(by.xpath('//*[@id="cdk-overlay-1"]/div/div/div[7]/button'));
        footerSection.click();
        browser.sleep(10000);
        break;
      case 8:
        footerSection = element(by.xpath('//*[@id="cdk-overlay-1"]/div/div/div[8]/button'));
        footerSection.click();
        browser.sleep(10000);
        break;
      case 9:
        footerSection = element(by.xpath('//*[@id="cdk-overlay-1"]/div/div/div[9]/button'));
        footerSection.click();
        browser.sleep(10000);
        break;
      case 10:
        footerSection = element(by.xpath('//*[@id="cdk-overlay-1"]/div/div/div[10]/button'));
        footerSection.click();
        browser.sleep(10000);
        break;
    }
  }
}
