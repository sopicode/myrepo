import { AppPage } from './app.po';
import { browser , element, by } from 'protractor';
describe('To test billing account section', () => {
    let page: AppPage;

    beforeEach(() => {
        page = new AppPage();
    });

    it('should validate the mandatory information of  account card- Billing Accounts', async() => {
        page.navigateTo();
        browser.sleep(10000);
        page.goToSection(4);
        //Check the mandatory fields are available in a billing card
        var billingKey = element(by.id('mat-input-0'));
        expect(await billingKey.getAttribute('placeholder')).toEqual('Proposed Billing Key');
        var accountShortName = element(by.id('mat-input-1'));
        expect(await accountShortName.getAttribute('placeholder')).toEqual('Billing Account Short Name');
        var accountLongName = element(by.id('mat-input-2'));
        expect(await accountLongName.getAttribute('placeholder')).toEqual('Billing Account Long Name');
        expect(await element(by.xpath('//div[contains(text(), "BNYM Legal Entity")]'))).toBeTruthy();
        
        
    });

    it('should validate the  value for the jump menu- Billing Accounts', async() => {
        page.navigateTo();
        browser.sleep(10000);
        page.goToSection(4);
        expect(await page.getJumpMenuText(0)).toEqual('Billing Accounts');
    });

    it('should validate the text displayed - Billing Accounts', async() => {
        page.navigateTo();
        browser.sleep(10000);
        page.goToSection(4);
        expect(await element(by.xpath('//span[contains(text(), "Add Billing Account(s) for this request here.")]'))).toBeTruthy();
        expect(await element(by.xpath('//span[contains(text(), "Count :2")]'))).toBeTruthy();
    });

    it('should validate the button text displayed - Billing Accounts', async() => {
        page.navigateTo();
        browser.sleep(10000);
        page.goToSection(4);
        expect(await element(by.xpath('//span[contains(text(), "View/Update Details")]'))).toBeTruthy();
        expect(await element(by.xpath('//span[contains(text(), "Duplicate")]'))).toBeTruthy();
        expect(await element(by.xpath('//span[contains(text(), "DELETE")]'))).toBeTruthy();
    });

});
