import { AppPage } from './app.po';
import { browser , element, by } from 'protractor';
describe('To test summary section', () => {
    let page: AppPage;

    beforeEach(() => {
        page = new AppPage();
    });

    it('should validate the display sections- Summary', async() => {
        page.navigateTo();
        browser.sleep(10000);
        page.goToSection(10);
        expect(await element(by.xpath('//span[contains(text(), "Billing Request Details")]'))).toBeTruthy();
        expect(await element(by.xpath('//span[contains(text(), "Customer & Consolidated Billing")]'))).toBeTruthy();
        expect(await element(by.xpath('//span[contains(text(), "Contact Information")]'))).toBeTruthy();
        expect(await element(by.xpath('//span[contains(text(), "Billing Accounts")]'))).toBeTruthy();
        expect(await element(by.xpath('//span[contains(text(), "Additional Billing Details")]'))).toBeTruthy();
        expect(await element(by.xpath('//span[contains(text(), "Billing Team")]'))).toBeTruthy();
        expect(await element(by.xpath('//span[contains(text(), "Billing Documents")]'))).toBeTruthy();
        expect(await element(by.xpath('//span[contains(text(), "Special Billing Instructions ")]'))).toBeTruthy();
        expect(await element(by.xpath('//span[contains(text(), "Data Mismatch Details")]'))).toBeTruthy();
    });

    it('should validate the display of sub sections- Summary', async() => {
        page.navigateTo();
        browser.sleep(10000);
        page.goToSection(10);
        expect(await element(by.xpath('//span[contains(text(), "Customer")]'))).toBeTruthy();
        expect(await element(by.xpath('//span[contains(text(), "Consolidated Billing")]'))).toBeTruthy();
        expect(await element(by.xpath('//div[contains(text(), "Attached Documents")]'))).toBeTruthy();

    });

    it('should validate the display of buttons- Summary', async() => {
        page.navigateTo();
        browser.sleep(10000);
        page.goToSection(10);
        expect(await element(by.xpath('//span[contains(text(), "Submit")]'))).toBeTruthy();
        expect(await element(by.xpath('//span[contains(text(), "Back")]'))).toBeTruthy();
    });

    it('should validate the  value for the jump menu- Summary', async() => {
        page.navigateTo();
        browser.sleep(10000);
        page.goToSection(10);
        expect(await page.getJumpMenuText(0)).toEqual('Summary');
    });
});
