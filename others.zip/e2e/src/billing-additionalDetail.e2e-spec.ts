import { AppPage } from './app.po';
import { browser , element, by } from 'protractor';
describe('To test additional billing details section', () => {
    let page: AppPage;

    beforeEach(() => {
        page = new AppPage();
    });

    it('should validate the section- Additional Billing Details', async() => {
        page.navigateTo();
        browser.sleep(10000);
        page.goToSection(5);
        expect(await element(by.xpath('//div[contains(text(), "Additional Billing Details do not apply.")]'))).toBeTruthy();
    });

    it('should validate the  value for the jump menu- Additional Billing Details', async() => {
        page.navigateTo();
        browser.sleep(10000);
        page.goToSection(5);
        expect(await page.getJumpMenuText(0)).toEqual('Additional Billing Details');
    });
});
