import { AppPage } from './app.po';
import { browser , element, by } from 'protractor';
describe('To test billing documents section', () => {
    let page: AppPage;

    beforeEach(() => {
        page = new AppPage();
    });

    it('should validate the display items- Billing Documents', async() => {
        page.navigateTo();
        browser.sleep(10000);
        page.goToSection(7);
        expect(await element(by.xpath('//div[contains(text(), "Please attach a Waiver and/or Fee Schedule.")]'))).toBeTruthy();
        expect(await element(by.xpath('//div[contains(text(), "Drag and Drop here or")]'))).toBeTruthy();
        expect(await element(by.xpath('//span[contains(text(), "DOWNLOAD")]'))).toBeTruthy();
        expect(await element(by.xpath('//span[contains(text(), "DELETE")]'))).toBeTruthy();
    });

    it('should validate the  value for the jump menu- Billing Documents', async() => {
        page.navigateTo();
        browser.sleep(10000);
        page.goToSection(7);
        expect(await page.getJumpMenuText(0)).toEqual('Documents');
    });
});
