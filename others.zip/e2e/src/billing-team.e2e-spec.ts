import { AppPage } from './app.po';
import { browser , element, by } from 'protractor';
describe('To test billing team section', () => {
    let page: AppPage;

    beforeEach(() => {
        page = new AppPage();
    });

    it('should validate the display items- Billing Team', async() => {
        page.navigateTo();
        browser.sleep(10000);
        page.goToSection(6);
        expect(await element(by.xpath('//billing-select[contains(@ng-reflect-placeholder,"Team Name")]'))).toBeTruthy();
        expect(await element(by.xpath('//div[contains(text(), "Admin")]'))).toBeTruthy();
        expect(await element(by.xpath('//div[contains(text(), "Manager")]'))).toBeTruthy();
    });

    it('should validate the  value for the jump menu- Billing Team', async() => {
        page.navigateTo();
        browser.sleep(10000);
        page.goToSection(6);
        expect(await page.getJumpMenuText(0)).toEqual('Billing Team');
    });
});
