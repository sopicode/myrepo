import { AppPage } from './app.po';
import { browser } from 'protractor';
describe('To test billing request details section', () => {
    let page: AppPage;

    beforeEach(() => {
        page = new AppPage();
    });

    it('should validate the value for the mandatory question- Is billing Required', async() => {
        page.navigateTo();
        browser.sleep(10000);
        expect(await page.getRadioSelectedText(0)).toEqual('No');
    });

    it('should validate the value for the mandatory question- Type of Billing Key', async() => {
        page.navigateTo();
        browser.sleep(10000);
        expect(await page.getRadioSelectedText(1)).toEqual('New');
    });

    it('should validate the value for the jump menu- Billing Request Details', async() => {
        page.navigateTo();
        browser.sleep(10000);
        expect(await page.getJumpMenuText(0)).toEqual('Billing Request Details');
    });

});
