import { AppPage } from './app.po';
import { browser } from 'protractor';

describe('workspace-project App', () => {
  let page: AppPage;

  beforeEach(() => {
    page = new AppPage();
  });

  it('should select new as billing key by default', () => {
    page.navigateTo();
    browser.sleep(10000);
    expect(page.getRadioSelectedText(1)).toEqual('New');
  });
});
