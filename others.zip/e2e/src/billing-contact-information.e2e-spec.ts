import { AppPage } from './app.po';
import { browser,element, by } from 'protractor';
describe('To test billing contact section', () => {
    let page: AppPage;

    beforeEach(() => {
        page = new AppPage();
    });

    it('should validate the mandatory information of deal party section- Billing Contact', async() => {
        page.navigateTo();
        browser.sleep(10000);
        page.goToSection(3);
        //Check the mandatory fields are filled with data for selected deal party
        expect(await page.getExpandableContainerText(0)).toEqual('MORGAN COUNTY BUILDING AUTHORITY');
        expect(await page.getMatChipText(0)).toEqual('Customer');
        expect(await element.all(by.cssContainingText('.form-field-label', 'Number of Contacts'))).toBeTruthy();
    });

    it('should validate the mandatory information of customer section- Billing Contact', async() => {
        page.navigateTo();
        browser.sleep(10000);
        page.goToSection(3);
        //Check the mandatory fields are filled with data for selected customer
        expect(await page.getExpandableContainerText(1)).toEqual('MORGAN COUNTY BUILDING AUTHORITY');
        expect(await page.getExpandableContainerText(2)).toEqual('Account Executive');
        expect(await page.getExpandableContainerText(4)).toEqual('shiny');
        expect(await page.getExpandableContainerText(12)).toEqual('dasdas');
        expect(await page.getExpandableContainerText(15)).toEqual('dasdasd');
    });

    it('should validate the  value for the jump menu- Billing Contact', async() => {
        page.navigateTo();
        browser.sleep(10000);
        page.goToSection(3);
        expect(await page.getJumpMenuText(0)).toEqual('Billing Contact');
    });

    it('should validate the section display - Billing Contact', async() => {
        page.navigateTo();
        browser.sleep(10000);
        page.goToSection(3);
        expect(await element(by.xpath('//h4[contains(text(), "Deal Party Information")]'))).toBeTruthy();
        expect(await element(by.xpath('//span[contains(text(), "Contact Information")]'))).toBeTruthy();
        expect(await element(by.xpath('//span[contains(text(), "Address Information")]'))).toBeTruthy();
        expect(await element(by.xpath('//span[contains(text(), "Additional Information")]'))).toBeTruthy();
    });

    it('should validate the button text displayed - Billing Contact', async() => {
        page.navigateTo();
        browser.sleep(10000);
        page.goToSection(3);
        expect(await element(by.xpath('//span[contains(text(), "Change Contact")]'))).toBeTruthy();
        expect(await element(by.xpath('//span[contains(text(), "Edit")]'))).toBeTruthy();
    });

});
