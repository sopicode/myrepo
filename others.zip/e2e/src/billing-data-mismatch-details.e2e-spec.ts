import { AppPage } from './app.po';
import { browser , element, by } from 'protractor';
describe('To test data mismtach details section', () => {
    let page: AppPage;

    beforeEach(() => {
        page = new AppPage();
    });

    it('should validate the display items- Data Mismatch Details', async() => {
        page.navigateTo();
        browser.sleep(10000);
        page.goToSection(9);
        expect(await element(by.xpath('//div[contains(text(), "Data Mismatch Details do not apply.")]'))).toBeTruthy();
    });

    it('should validate the  value for the jump menu- Data Mismatch Details', async() => {
        page.navigateTo();
        browser.sleep(10000);
        page.goToSection(9);
        expect(await page.getJumpMenuText(0)).toEqual('Data Mismatch Details');
    });
});
