import { AppPage } from './app.po';
import { browser , element, by } from 'protractor';
describe('To test billing special instructions section', () => {
    let page: AppPage;

    beforeEach(() => {
        page = new AppPage();
    });

    it('should validate the display items- Special Billing Instructions', async() => {
        page.navigateTo();
        browser.sleep(10000);
        page.goToSection(8);
        expect(await element(by.xpath('//textarea[contains(@placeholder,"Special Billing Instructions")]'))).toBeTruthy();
    });

    it('should validate the  value for the jump menu- Special Billing Instructions', async() => {
        page.navigateTo();
        browser.sleep(10000);
        page.goToSection(8);
        expect(await page.getJumpMenuText(0)).toEqual('Special Billing Instructions');
    });
});
