package com.bnymellon.ctt.ui.model;

import java.io.Serializable;

public class User implements Serializable {

	/**
		 * 
		 */
	private static final long serialVersionUID = 1906594725780991470L;

	private String city;

	private String state;

	private String corporateTitle;

	private String country;

	private String department;

	private String displayName;

	private String mobileNumber;

	private String jobTitle;

	private String comitId;

	private String managerName;

	private String managerComitId;

	private String managerEmailAddress;

	private String managerPhone;

	private String preferredFirstName;

	private String preferredLastName;

	private String firstName;

	private String lastName;

	private String phone;

	private String persona;

	private String personaCode;

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCorporateTitle() {
		return corporateTitle;
	}

	public void setCorporateTitle(String corporateTitle) {
		this.corporateTitle = corporateTitle;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getJobTitle() {
		return jobTitle;
	}

	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}

	public String getComitId() {
		return comitId;
	}

	public void setComitId(String comitId) {
		this.comitId = comitId;
	}

	public String getManagerName() {
		return managerName;
	}

	public void setManagerName(String managerName) {
		this.managerName = managerName;
	}

	public String getManagerComitId() {
		return managerComitId;
	}

	public void setManagerComitId(String managerComitId) {
		this.managerComitId = managerComitId;
	}

	public String getManagerEmailAddress() {
		return managerEmailAddress;
	}

	public void setManagerEmailAddress(String managerEmailAddress) {
		this.managerEmailAddress = managerEmailAddress;
	}

	public String getManagerPhone() {
		return managerPhone;
	}

	public void setManagerPhone(String managerPhone) {
		this.managerPhone = managerPhone;
	}

	public String getPreferredFirstName() {
		return preferredFirstName;
	}

	public void setPreferredFirstName(String preferredFirstName) {
		this.preferredFirstName = preferredFirstName;
	}

	public String getPreferredLastName() {
		return preferredLastName;
	}

	public void setPreferredLastName(String preferredLastName) {
		this.preferredLastName = preferredLastName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getPersona() {
		return persona;
	}

	public void setPersona(String persona) {
		this.persona = persona;
	}

	public String getPersonaCode() {
		return personaCode;
	}

	public void setPersonaCode(String personaCode) {
		this.personaCode = personaCode;
	}

}
