package com.bnymellon.ctt.ui.client;

import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.loadbalancer.LoadBalancerClient;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;

import com.bnymellon.ctt.api.exception.APIException;

@Component
@ConfigurationProperties(prefix="profiles.service")
public class ProfilesClient {
	
	@Autowired
	private Environment environment;
	
	private String serviceId; 
	
	private String context;

	LoadBalancerClient loadBalancer;
	
	@Autowired
	HttpServletRequest request;
	
	@Autowired(required = false)
	public void setLoadBalancer(LoadBalancerClient loadBalancer) {
		this.loadBalancer = loadBalancer;
	}
	
	public void setHeaders(HttpHeaders headers) {
		Enumeration<String> e = request.getHeaderNames();
		while(e.hasMoreElements()) {
			String name = e.nextElement();
			headers.add(name, request.getHeader(name));
		}
	}
	
	public String getEndpoint() {
		ServiceInstance instance = loadBalancer.choose(getServiceId());
		if(instance ==null ) 
			throw new APIException("Profiles service not available");
		String url =String.format("http://%s:%s/%s", instance.getHost(), instance.getPort(),context);
		return url;
	}

	public String getContext() {
		return context;
	}

	public void setContext(String context) {
		this.context = context;
	}

	public String getServiceId() {
		return getAppEnv()+this.serviceId;
	}

	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}
	
	private String getAppEnv() {
		if(environment.containsProperty("BXP_APP_ENV")) {
			if(environment.getProperty("BXP_APP_ENV").equalsIgnoreCase("prod")) {
				return "";
			}
			return environment.getProperty("BXP_APP_ENV")+"-";
		}else {
			return "";
		}
	}

}
