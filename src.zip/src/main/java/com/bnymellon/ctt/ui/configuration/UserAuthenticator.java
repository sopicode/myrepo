package com.bnymellon.ctt.ui.configuration;

import java.util.ArrayList;
import java.util.Collection;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

import com.bnymellon.ctt.api.exception.APIException;
import com.bnymellon.ctt.api.security.authenticator.APIAuthenticator;
import com.bnymellon.ctt.api.security.authenticator.AuthenticationWithPrincipal;
import com.bnymellon.ctt.api.security.authorization.APIPrincipal;
import com.bnymellon.ctt.ui.model.User;
import com.bnymellon.ctt.ui.service.UserDetailService;

public class UserAuthenticator  implements APIAuthenticator {
	
	Logger logger = LoggerFactory.getLogger(UserAuthenticator.class);
	
	   @Autowired
		UserDetailService service;
	   
		@Override
		public Authentication hasAccess(APIPrincipal principal) {
			Authentication authentication;
			String comitId = principal.getName().toUpperCase();
			Collection<GrantedAuthority> c =	getAuthorities(comitId);
			authentication = new AuthenticationWithPrincipal(comitId,null,c);
			if(c.size() > 0) {
				authentication.setAuthenticated(true);
			}else{
				authentication.setAuthenticated(false);
			}
			return authentication;
		}
		
		private Collection<GrantedAuthority> getAuthorities(String comitId){
			Collection<GrantedAuthority> c = new ArrayList<GrantedAuthority>();
			try {
				User u = service.getUserPrivileges(comitId);
				if(u != null && u.getPersonaCode() !=null) {
					c.add(new  SimpleGrantedAuthority(u.getPersonaCode()));
				}
			}catch(AccessDeniedException | APIException e) {
				throw e;
			}catch(Exception e) {
				logger.error("Technical Exception",e);
				throw new APIException("Technical exception while retrieving User's privileges",e);
			}
			return c;
		}


}
