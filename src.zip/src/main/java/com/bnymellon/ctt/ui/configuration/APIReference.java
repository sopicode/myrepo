package com.bnymellon.ctt.ui.configuration;

public interface APIReference {

	final String BASE_URL = "";

	final String USER_PRIVILEGES = "/users/{comitId}/privileges";

	final String PERSONA = "/me";

}
