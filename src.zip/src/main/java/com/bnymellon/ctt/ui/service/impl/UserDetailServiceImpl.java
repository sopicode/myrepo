package com.bnymellon.ctt.ui.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;
import com.bnymellon.ctt.api.exception.APIException;
import com.bnymellon.ctt.api.model.ResponseWrapperNoPagination;
import com.bnymellon.ctt.ui.client.ProfilesClient;
import com.bnymellon.ctt.ui.configuration.APIReference;
import com.bnymellon.ctt.ui.model.User;
import com.bnymellon.ctt.ui.service.UserDetailService;

@Service
public class UserDetailServiceImpl implements UserDetailService{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(UserDetailServiceImpl.class);
	@Autowired
	ProfilesClient client;
	@Override
	public User getUserPrivileges(String comitId) {
		User u = null;
		RestTemplate template = new RestTemplate();
		UriComponentsBuilder builder = null;
		try {
			HttpHeaders headers = new HttpHeaders();
			client.setHeaders(headers);
			HttpEntity<String> entity = new HttpEntity<String>(headers);
			builder = UriComponentsBuilder.fromHttpUrl(client.getEndpoint()+APIReference.PERSONA);
			ResponseEntity<ResponseWrapperNoPagination<User>> response  = template.exchange(builder.build().toString(), HttpMethod.GET,entity,
					new ParameterizedTypeReference<ResponseWrapperNoPagination<User>>(){});
			u = response.getBody().getData();
		}catch(APIException e) {
			throw e;
		}catch(Exception e) {
			LOGGER.error("Technical Exception"+e);
			throw new APIException("Technical exception while retrieving User's privileges",e);
		}
		return u;
	}

}
