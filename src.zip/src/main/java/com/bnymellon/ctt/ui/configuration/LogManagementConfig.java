package com.bnymellon.ctt.ui.configuration;

import java.util.Arrays;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import com.bnymellon.ctt.api.exception.APIException;
import com.bnymellon.ctt.api.exception.NotFoundException;
import com.bnymellon.ctt.api.exception.ValidationException;

@Aspect
@Component
public class LogManagementConfig {

	private static final Logger LOGGER = LoggerFactory.getLogger(LogManagementConfig.class);

	@Pointcut("within(@org.springframework.web.bind.annotation.RestController *)")
	public void log() {
	};

	@Before(value = "log()")
	public void logBefore(JoinPoint joinPoint) {
		if (LOGGER.isDebugEnabled()) {
			Signature signature = joinPoint.getSignature();
			String methodName = signature.getName();
			String arguments = Arrays.toString(joinPoint.getArgs());
			String className = signature.getDeclaringTypeName();
			LOGGER.debug("Entering  class " + className + "in method " + methodName + " with arguments: " + arguments);
		}
	};

	@After(value = "log()")
	public void logAfter(JoinPoint joinPoint) {
		if (LOGGER.isDebugEnabled()) {
			LOGGER.debug("Exiting  class " + joinPoint.getSignature().getDeclaringTypeName() + " in method "
					+ joinPoint.getSignature().getName() + "");
		}
	};

	@AfterThrowing(value = "log()", throwing = "e")
	public void logException(JoinPoint joinPoint, Throwable e) {
		Signature signature = joinPoint.getSignature();
		String methodName = signature.getName();
		String arguments = Arrays.toString(joinPoint.getArgs());
		String className = signature.getDeclaringTypeName();
		LOGGER.error("Exception occured while executing in class " + className + " in method " + methodName
				+ " with arguments: " + arguments);
		if (e instanceof NotFoundException || e instanceof ValidationException) {
			LOGGER.error(e.getMessage());
		}
		if ((e instanceof APIException) && ((APIException) e).getException() != null) {
			e = ((APIException) e).getException();
			LOGGER.error(e.getMessage(), e);
		} else {
			if ((e instanceof APIException) && ((APIException) e).getObject() != null) {
				Exception exp = (Exception) ((APIException) e).getObject();
				LOGGER.error(exp.getMessage(), exp);
			} else {
				LOGGER.error(e.getMessage(), e);
			}
		}
	};

}
