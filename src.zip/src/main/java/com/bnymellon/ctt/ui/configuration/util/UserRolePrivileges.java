package com.bnymellon.ctt.ui.configuration.util;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Component;
import com.bnymellon.ctt.api.security.domain.SecurityPrincipal;

@Component
public class UserRolePrivileges {

	Map<String, String> privileges;

	public Map<String, String> getPrivileges(String comitId) {
		privileges = new HashMap<String, String>();
		Collection<? extends GrantedAuthority> authorities = SecurityPrincipal.getPrivileges();
		for (GrantedAuthority authority : authorities) {
			String role = authority.getAuthority();
			privileges.put(role, role);
		}
		return privileges;
	}

}
