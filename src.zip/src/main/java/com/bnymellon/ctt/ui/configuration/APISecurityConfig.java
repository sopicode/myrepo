package com.bnymellon.ctt.ui.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;

import com.bnymellon.ctt.api.security.authenticator.APIAuthenticator;
import com.bnymellon.ctt.api.security.config.SecurityConfig;


@Order(10)
@Configuration
public class APISecurityConfig extends SecurityConfig {
	
	@Override
	@Bean
	public APIAuthenticator apiAuthenticator() {
		return new UserAuthenticator();
	}

}
