package com.bnymellon.ctt.ui.service;

import com.bnymellon.ctt.ui.model.User;

public interface UserDetailService {
	
	User getUserPrivileges(String comitId);

}
