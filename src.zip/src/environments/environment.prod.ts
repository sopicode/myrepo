export const environment = {
  production: true,
  apiBaseUrl: 'https://trust.dev.bnymellon.net/'
};
