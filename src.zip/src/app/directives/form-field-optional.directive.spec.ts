import { FormFieldOptionalDirective } from './form-field-optional.directive';

describe('FormFieldOptionalDirective', () => {
  it('should create an instance', () => {
    //const directive = new FormFieldOptionalDirective();
   // expect(directive).toBeTruthy();
  });
});
