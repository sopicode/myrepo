import { BigNumberDirective } from './big-number.directive';

describe('BigNumberDirective', () => {
  it('should create an instance', () => {
    const directive = new BigNumberDirective();
    expect(directive).toBeTruthy();
  });
});
