import { Directive, Renderer, ElementRef, Input } from '@angular/core';

@Directive({
  selector: '[formFieldOptional]'
})
export class FormFieldOptionalDirective {

  @Input() optional: boolean;
  private _optionalDisplay: any;

  constructor(private _elRef: ElementRef, private _renderer: Renderer) { }

  ngOnChanges(): void {
    if (this.optional) {
      this._optionalDisplay = this._renderer.createElement(this._elRef.nativeElement.parentElement, 'span');
      this._renderer.setElementClass(this._optionalDisplay, 'optionalField', true);
      this._renderer.createText(this._optionalDisplay, '(optional)');
    } else {
      let elem = this._elRef.nativeElement.parentElement;
      let optionalElem = elem.querySelector('.optionalField');
      if (optionalElem) {
        elem.removeChild(optionalElem);
      }
    }
  }

}
