import { Directive, Optional, ElementRef, Input, HostListener } from '@angular/core';
import { NgControl } from '@angular/forms';
import { _ } from 'underscore';
declare var Inputmask;

@Directive({
  selector: '[inputMask]'
})
export class InputMaskDirective {

  @Input('inputMask')
  mask: string;

  @Input('inputMaskOptions')
  options: any;

  maskOptions: any

  constructor(private elementRef: ElementRef, @Optional() private control: NgControl) { }

  ngOnInit() {
    this.maskOptions = _.clone(this.options) || {};
    _.defaults(this.maskOptions, { showMaskOnHover: false });
    if (this.mask == 'currency') {
      this.maskOptions.rightAlign = _.has(this.maskOptions, 'rightAlign') ? this.maskOptions.rightAlign : false;
      this.maskOptions.allowMinus = _.has(this.maskOptions, 'allowMinus') ? this.maskOptions.allowMinus : false;
      this.maskOptions.autoUnmask = _.has(this.maskOptions, 'autoUnmask') ? this.maskOptions.autoUnmask : true;
    }
    let value = this.control.control.value;
    if (value) {
      Inputmask(this.mask, this.maskOptions).mask(this.elementRef.nativeElement);
    }
  }

  @HostListener('blur', ['$event']) onBlur(e: Event) {
    this.control.control.patchValue(this.elementRef.nativeElement.value);
  }

  @HostListener('focus', ['$event']) onFocus(e: Event) {
    Inputmask(this.mask, this.maskOptions).mask(this.elementRef.nativeElement);
  }

}
