import { Directive, ElementRef, Renderer, OnInit, HostListener } from '@angular/core';

@Directive({
  selector: '[dmCharCounter]'
})
export class DmCharCounterDirective {

  private _limit: number;
  private _countDisplay: any;

  constructor(private _elRef: ElementRef, private _renderer: Renderer) { }

  ngAfterViewInit(): void {
    this._limit = this._elRef.nativeElement.getAttribute('maxlength');
    this._countDisplay = this._renderer.createElement(this._elRef.nativeElement.parentElement.parentElement.parentElement.parentElement, 'div');
    this._renderer.setElementClass(this._elRef.nativeElement.parentElement.parentElement.parentElement,'char-count-wrapper',true);
    this._renderer.setElementClass(this._countDisplay,'char-count',true);
  }

  @HostListener('focus', ['$event']) onFocus(e: Event) {
    let count: any = this._elRef.nativeElement.value.length;
    this._countDisplay.innerText='';
    this._renderer.createText(this._countDisplay, (this._limit - count) + ' characters remaining');
  }

  @HostListener('keyup', ['$event']) onKeyup(e: Event) {
    let count: any = this._elRef.nativeElement.value.length;
    this._countDisplay.innerText='';
    this._renderer.createText(this._countDisplay, (this._limit - count) + ' characters remaining');
  }

  @HostListener('blur', ['$event']) onBlur(e: Event) {
    this._countDisplay.innerText='';
  }

}
