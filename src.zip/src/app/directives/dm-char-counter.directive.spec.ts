import { DmCharCounterDirective } from './dm-char-counter.directive';

describe('DmCharCounterDirective', () => {
  it('should create an instance', () => {
    //const directive = new DmCharCounterDirective();
    //expect(directive).toBeTruthy();
  });
});
