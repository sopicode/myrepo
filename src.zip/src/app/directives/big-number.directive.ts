import { Directive, Optional, ElementRef, Input, HostListener } from '@angular/core';
import { NgControl } from '@angular/forms';
import * as BigNumber from 'bignumber.js';

@Directive({
  selector: '[bigNumber]'
})
export class BigNumberDirective {

  @Input('config')
  config: any;
  private _defaultValueSet:boolean = false;
  private _currentValue : any;

  constructor(private elementRef: ElementRef, @Optional() private control: NgControl) { }

  ngOnInit() {
    let elem = this.elementRef.nativeElement;
    let value = this.elementRef.nativeElement.value;
    this._currentValue = value;
    this.applyMask(elem);
  }

  @HostListener('focus', ['$event']) onFocus(e: Event) {
    let elem = this.elementRef.nativeElement;
    let value = this.elementRef.nativeElement.value;
    if (!value) {
      this._defaultValueSet = true;
      this.elementRef.nativeElement.value = 0;
    }
    this.applyMask(elem,true);
  }

  @HostListener('input', ['$event']) onInput(e: Event) {
    let elem = this.elementRef.nativeElement;
    this.applyMask(elem,true);
  }

  setCursorPosition(elem, pos) {
    if (elem.setSelectionRange) {
      elem.setSelectionRange(pos, pos);
    } else if (elem.createTextRange) {
      var range = elem.createTextRange();
      range.collapse(true);
      range.moveEnd('character', pos);
      range.moveStart('character', pos);
      range.select();
    }
  }

  applyMask(elem,checkCursorPos?:boolean) {
    let currentCursorPos = elem.selectionStart;
    let value = elem.value;
    let maxIntegerDigits = this.config.integerDigits;
    let decimalPlaces = this.config.decimalPlaces;
    if (value) {
      value = value.replace(/\,/g, '');
      // check the length before decimal
      let integerValue = (value.indexOf(".") >= 0) ? value.substr(0, value.indexOf(".")) : value;
      let decimalValue = (value.indexOf(".") >= 0) ? value.substr(value.indexOf(".") + 1) : 0;
      integerValue = integerValue.length > maxIntegerDigits ? integerValue.substr(0, maxIntegerDigits) : integerValue;
      decimalValue = decimalValue.length > decimalPlaces ? decimalValue.substr(0, decimalPlaces) : decimalValue;
      value = integerValue + "." + decimalValue;
      let bigNum = new BigNumber.BigNumber(value);
      elem.value = bigNum.toFormat(decimalPlaces);
      let cursorPos = elem.value.indexOf(".") >= 0 ? elem.value.indexOf(".") : elem.value.length;
      if((checkCursorPos && currentCursorPos <= cursorPos+1) || !checkCursorPos){
        this.setCursorPosition(elem, cursorPos);
      } else if(checkCursorPos){
        this.setCursorPosition(elem, currentCursorPos);
      }
    }
  }

  @HostListener('blur', ['$event']) onBlur(e: Event) {
    let decimalPlaces = this.config.decimalPlaces;
    let value = this.elementRef.nativeElement.value;
    if(this._defaultValueSet){
      this.elementRef.nativeElement.value = this._currentValue;
      this.control.control.patchValue(this._currentValue);
    }
    else if (value) {
      value = value.replace(/\,/g, '');
      let bigNum = new BigNumber.BigNumber(value);
      this.control.control.patchValue(bigNum.toFixed(decimalPlaces));
    }
  }

  @HostListener('keypress', ['$event']) onkeypress(e: KeyboardEvent) {
    this._defaultValueSet = false;
    var charCode = (e.which) ? e.which : e.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  @HostListener('paste', ['$event']) onPaste(e: KeyboardEvent) {
    this._defaultValueSet = false;
  }

}
