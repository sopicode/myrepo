import { NgModule } from '@angular/core';
import { MatInputModule, MatDividerModule } from '@angular/material';
import { MatButtonModule } from '@angular/material';
import { MatDialogModule } from '@angular/material';
import { MatExpansionModule } from '@angular/material';
import { MatRadioModule } from '@angular/material';
import { MatMenuModule } from '@angular/material';
import { MatCardModule } from '@angular/material';
import { MatSelectModule } from '@angular/material';
import { MatChipsModule } from '@angular/material';
import { MatAutocompleteModule } from '@angular/material';
import { MatDatepickerModule,MatTableModule} from '@angular/material';
import { MatMomentDateModule } from '@angular/material-moment-adapter';
import {MatProgressSpinnerModule} from '@angular/material';
import {MatCheckboxModule} from '@angular/material';
import {MatTooltipModule} from '@angular/material';

@NgModule({
  imports: [MatInputModule, 
            MatButtonModule, 
            MatDialogModule, 
            MatExpansionModule, 
            MatRadioModule, 
            MatMenuModule, 
            MatCardModule, 
            MatSelectModule, 
            MatChipsModule, 
            MatAutocompleteModule, 
            MatDatepickerModule, 
            MatMomentDateModule,
            MatTableModule,
            MatProgressSpinnerModule,
            MatCheckboxModule,
            MatTooltipModule,
            MatDividerModule],
  exports: [MatInputModule, 
            MatButtonModule, 
            MatDialogModule, 
            MatExpansionModule, 
            MatRadioModule, 
            MatMenuModule, 
            MatCardModule, 
            MatSelectModule, 
            MatChipsModule, 
            MatAutocompleteModule, 
            MatDatepickerModule, 
            MatMomentDateModule,
            MatTableModule,
            MatProgressSpinnerModule,
            MatCheckboxModule,
            MatTooltipModule,MatDividerModule]
})
export class MaterialAppModule { }
