import { Component, Inject } from '@angular/core';
import { HomeComponent } from './components/home/home.component';
import { MatDialog, MatDialogConfig } from "@angular/material";
import { ClientErrorComponent } from './components/client-error/client-error.component';
import { Task } from './models/task';
import { UserService } from './services/user.service';
import { DealService } from './services/deal.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  private dialogRef: any;
  private _task: Task; // holds task information
  private _userInfo: any;
  private _lockData: any = {};

  constructor(private userService: UserService, private dialog: MatDialog, @Inject("unmountFunc") private unmountFunc, @Inject("task") private task,
    private dealService: DealService) {
    this.openBillingComponent();
  }

  openBillingComponent(){
    if(!this.task.variablesMap){
      this.dealService.getVariables(this.task.processInstanceId).subscribe(data => {
        let variables: any[] = data;
        let variablesObj : any = {};
        for(let variable of variables){
          let name = variable["name"];
          let value = variable["value"];
          variablesObj[name] = value;
        }
        this.task.variablesMap = variablesObj;
        this._task = Task.fromJSON(this.task);
        this.validateUser();
      });
    }
    else {
      this._task = Task.fromJSON(this.task);
      this.validateUser();
    }   
  }

  validateUser() {
    this.userService.getProfileInformation().subscribe(data => {
      this._userInfo = data.data;
      let variables = this._task.variables;
      if (variables.isApproveTask) {
        if (!(data.data.comitId == variables.billingTaskInitiator)) {
          this.showHomeComponent();
        }
        else {
          this.showAccessErrorDialog(variables.makerCheckerErrorMessage);
        }
      }
      else {
        this.showHomeComponent();
      }
    });
   }

  showAccessErrorDialog(data: any) {
    const dialogConfig = this.createDialog();
    dialogConfig.width = '480px';
    dialogConfig.height = '115px';
    dialogConfig.data = data;
    this.dialogRef = this.dialog.open(ClientErrorComponent, dialogConfig);
    this.dialogRef.componentInstance.errorMessages = [];
    this.dialogRef.componentInstance.errorMessages.push(data);
    this.dialogRef.componentInstance.hasCloseIcon = true;
    this.dialogRef.componentInstance.showTotalErrorCount = false;
    this.dialogRef.componentInstance.showErrorsAsList = false;
    this.dialogRef.componentInstance.closeClick.subscribe($event => {
      this.dialogRef.close();
    });
    this.dialog.afterAllClosed.subscribe(() => { this.unmountFunc() });
  }

  showHomeComponent() {
    // in view mode, no need to acquire lock as no actions are permitted
    if(this._task.mode != 'view'){
      this.getTaskLockAction();
    }
    const dialogConfig = this.createDialog();
    dialogConfig.panelClass = ['billingPopup','billing'];
    dialogConfig.width = '980px';
    this.dialogRef = this.dialog.open(HomeComponent, dialogConfig);
    this.dialog.afterAllClosed.subscribe(() => {
      if (this._task.mode != 'view' && this.checkIfReleaseLockApplicable()) {
        this.getTaskCloseAction();
      }
      this.unmountFunc();
    });
  }
  createDialog() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.autoFocus = false;
    dialogConfig.disableClose = true;
    dialogConfig.hasBackdrop = true;
    return dialogConfig;
  }

  getTaskCloseAction() {
    this.dealService.releaseLock(this._task.id, this._task.taskId).subscribe(
      data => {
      });
  }

  checkIfReleaseLockApplicable() {
    var loggedInUserComitId = this._userInfo.comitId;
    var activeLockComitId = this._lockData.lockedByComitId;
    return loggedInUserComitId && (!activeLockComitId || loggedInUserComitId == activeLockComitId);
  }

  getTaskLockAction() {
    this.dealService.checkLock(this._task.id, this._task.taskId).subscribe(
      data => {
        let lockData: any = data;
        this._lockData = lockData.data;
        this.dialogRef.componentInstance.lockData = this._lockData;
        let lockedByComitId = this._lockData.lockedByComitId;
        if (lockedByComitId == null) {
          this.dealService.acquireLock(this._task.id, this._task.taskId).subscribe(
            data => {
            });
        }
      });
  }

}