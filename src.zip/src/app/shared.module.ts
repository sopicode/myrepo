import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MaterialAppModule } from './material.module';
import { HttpClientModule } from '@angular/common/http';
import { FlexLayoutModule } from "@angular/flex-layout";
import { FileUploadModule } from 'ng2-file-upload';
import { SatPopoverModule } from '@ncstate/sat-popover';

import { AppComponent } from './app.component';
import { HeaderComponent } from './components/header/header.component';
import { HomeComponent } from './components/home/home.component';
import { FooterComponent } from './components/footer/footer.component';
import { RequestDetailsComponent } from './components/request-details/request-details.component';
import { AccountsComponent } from './components/accounts/accounts.component';
import { CustomerContactInformationComponent } from './components/customer-contact-information/customer-contact-information.component';
import { ContactInformationComponent } from './components/contact-information/contact-information.component';
import { TeamComponent } from './components/team/team.component';
import { DocumentsComponent } from './components/documents/documents.component';
import { SpecialInstructionsComponent } from './components/special-instructions/special-instructions.component';
import { DmCharCounterDirective } from './directives/dm-char-counter.directive';
import { AccountComponent } from './components/account/account.component';
import { AccountDetailComponent } from './components/account-detail/account-detail.component';
import { FormFieldOptionalDirective } from './directives/form-field-optional.directive';
import { ContactDetailsComponent } from './components/contact-details/contact-details.component';
import { LoaderComponent } from './components/loader/loader.component';
import { SummaryComponent } from './components/summary/summary.component';
import { ExpandedTableComponent } from './components/expanded-table/expanded-table.component';
import { AccordionComponent } from './components/accordion/accordion.component';
import { DocumentDetailComponent } from './components/document-detail/document-detail.component';
import { CreateEditContactComponent } from './components/create-edit-contact/create-edit-contact.component';
import { ChipsMultiselectComponent } from './components/chips-multiselect/chips-multiselect.component';
import { AccountDetailsComponent } from './components/account-details/account-details.component';
import { SelectComponent } from './components/select/select.component';
import { InvoiceComponent } from './components/invoice/invoice.component';
import { DynamicTableComponent } from './components/dynamic-table/dynamic-table.component';
import { SystemLinksComponent } from './components/system-links/system-links.component';
import { ServicesFeesComponent } from './components/services-fees/services-fees.component';
import { InputMaskDirective } from './directives/input-mask.directive';
import { ServerErrorComponent } from './components/server-error/server-error.component';
import { CustomerContactDetailsComponent } from './components/customer-contact-details/customer-contact-details.component';
import { ContactDealpartyDetailsComponent } from './components/contact-dealparty-details/contact-dealparty-details.component';
import { RadioComponent } from './components/radio/radio.component';
import { AdditionalBillingDetailsComponent } from './components/additional-billing-details/additional-billing-details.component';
import { ClientErrorComponent } from './components/client-error/client-error.component';
import { TableComponent } from './components/table/table.component';
import { ExpandableContainerComponent } from './components/expandable-container/expandable-container.component';
import { TextareaComponent } from './components/textarea/textarea.component';
import { AutocompleteComponent } from './components/autocomplete/autocomplete.component';
import { DatepickerComponent } from './components/datepicker/datepicker.component';
import { ManualBillingComponent } from './components/manual-billing/manual-billing.component';
import { WarningComponent } from './components/warning/warning.component';
import { RejectCommentsComponent } from './components/reject-comments/reject-comments.component';
import { UserAccessDialogComponent } from './components/user-access-dialog/user-access-dialog.component';
import { BigNumberDirective } from './directives/big-number.directive';
import { SectionHeadingComponent } from './components/section-heading/section-heading.component';
import { BillingKeyDetailsComponent } from './components/billing-key-details/billing-key-details.component';
import { DataMismatchDetailsComponent } from './components/data-mismatch-details/data-mismatch-details.component';
import { SearchExistingAccount } from './components/search-existing-account/search-existing-account.component';

@NgModule({
    declarations: [ 
        AppComponent,
        HeaderComponent,
        HomeComponent,
        FooterComponent,
        RequestDetailsComponent,
        AccountsComponent,
        CustomerContactInformationComponent,
        ContactInformationComponent,
        TeamComponent,
        DocumentsComponent,
        SpecialInstructionsComponent,
        DmCharCounterDirective,
        AccountComponent,
        AccountDetailComponent,
        FormFieldOptionalDirective,
        ContactDetailsComponent,
        LoaderComponent,
        SummaryComponent,
        ExpandedTableComponent,
        AccordionComponent,
        DocumentDetailComponent,
        CreateEditContactComponent,
        ChipsMultiselectComponent,
        AccountDetailsComponent,
        SelectComponent,
        InvoiceComponent,
        DynamicTableComponent,
        SystemLinksComponent,
        ServicesFeesComponent,
        InputMaskDirective,
        ServerErrorComponent,
        CustomerContactDetailsComponent,
        ContactDealpartyDetailsComponent,
        RadioComponent,
        AdditionalBillingDetailsComponent,
        ClientErrorComponent,
        TableComponent,
        ExpandableContainerComponent,
        TextareaComponent,
        AutocompleteComponent,
        DatepickerComponent,
        ManualBillingComponent,
        WarningComponent,
        RejectCommentsComponent,
        UserAccessDialogComponent,
        BigNumberDirective,
        SectionHeadingComponent,
        BillingKeyDetailsComponent,
        DataMismatchDetailsComponent,
        SearchExistingAccount
      ],
      entryComponents: [
        HomeComponent,
        RequestDetailsComponent,
        CustomerContactInformationComponent,
        AccountsComponent,
        ContactInformationComponent,
        TeamComponent,
        DocumentsComponent,
        SpecialInstructionsComponent,
        AccountDetailComponent,
        SummaryComponent,
        CreateEditContactComponent,
        AdditionalBillingDetailsComponent,
        
        ManualBillingComponent,
        RejectCommentsComponent,
        UserAccessDialogComponent,
        ClientErrorComponent,
        BillingKeyDetailsComponent,
        DataMismatchDetailsComponent,
        SearchExistingAccount
    ],
    imports: [
        BrowserModule,
        BrowserAnimationsModule,
        MaterialAppModule,
        ReactiveFormsModule,
        HttpClientModule,
        FlexLayoutModule,
        FileUploadModule,
        SatPopoverModule
      ],
    exports: [ AppComponent ]
  })
export class SharedModule {}