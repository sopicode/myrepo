import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'billing-user-access-dialog',
  templateUrl: './user-access-dialog.component.html',
  styleUrls: ['./user-access-dialog.component.scss']
})
export class UserAccessDialogComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
