import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { FormDetail } from 'src/app/models/form-detail';

@Component({
  selector: 'billing-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss']
})
export class FooterComponent implements OnInit {

  @Input() formDetail: FormDetail;
  @Input() formDetails: FormDetail[];
  @Input() lockData: any;

  @Output() menuClick = new EventEmitter();
  @Output() backClick = new EventEmitter();
  @Output() nextClick = new EventEmitter();
  @Output() submitClick = new EventEmitter();
  @Output() cancelClick = new EventEmitter();
  @Output() approveClick = new EventEmitter();
  @Output() rejectClick = new EventEmitter();


  constructor() {

  }

  ngOnInit() {

  }

  navigate(formDetail: any) {
    let data = {};
    data["formDetail"] = formDetail;
    data["action"] = "goto";
    this.menuClick.emit(data);
  }

  goBack() {
    let data = {};
    data["formDetail"] = this.formDetail;
    data["action"] = "back";
    this.backClick.emit(data);
  }

  goNext() {
    this.nextClick.emit();
  }

  submit() {
    this.submitClick.emit();
  }

  cancel() {
    this.cancelClick.emit();
  }

  approve() {
    this.approveClick.emit();
  }

  reject() {
    this.rejectClick.emit();
  }

}
