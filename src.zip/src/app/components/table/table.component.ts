import { Component, OnInit, Input, TemplateRef, Output, EventEmitter } from '@angular/core';
import { TableModel } from 'src/app/models/table-model';

@Component({
  selector: 'billing-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.scss']
})
export class TableComponent implements OnInit {

  @Input()
  actionTemplate: TemplateRef<any>;
  @Input()
  dataSource: TableModel[];
  @Input()
  columnsToDisplay: string[];
  @Input()
  columnsDisplayNames: any;
  @Input()
  dataSourceEmptyMsg: string;

  @Output() rowClick = new EventEmitter();

  selectedRow: any;

  constructor() { }

  ngOnInit() {
  }

  clicked(element: any) {
    this.rowClick.emit(element);
    this.selectedRow = element;
  }

}