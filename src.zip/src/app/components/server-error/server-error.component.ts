import { Component, OnInit, Input, ChangeDetectorRef } from '@angular/core';
import { Subscription } from 'rxjs';
import { ErrorService } from 'src/app/services/error.service';
import { ErrorState } from 'src/app/models/error-state';

@Component({
  selector: 'billing-server-error',
  templateUrl: './server-error.component.html',
  styleUrls: ['./server-error.component.scss']
})
export class ServerErrorComponent implements OnInit {

  serverError:any
  show = false;
  private subscription: Subscription;
  constructor(private errorService: ErrorService, private ref: ChangeDetectorRef) { }

  ngOnInit() {
    this.subscription = this.errorService.errorState
      .subscribe((state: ErrorState) => {
        if (this.show != state.show) {
          this.show = state.show;
          this.serverError = state.errorObject;
          this.ref.detectChanges();
        }
      });
  }
  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
}
