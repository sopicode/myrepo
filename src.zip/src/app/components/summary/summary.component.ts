import { Component, OnInit, Input, Inject } from '@angular/core';
import { Deal } from 'src/app/models/deal';
import { Wizard } from 'src/app/models/wizard';
import { Task } from 'src/app/models/task';

@Component({
  selector: 'billing-summary',
  templateUrl: './summary.component.html',
  styleUrls: ['./summary.component.scss']
})
export class SummaryComponent implements OnInit {

  @Input() deal: Deal;
  @Input() data: any[];
  @Input() wizard: Wizard;
  reqDetailsData: any[] = [];
  custContactData: any[] = [];
  accountsData: any[] = [];
  teamData: any[] = [];
  specialInstData: any[] = [];
  documentsData: any[] = [];
  billingContactData: any[] = [];
  dataMismatchData: any[] = [];
  additionalBillingData: any[] = [];
  specialInstructionsHeader: string = "Special Billing Instructions (optional)";
  private _task: Task; // holds task information
  existingBillingKey: boolean;

  constructor(@Inject("task") private task) {
    this._task = Task.fromJSON(task);
  }

  ngOnInit() {
    let billingStatus = this._task.variables && this._task.variables.billingStatus ? this._task.variables.billingStatus : '';
    if ("Sent To Billing" != billingStatus && "Billing Success" != billingStatus) {
      if (this.data[0].data.billingTypeCode == 'E') {
        this.existingBillingKey = true;
      }
      this.reqDetailsData = [this.data[0], this.data[1], this.data[2], this.data[3], this.data[4], this.data[20]];
      this.custContactData = [this.data[5], this.data[6]];
      this.billingContactData = [this.data[7], this.data[8], this.data[0], this.data[6]];
      this.accountsData = [this.data[9], this.data[10], this.data[0]];
      this.additionalBillingData = [this.data[11], this.data[0], this.data[9], this.data[5], this.data[17], this.data[18], this.data[19], this.data[6], this.data[10]];
      this.teamData = [this.data[12], this.data[13]];
      this.documentsData = [this.data[14], this.data[15]];
      this.specialInstData = [this.data[16], this.data[0]];
      this.dataMismatchData = [this.data[0], this.data[21]];
      let reqDetails = this.data[0].data;
      let billingTypeCode = reqDetails.billingTypeCode;
      if (billingTypeCode != "N") {
        this.specialInstructionsHeader = "Special Billing Instructions";
      }
    } else {
      let billingSnapshotData = this.data[0].data;
      let reqDetailsFormData = {};
      reqDetailsFormData["data"] = billingSnapshotData["billingRequestDetails"];
      let custContactFormData = {};
      custContactFormData["data"] = [];
      custContactFormData["data"].push(billingSnapshotData["billingCustomer"]);
      let billingContactFormData = {};
      billingContactFormData["data"] = [];
      billingContactFormData["data"].push(billingSnapshotData["billingContact"]);
      let addlBillingFormData = {};
      addlBillingFormData["data"] = billingSnapshotData["additionalBillingDetails"];
      let billingTeamFormData = {};
      billingTeamFormData["data"] = billingSnapshotData["billingTeam"];
      let specialInstFormData = {};
      specialInstFormData["data"] = billingSnapshotData["specialInstructionRequest"];
      this.reqDetailsData = [reqDetailsFormData, this.data[3], this.data[4], this.data[5], this.data[6], this.data[20]];
      this.custContactData = [custContactFormData, this.data[7]];
      this.billingContactData = [billingContactFormData, this.data[8], reqDetailsFormData, this.data[7]];
      this.accountsData = [this.data[1], this.data[9], reqDetailsFormData];
      this.additionalBillingData = [addlBillingFormData, reqDetailsFormData, this.data[1], custContactFormData, this.data[12], this.data[13], this.data[14], this.data[7], this.data[9]];
      this.teamData = [billingTeamFormData, this.data[10]];
      this.documentsData = [this.data[2], this.data[11]];
      this.specialInstData = [specialInstFormData, reqDetailsFormData];
      this.dataMismatchData = [, this.data[15]];
    }
  }

}