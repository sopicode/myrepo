import { Component, OnInit, Input, Inject, ChangeDetectorRef, Output, EventEmitter } from '@angular/core';
import { Deal } from 'src/app/models/deal';
import { dealPartyRoles } from 'src/app/models/dealPartyRoles';
import { HelperService } from '../../services/helper.service';
import { MatDialog, MatDialogConfig } from "@angular/material";
import { CreateEditContactComponent } from '../create-edit-contact/create-edit-contact.component';
import { DealService } from '../../services/deal.service';
import { Task } from '../../models/task';
import { ContactDetail } from 'src/app/models/contact-detail';
import { PartiesService } from 'src/app/services/parties.service';
import { ErrorService } from 'src/app/services/error.service';

@Component({
  selector: 'billing-contact-information',
  templateUrl: './contact-information.component.html',
  styleUrls: ['./contact-information.component.scss']
})
export class ContactInformationComponent implements OnInit {

  @Input() deal: Deal;
  @Input() data: any;
  @Input() readOnly: boolean;
  roles: dealPartyRoles[];
  dealPartyName: string;
  partyId: number;

  selectedDealParty: any;
  singleDealParty: boolean = false;
  showAllDealParties: boolean = false;

  selectedContact: any;
  singleContact: boolean = true;
  showAllContacts: boolean = false;

  partyRoleTypes: any;
  billingContacts: ContactDetail[];
  billingReqDetails: any;

  country: string;
  countryList: any;

  constructor(private dealService: DealService, @Inject("task") private taskDetails, private partiesService: PartiesService, private helperService: HelperService, private errorService: ErrorService, private dialog: MatDialog) {
  }

  extractBillingParties(d) {
    if (d.length > 1) {
      let selectedDP = this.helperService.filterByKey(d, "isSelected", true);
      // if there are no selected deal parties, show grid
      if (selectedDP && selectedDP.length > 0) {
        this.selectedDealParty = selectedDP[0];
      } else {
        this.showAllDealParties = true;
      }
      this.singleDealParty = false;
    } else {
      this.selectedDealParty = d[0];
      this.singleDealParty = true;
    }
  }

  extractBillingContact() {
    let d = this.billingContacts ? this.billingContacts : null;
    if (d && d.length > 1) {
      let selectedCnt = this.helperService.filterByKey(d, "isSelected", true);
      this.singleContact = false;
      // if there are no selected contacts, show grid
      if (selectedCnt && selectedCnt.length > 0) {
        this.selectedContact = selectedCnt[0];
      } else {
        this.showAllContacts = true;
      }
    } else if(d[0]){
      this.selectedContact = d[0];
      this.singleContact = true;
    } else { // if there is no contact in a deal party
      this.showAllContacts = true;
    }
    if (this.selectedContact) {
      let countryCode = this.selectedContact.country;
      let countrySource = this.helperService.find(this.countryList.data, "code", countryCode);
      if (countrySource) {
        this.country = countrySource.name;
      }
    }
  }

  ngOnInit() {
    let task = Task.fromJSON(this.taskDetails);
    this.partyRoleTypes = this.data[1];
    this.billingReqDetails = this.data[2];
    this.countryList = this.data[3];
    let billingStatus = task.variables && task.variables.billingStatus ? task.variables.billingStatus : '';
    if ("Sent To Billing" != billingStatus && "Billing Success" != billingStatus) {
      this.extractBillingParties(this.data[0].data);
      if (this.selectedDealParty) {
        this.roles = this.selectedDealParty.roles;
        this.dealPartyName = this.selectedDealParty.dealPartyName;
        this.partyId = this.selectedDealParty.partyId;
        this.dealService.getBillingContacts(task.id, task.variables.billingRequestId, this.partyId).subscribe(
          data => {
            this.billingContacts = this.buildContacts(data.data);
            this.extractBillingContact();
            //if there is no selected contact, then in summary page show empty contact
            if (this.readOnly && !this.selectedContact) {
              this.selectedContact = new ContactDetail();
            }
          });
      }
    } else {
      this.billingContacts = this.buildContacts(this.data[0].data);
      this.extractBillingContact();
    }
  }

  selectContact(data: any) {
    this.showAllContacts = false;
    this.selectedContact = data;
    let countryCode = this.selectedContact.country;
    let countrySource = this.helperService.find(this.countryList.data, "code", countryCode);
    if (countrySource) {
      this.country = countrySource.name;
    }
    this.errorService.hide();
  }

  selectDealParty(data: any) {
    this.showAllDealParties = false;
    this.selectedDealParty = data;
    this.roles = this.selectedDealParty.roles;
    this.partyId = this.selectedDealParty.partyId;
    this.showAllContacts = true;
    let task = Task.fromJSON(this.taskDetails);
    this.dealService.getBillingContacts(task.id, task.variables.billingRequestId, this.partyId).subscribe(
      data => {
        this.billingContacts = this.buildContacts(data.data);
      });
    this.errorService.hide();
  }

  changeContact() {
    this.showAllContacts = true;
    this.selectedContact = null;
    this.errorService.hide();
  }

  changeDealParty() {
    this.showAllDealParties = true;
    this.showAllContacts = false;
    this.selectedDealParty = null;
    this.selectedContact = null;
    this.errorService.hide();
  }
  openContactForm(data) {
    let dialogData;
    let isCompanyNameTruncated = false;
    let billingReqType = this.billingReqDetails.data.billingTypeCode;
    this.errorService.hide();
    if (data && data.company) {
      this.dealPartyName = data.company;
    } else {
      this.dealPartyName = this.selectedDealParty.dealPartyName;
    }
    if (this.dealPartyName && this.dealPartyName.length > 40) {
      this.dealPartyName = this.dealPartyName.substring(0, 40);
      isCompanyNameTruncated = true && billingReqType == 'N';
    }
    let mode = data ? "Edit Contact" : "Create New Contact";
    if (!data) {
      data = new ContactDetail();
    }
    if (data.contactId) {
      this.partiesService.getIndividualContactDetails(data.contactId).subscribe(
        contactData => {
          let contactDetail: ContactDetail = ContactDetail.fromJSON(contactData.data);
          dialogData = { "mode": mode, "companyName": this.dealPartyName, "partyId": this.partyId, "data": contactDetail, "readOnly": this.readOnly, "isCompanyNameTruncated": isCompanyNameTruncated };
          this.openContactDialog(dialogData);
        });
    } else {
      dialogData = { "mode": mode, "companyName": this.dealPartyName, "partyId": this.partyId, "data": data, "readOnly": this.readOnly, "isCompanyNameTruncated": isCompanyNameTruncated};
      this.openContactDialog(dialogData);
    }
  }

  openContactDialog(data: any) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.autoFocus = false;
    dialogConfig.hasBackdrop = true;
    dialogConfig.disableClose = true;
    dialogConfig.panelClass = ['contactPopup','billing'];
    dialogConfig.width = '980px';
    dialogConfig.data = data;
    let dialogRef = this.dialog.open(CreateEditContactComponent, dialogConfig);
    let task = Task.fromJSON(this.taskDetails);
    dialogRef.afterClosed().subscribe(dialogData => {
      this.dealService.getBillingContacts(task.id, task.variables.billingRequestId, this.partyId).subscribe(
        data => {
          this.billingContacts = this.buildContacts(data.data);
          this.extractBillingContact();
        });
    });
  }

  getSubmissionData() {
    let data: any = {};
    data.billingRequestId = this.billingReqDetails.data.id;
    if (this.selectedContact) {
      data.selectedContactId = this.selectedContact.contactId;
    }
    if (this.selectedDealParty) {
      data.selectedPartyId = this.selectedDealParty.partyId;
    }
    return data;
  }


  buildContacts(contactList: any): ContactDetail[] {
    let contacts: ContactDetail[] = [];
    if (Array.isArray(contactList)) {
      contactList.forEach((contact, index) => {
        let contactDetail: ContactDetail = ContactDetail.fromJSON(contact);
        contactDetail.position = index % 2 == 0 ? 'even' : 'odd';
        contacts.push(contactDetail);
      });
      return contacts;
    }
  }

}
