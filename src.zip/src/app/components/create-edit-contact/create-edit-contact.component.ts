import { Component, OnInit, Inject, Output, EventEmitter, ViewChild, ElementRef } from '@angular/core';
import { FormGroup, Validators, FormBuilder, FormArray, FormControl } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from "@angular/material";
import { Error } from 'src/app/models/error';
import { ReferencesService } from 'src/app/services/references.service';
import { PartiesService } from '../../services/parties.service';
import { FormService } from '../../services/form.service';
import { Wizard } from '../../models/wizard';
import { Deal } from '../../models/deal';
import { forkJoin } from 'rxjs';
import * as _ from 'lodash';
import { ContactDetail } from 'src/app/models/contact-detail';
import { HelperService } from 'src/app/services/helper.service';

@Component({
  selector: 'billing-create-edit-contact',
  templateUrl: './create-edit-contact.component.html',
  styleUrls: ['./create-edit-contact.component.scss']
})
export class CreateEditContactComponent implements OnInit {
  
  @ViewChild('alertDiv') alertDiv: ElementRef;
  
  deal: Deal;
  contactDetails;
  companyName;
  partyId;
  modalTitle;
  contactDetailForm: FormGroup;
  contactData: ContactDetail;
  wizard: Wizard;
  _title: any[];
  _preTitle: any[];
  _suffix: any[];
  country: any[];
  _state: any[];
  saveChanges: boolean = false;
  errors: Error[] = [];
  errorMessages: string[] = [];
  invalidForm: boolean;
  isUSOrCanada: boolean;
  readOnly: boolean;
  isCompanyNameTruncated : boolean;
  fieldsToBeWatched: string[] = ['company', 'firstName', 'lastName',
    'title', 'country',
    'addressLine1', 'addressLine2', 'addressLine3', 'city', 'state', 'postalCode'];

  constructor(private _fb: FormBuilder, private dialogRef: MatDialogRef<CreateEditContactComponent>,
    @Inject(MAT_DIALOG_DATA) data, private referencesService: ReferencesService,
    private formService: FormService, private partiesServices: PartiesService, private helperService: HelperService) {
    this.modalTitle = data.mode;
    this.companyName = data.companyName;
    this.partyId = data.partyId;
    this.contactData = data.data;
    this.readOnly = data.readOnly;
    this.isCompanyNameTruncated = data.isCompanyNameTruncated;
  }
  onSelectCountry(countryCode: string) {
    this.contactDetailForm.get('postalCode').setValue(null);
    this.contactDetailForm.get('state').setValue(null);
    this.getPatternForCountry(countryCode);
    if (this.isUSOrCanada) {
      this.referencesService.getCountrySubDivisions(countryCode).subscribe((value: any) => {
        this._state = value.data;
      });
    }
  }

  ngOnInit() {
    this.isUSOrCanada = this.contactData.country == "CAN" || this.contactData.country == "USA";
    let phone = this.contactData.phone ? this.contactData.phone : '000-000-0000';
    if (this.isUSOrCanada) {
      this.referencesService.getCountrySubDivisions(this.contactData.country).subscribe((value: any) => {
        this._state = value.data;
      });
    }
    this.contactDetailForm = this._fb.group({
      contactId: [this.contactData.contactId ? this.contactData.contactId : null],
      partyId: [this.partyId],
      company: [this.companyName, Validators.required],
      title: [this.contactData.title],
      preTitle: [this.contactData.preTitle],
      suffix: [this.contactData.suffix],
      state: [this.contactData.state],
      firstName: [this.contactData.firstName],
      lastName: [this.contactData.lastName],
      initial: [this.contactData.initial],
      phone: [phone, Validators.required],
      mobile: [this.contactData.mobile],
      fax: [this.contactData.fax],
      email: [this.contactData.email],
      addressLine1: [this.contactData.addressLine1, Validators.required],
      addressLine2: [this.contactData.addressLine2],
      addressLine3: [this.contactData.addressLine3],
      city: [this.contactData.city, Validators.required],
      country: [this.contactData.country,Validators.required],
      postalCode: [this.contactData.postalCode],
      firreAddressNumber: [{ value: this.contactData.firreAddressNumber, disabled: true}],
      acsNameKey: [this.contactData.acsNameKey],
      nexenClientId: [this.contactData.nexenClientId],
      eagleIntPartyId: [this.contactData.eagleIntPartyId],
      proxyEdgeId: [this.contactData.proxyEdgeId]
    });
    this.initErrors();
    this.contactDetailForm.valueChanges.subscribe((data) => {
      this.errorMessages = this.formService.validateForm(this.contactDetailForm, this.errors);
    });
    this.getPatternForCountry(this.contactData.country);
    let title = this.referencesService.getTitle();
    let preTitle = this.referencesService.getPreTitle();
    let suffix = this.referencesService.getSuffix();
    let country = this.referencesService.getCountry();
    forkJoin(title, preTitle, suffix, country).subscribe((results: any[]) => {
      this._title = results[0].data;
      this._preTitle = results[1].data;
      this._suffix = results[2].data;
      this.country = results[3].data;
    });
    this.onCompanyNameChange();
  }

  initErrors() {
    this.errors.push(this.helperService.buildError("company", "Company - This field is required", "required"));
    this.errors.push(this.helperService.buildError("state", "State - This field is required", "required"));
    this.errors.push(this.helperService.buildError("addressLine1", "Address Line 1 - This field is required", "required"));
    this.errors.push(this.helperService.buildError("city", "City - This field is required", "required"));
    this.errors.push(this.helperService.buildError("country", "Country - This field is required", "required"));
    this.errors.push(this.helperService.buildError("postalCode", "Postal Code - This field is required", "required"));
    this.errors.push(this.helperService.buildError("phone", "Phone - This field is required", "required"));
  }

  getPatternForCountry(countryCode: string) {
    this.isUSOrCanada = countryCode == "CAN" || countryCode == "USA";
    if (this.isUSOrCanada) {
      this.helperService.addValidation(this.contactDetailForm,"postalCode",Validators.required);
      this.helperService.addValidation(this.contactDetailForm,"state",Validators.required);
    } else {
      this.helperService.removeValidation(this.contactDetailForm,"postalCode");
      this.helperService.removeValidation(this.contactDetailForm,"state");
    }
  }

  detectChangesInValues(field: string): boolean {
    let newValue = this.contactDetailForm.get(field).value;
    let oldValue = this.contactData[field];
    if (newValue != oldValue) {
      return true;
    }
    return false;
  }

  onCompanyNameChange(){
    this.contactDetailForm.get('company').valueChanges.subscribe(value => {
      this.isCompanyNameTruncated = false;
    });
  }

  saveContact(showAlert?: boolean) {
    let form = this.contactDetailForm;
    this.formService.validateFormFields(form);
    if (showAlert) {
      let valueChanged = false;
      for (let field of this.fieldsToBeWatched) {
        valueChanged = this.detectChangesInValues(field);
        if (valueChanged) {
          break;
        }
      }
      if (valueChanged && this.contactData.firreAddressNumber) {
        this.saveChanges = true;
        setTimeout(() => {this.alertDiv.nativeElement.scrollIntoView()},500);
      }
    }
    if (!form.valid) {
      this.invalidForm = true;
      setTimeout(() => {this.alertDiv.nativeElement.scrollIntoView()},500);
    } else if (!showAlert || !this.saveChanges) {
      let endPoint = "contact-details"
      let reqBody = {};
      let formData = {};
      this.formService.collectData(form, formData, true);
      if (this.saveChanges) {
        formData["firreAddressNumber"] = null;
      }
      reqBody["data"] = formData;
      this.partiesServices.postForm(endPoint, reqBody).subscribe(
        data => {
          this.closePopup();
        }, error => {
          setTimeout(() => {this.alertDiv.nativeElement.scrollIntoView()},500);
        })
    }

  }

  closePopup() {
    this.dialogRef.close();
  }

  cancel() {
    this.closePopup();
  }

  cancelFirreValidation(){
    this.saveChanges = false;
  }

}
