import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { BillingAccount } from 'src/app/models/billing-account';
import { FormGroup, FormBuilder, FormArray, Validators } from '@angular/forms';
import { Column } from 'src/app/models/column';
import { ReferencesService } from 'src/app/services/references.service';
import { forkJoin } from 'rxjs';
import { HelperService } from 'src/app/services/helper.service';

@Component({
  selector: 'billing-system-links',
  templateUrl: './system-links.component.html',
  styleUrls: ['./system-links.component.scss']
})
export class SystemLinksComponent implements OnInit {

  @Input()
  billingAccount: BillingAccount;
  @Input()
  readOnly: boolean;
  @Output() formReady = new EventEmitter<FormGroup>();
  linksForm: FormGroup;
  columns: Column[] = [];
  _systemNames: any[];
  _subSystemNames: any[];
  _systemPurpose: any[];
  _billingDisplayOptions: any[];
  _showSourceDetail: boolean = false;

  constructor(private _fb: FormBuilder, private referencesService: ReferencesService, private helperService: HelperService) { }

  ngOnInit() {
    this.linksForm = this._fb.group({
      links: this._fb.array([]),
      separateBillingDisplayIndctr: [this.billingAccount.separateBillingDisplayIndctr, Validators.required],
      isEU: [this.billingAccount.isEU]
    });
    this.getSystemLinkColumns();
    let systemNames = this.referencesService.getSystemNames();
    let subSystemNames = this.referencesService.getSubSystemNames();
    let systemPurpose = this.referencesService.getSystemPurpose();
    forkJoin(systemNames, subSystemNames, systemPurpose).subscribe((results: any[]) => {
      this._systemNames = results[0].data;
      this._subSystemNames = results[1].data;
      this._systemPurpose = results[2].data;
      this.initLinks();
      this.formReady.emit(this.linksForm);
    });
    this._billingDisplayOptions = this.getBillingDisplayOptions();
  }

  getLinksControl(): FormArray {
    return this.linksForm.get('links') as FormArray;
  }
  getSystemLinkColumns() {
    this.columns.push({ "displayName": " ", "name": "linkCheck" });
    this.columns.push({ "displayName": "System Name", "name": "sysName" });
    this.columns.push({ "displayName": "Database Name", "name": "dbName" });
    this.columns.push({ "displayName": "System Key", "name": "sysKey" });
    this.columns.push({ "displayName": "System Purpose", "name": "sysPurpose" });
  }

  initLinks() {
    let linksControl = this.getLinksControl();
    if (this.billingAccount.links) {
      this.billingAccount.links.forEach(link => {
        if (!this.readOnly || (this.readOnly && link.isSelected)) {
          linksControl.push(
            this._fb.group({
              id: [link.id],
              billingAccountId: [link.billingAccountId],
              systemId: [{ value: link.systemId, disabled: true }],
              subSystem: [{ value: link.subSystem, disabled: true }],
              accountNumber: [{ value: link.accountNumber, disabled: true }],
              systemPurpose: [{ value: link.systemPurpose, disabled: true }],
              isSelected: [link.isSelected],
              action: [link.action]
            }))
        }
      })
    }
    if (!this.readOnly) {
      this.onLinksChange(this.linksForm.get('links').value);
      this.linksForm.get('links').valueChanges.subscribe(value => {
        this.onLinksChange(value);
      });
    }
  }

  getSystemName(systemId: string) {
    return this.helperService.find(this._systemNames, "id", systemId).name;
  }

  getSubSytemName(subSystemId: string) {
    return this.helperService.find(this._subSystemNames, "id", subSystemId).name;
  }

  getSystemPurposeName(systemPurpose: string) {
    return this.helperService.find(this._systemPurpose, "id", systemPurpose).name;
  }

  getBillingDisplayOptions(): any[] {
    let options: any[] = [];
    options.push(this.helperService.buildOption(true, "Yes - Separate Billing Display"));
    options.push(this.helperService.buildOption(false, "No - Aggregated Billing Display"));
    return options;
  }

  //on check of checkbox in system table 
  onLinksChange(value: any) {
    let selectedArray = this.helperService.filterByKey(value, "isSelected", true);
    let separateBillingDisplayIndctrCtrl = this.linksForm.get("separateBillingDisplayIndctr");
    if (selectedArray && selectedArray.length < 2) {
      separateBillingDisplayIndctrCtrl.setValue(false);
      this._showSourceDetail = false;
    } else {
      this._showSourceDetail = true;
    }
  }

}
