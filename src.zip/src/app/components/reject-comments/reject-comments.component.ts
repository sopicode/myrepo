import { Component, OnInit, Output, EventEmitter, ViewChild, ElementRef, Inject } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialog } from '@angular/material';
import { FormService } from 'src/app/services/form.service';
import { HelperService } from 'src/app/services/helper.service';
import { Error } from 'src/app/models/error';
import { Task } from 'src/app/models/task';
import { Deal } from 'src/app/models/deal';
import { DealService } from 'src/app/services/deal.service';
import { ErrorService } from 'src/app/services/error.service';

@Component({
  selector: 'billing-reject-comments',
  templateUrl: './reject-comments.component.html',
  styleUrls: ['./reject-comments.component.scss']
})
export class RejectCommentsComponent implements OnInit {

  rejectForm: FormGroup;
  @ViewChild('alertDiv') alertDiv: ElementRef;
  errors: Error[] = [];
  errorMessages: string[] = [];
  invalidForm: boolean;
  @Output() formInitialized = new EventEmitter<FormGroup>();
  private _task: Task; // holds task information
  private _deal: Deal; // holds deal informations

  constructor(private dialogAllRef: MatDialog, private dealService: DealService, private errorService: ErrorService, private _fb: FormBuilder, @Inject("task") private task, private dialogRef: MatDialogRef<RejectCommentsComponent>, private formService: FormService, private helperService: HelperService, @Inject(MAT_DIALOG_DATA) data) {
    this._task = Task.fromJSON(task);
    this._deal = data;
  }

  ngOnInit() {
    this.rejectForm = this._fb.group({
      id: [],
      comment: []
    });
    this.rejectForm.controls["comment"].setValidators(Validators.required);
    this.initErrors();
    this.formInitialized.emit(this.rejectForm);
    this.rejectForm.valueChanges.subscribe((data) => {
      this.errorMessages = this.formService.validateForm(this.rejectForm, this.errors);
    });
  }

  initErrors() {
    this.errors.push(this.helperService.buildError("comment", "Comments - This field is required", "required"));
  }

  rejectAction() {
    let form = this.rejectForm;
    this.formService.validateFormFields(form);
    if (!form.valid) {
      this.invalidForm = true;
      this.errorMessages = this.formService.validateForm(this.rejectForm, this.errors);
      setTimeout(() => { this.alertDiv.nativeElement.scrollIntoView() }, 500);
    }
    else {
      let reqBody = { "action": "reject", "data": { "comment": this.rejectForm.get('comment').value } };
      let endPoint = "tasks/" + this._task.taskId + "/complete";
      this.dealService.postForm(this._deal.id, endPoint, reqBody).subscribe(
        data => {
          this.completeAction();
        }, error => {
          this.errorService.show(error.error.metadata.error);
        })
    }
  }

  closePopup() {
    this.dialogRef.close();
  }

  completeAction() {
    this.dialogAllRef.closeAll();
  }

}