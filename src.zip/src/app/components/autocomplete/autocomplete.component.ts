import { Component, OnInit, Input } from '@angular/core';
import { FormControl } from '@angular/forms';
import { HelperService } from 'src/app/services/helper.service';
import { Observable } from 'rxjs';
import {map, startWith} from 'rxjs/operators';

@Component({
  selector: 'billing-autocomplete',
  templateUrl: './autocomplete.component.html',
  styleUrls: ['./autocomplete.component.scss']
})
export class AutocompleteComponent implements OnInit {

  @Input()
  options: any[] = []; // dropdown options
  @Input()
  optionKeyProp: string; // dropdown options
  @Input()
  optionValueProp: string; // dropdown options
  @Input()
  placeholder: string;
  @Input()
  autoCompleteCtrl: FormControl;
  @Input()
  errorMsg: string;
  @Input()
  readOnly: boolean = false;
  filteredOptions: Observable<any[]>;

  constructor(private helperService: HelperService) { }

  ngOnInit() {
  }

  ngOnChanges() {
    this.filteredOptions = this.autoCompleteCtrl.valueChanges
      .pipe(
        startWith(''),
        map(state => state ? this.filterOptions(state) : this.options.slice())
      );
  }

  getLabel(key: any) {
    let option = this.helperService.find(this.options, this.optionKeyProp, key);
    return option ? option[this.optionValueProp] : '';
  }

  // Autocomplete display function
  displayFn = (key) => {
    let selectedOption = this.helperService.find(this.options, this.optionKeyProp, key);
    return selectedOption ? selectedOption.name : undefined;
  }

  private filterOptions(value: string): any[] {
    const filterValue = value.toLowerCase();
    return this.options.filter(option => option[this.optionValueProp].toLowerCase().indexOf(filterValue) === 0);
  }


}
