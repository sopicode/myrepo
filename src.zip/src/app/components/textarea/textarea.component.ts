import { Component, OnInit, Input, HostListener, TemplateRef } from '@angular/core';
import { FormControl } from '@angular/forms';

@Component({
  selector: 'billing-textarea',
  templateUrl: './textarea.component.html',
  styleUrls: ['./textarea.component.scss']
})
export class TextareaComponent implements OnInit {

  @Input()
  placeholder: string;
  @Input()
  maxlength: number;
  @Input()
  textareaCtrl: FormControl;
  @Input()
  optional: boolean = false;
  @Input()
  readOnly: boolean = false;
  @Input()
  hideLabelIfReadOnly: boolean = false;
  @Input()
  errorTemplate: TemplateRef<any>;
  @Input()
  pattern:string;

  constructor() { }

  ngOnInit() {
  }

  onBlur() {
    let value: any = this.textareaCtrl.value;
    if (value != null && typeof value === 'string' && value.length==1) {
      value = value.trim();
      this.textareaCtrl.setValue(value);
    }
  }

}
