import { Component, OnInit, Input, Output, EventEmitter, ChangeDetectionStrategy, Inject, ViewEncapsulation } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Deal } from 'src/app/models/deal';
import { HelperService } from 'src/app/services/helper.service';
import { BillingAccount } from 'src/app/models/billing-account';
import { MatDialog, MatDialogConfig } from "@angular/material";
import { AccountDetailComponent } from '../account-detail/account-detail.component';
import { Wizard } from 'src/app/models/wizard';
import { DealService } from 'src/app/services/deal.service';
import { FormService } from 'src/app/services/form.service';
import { ErrorService } from 'src/app/services/error.service';
import { Task } from 'src/app/models/task';
import { forkJoin } from 'rxjs';

@Component({
  selector: 'billing-account',
  templateUrl: './account.component.html',
  styleUrls: ['./account.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AccountComponent implements OnInit {

  @Input() deal: Deal;
  @Input() billingAccount: BillingAccount;
  @Input() legalEntities: any;
  @Input() selected: boolean;
  @Input() showDelete: boolean;
  @Input() index: number;
  @Input() accountForm: FormGroup;
  @Input() wizard: Wizard;
  @Input() readOnly: boolean;
  @Input() isNewBilling: boolean;
  @Input() _showDuplicateBtn: boolean;
  @Input() prorationRules: any[];
  @Input() feeAccrlMethods: any[];
  @Input() feeBillingFrequencies: any[];
  @Input() prepaidFees: any[];
  @Input() billingCurrencies: any[];
  @Input() costCenters: any[];
  @Input() accountBillingFrequencies: any[] = [];
  @Input() splBillinglegalEntities: any[] = [];
  @Input() copybillingAccounts: BillingAccount[] = [];

  @Output() deleteAccount = new EventEmitter();
  @Output() selectAccount = new EventEmitter();
  @Output() accountUpdate = new EventEmitter();
  @Output() duplicateAccount = new EventEmitter();


  _selectedLegalEntityLbl: string;
  _hasMissingDetails: boolean;
  _showViewUpdateBtn: boolean;
  askConfirmation: boolean;
  readOnlyForReject: boolean = false;
  _task: Task;

  mandatoryDetails = ["partyId",
    "currencyCd",
    "costCenterCode",
    "feeScheduleMatchIndctr",
    "billingKey",
    "acctShortName",
    "acctLongName",
    "billDay",
    "onetimeBillingIndctr",
    "billingStartDate",
    "nextBillDate",
    "initInvcRqrdIndctr"];

  constructor(private helperService: HelperService, private _fb: FormBuilder, private dialog: MatDialog, private dealService: DealService, @Inject("task") private task, private formService: FormService, private errorService: ErrorService) {
    this._task = Task.fromJSON(task);
  }


  ngOnInit() {
    if (this.billingAccount.partyId) {
      let selectedLegalEntity = this.helperService.find(this.legalEntities, "id", this.billingAccount.partyId);
      this._selectedLegalEntityLbl = selectedLegalEntity ? selectedLegalEntity.externalLegalEntityId + " " + selectedLegalEntity.legalName : "";
    }
    this._hasMissingDetails = this.checkForMissingDetails();
    // when one time bill and close is false, cyclical invoice distribution is mandatory
    if (this.billingAccount.onetimeBillingIndctr == false && this.billingAccount.cyclicalInvcDstrbtn == null) {
      this._hasMissingDetails = true;
    }
    if (this.billingAccount.initInvcRqrdIndctr && this.billingAccount.initInvcDstrbtn == null) {
      this._hasMissingDetails = true;
    }
    if (!this.billingAccount.roles || this.billingAccount.roles.length == 0) {
      this._hasMissingDetails = true;
    }
    if (null != this._task.variables.rejectReason && this._task.variables.rejectReason != "Incorrect request type" && !this._task.variables.isApproveTask) {
      this.readOnlyForReject = true;
    }
    this._showViewUpdateBtn = this.showViewUpdateBtn();
  }


  checkForMissingDetails() {
    return this.mandatoryDetails.reduce(function (missing, property) {
      return missing || (this.billingAccount[property] == null);
    }.bind(this), false);
  }

  showViewUpdateBtn(): boolean {
    return this.billingAccount.billingKey && this.billingAccount.acctShortName && this.billingAccount.acctLongName && this.billingAccount.id != null;
  }

  deleteAcct() {
    if (this.isNewBilling) {
      this.askConfirmation = true;
    }
    else {
      this.deleteBillingAccount();
    }
  }

  deleteBillingAccount() {
    this.errorService.hide();
    this.deleteAccount.emit(this.index);
  }

  ignoreDelete() {
    this.askConfirmation = false;
  }

  selectAcct() {
    this.selectAccount.emit(this.index);
  }

  openAccountDetailsForm(add?: boolean) {
    this.errorService.hide();
    /* open the account details form only if there are no errors
      Billing short name unique errors may occur */
    let task = Task.fromJSON(this.task);
    let dealId = this.deal.id;
    let billingRequestId = task.variables.billingRequestId;
    let reqBody = {};
    let data = [];
    let accDetails: any = {};
    if (add) {
      accDetails.acctShortName = this.accountForm.get('acctShortName').value;
      accDetails.acctLongName = this.accountForm.get('acctLongName').value;
      accDetails.billingKey = this.accountForm.get('billingKey').value;
      accDetails.action = "add";
    } else {
      accDetails.action = "update";
      this.formService.collectData(this.accountForm, accDetails);
    }
    data.push(accDetails);
    this.wizard.action = "addAccountDetails";
    reqBody["wizard"] = Wizard.toJSON(this.wizard);
    reqBody["data"] = data;
    let endPoint;
    let billingDataEndPoint;
    let requestType;
    /*The below check is to fetch details from snapshot table when billing status is sent to billing*/
    let billingStatus = task.variables && task.variables.billingStatus ? task.variables.billingStatus : '';
    if (!this.readOnly) {
      endPoint = "billing-requests/" + billingRequestId + "/billing-account-details";
      requestType = this.dealService.postForm(dealId, endPoint, reqBody);
      requestType.subscribe(
        data => {
          if (add && this.billingAccount.isCopyAccount) {
            this.copybillingAccounts.splice(this.copybillingAccounts.indexOf(this.billingAccount), 1);
            this.copyAccountDetails();
          }
          billingDataEndPoint = dealId + "/billing-requests/" + billingRequestId + "/billing-account-for-billingKey?billingKey=" + this.accountForm.get('billingKey').value;
          if (this.billingAccount.duplicateAccountKey) {
            billingDataEndPoint = dealId + "/billing-account-for-billingKey?billingKey=" + this.accountForm.get('billingKey').value;
            let billingDuplicateEndPoint = dealId + "/billing-requests/" + billingRequestId + "/duplicate-account-for-billingKey?billingKey=" + this.billingAccount.duplicateAccountKey;
            this.openBillingAccountDetailsPopup(billingDataEndPoint, accDetails, billingDuplicateEndPoint);
          }
          else {
            this.openBillingAccountDetailsPopup(billingDataEndPoint, accDetails);
          }
        }, error => {
          this.errorService.show(error.error.metadata.error);
        })
    }
    else {
      let billingKey = this.accountForm.get('billingKey').value;
      if ("Sent To Billing" != billingStatus && "Billing Success" != billingStatus) {
        billingDataEndPoint = dealId + "/billing-requests/" + billingRequestId + "/billing-account-for-billingKey?billingKey=" + billingKey;
        this.openBillingAccountDetailsPopup(billingDataEndPoint, accDetails);
      }
      else {
        billingDataEndPoint = dealId + "/billing-requests/" + billingRequestId + "/billing-account-snapshot-for-billingKey?billingKey=" + billingKey;
        this.openBillingAccountDetailsPopup(billingDataEndPoint, accDetails);
      }
    }
  }

  copyAccountDetails() {
    for (let key of Object.keys(this.billingAccount)) {
      let propertyKey: string = key;
      if (Array.isArray(this.billingAccount[key])) {
        let arr = this.billingAccount[key];
        for (let i = 0; i < arr.length; i++) {
          for (let k of Object.keys(arr[i])) {
            let pKey: string = k;
            if (pKey == '_advanceOrArrearsCode') {
              let value = this.helperService.filterByKey(this.feeAccrlMethods, "name", arr[i][k])[0];
              this.setAccountArrayProperty(key, k, value, i);
            }
            else if (pKey == '_billingFrequencyCode') {
              let value = this.helperService.filterByKey(this.feeBillingFrequencies, "name", arr[i][k])[0];
              this.setAccountArrayProperty(key, k, value, i);
            }
            else if (pKey == '_prorationRuleCode') {
              let value = this.helperService.filterByKey(this.prorationRules, "name", arr[i][k])[0];
              this.setAccountArrayProperty(key, k, value, i);
            }
            else if (pKey == '_upfrontOrPrepaidFees') {
              let value = this.helperService.filterByKey(this.prepaidFees, "name", arr[i][k])[0];
              this.setAccountArrayProperty(key, k, value, i);
            }
          }
        }
      }
      else {
        if (propertyKey == '_billingFrequency') {
          let freq = this.helperService.filterByKey(this.accountBillingFrequencies, "name", this.billingAccount[propertyKey])[0];
          this.setAccountProperty(propertyKey, freq);
        }
        if (propertyKey == '_costCenterCode') {
          let curr = this.helperService.filterByKey(this.costCenters, "name", this.billingAccount[propertyKey])[0];
          this.setAccountProperty(propertyKey, curr);
        }
      }
    }
  }

  duplicateAccountDetails() {
    this.duplicateAccount.emit(this.billingAccount);
  }

  openBillingAccountDetailsPopup(billingDataEndPoint: string, accDetails: any, billingDuplicateEndPoint?: string) {
    if (this.billingAccount.duplicateAccountKey) {
      this.openDuplicateAccountDetailsPopUp(billingDataEndPoint, accDetails, billingDuplicateEndPoint);
    }
    else {
      this.dealService.getFormData(billingDataEndPoint).subscribe(
        billingData => {
          let billingAccountDetails = BillingAccount.fromJSON(billingData.data[0]);
          if (this.billingAccount.isCopyAccount) {
            this.setAccountDetails(accDetails, billingAccountDetails);
          }
          else {
            this.billingAccount = billingAccountDetails;
          }
          this.openDialog();
        });
    }
  }

  openDuplicateAccountDetailsPopUp(billingDataEndPoint: string, accDetails: any, billingDuplicateEndPoint?: string) {
    //GET call for getting the id for duplicated account
    let getBillingAccountIdDetails = this.dealService.getFormData(billingDataEndPoint);
    //GET call for getting the account details for duplicated account
    let getDuplicateAccountDetails = this.dealService.getFormData(billingDuplicateEndPoint);
    let billingAccountIdDetails, duplicateAccountDetails;
    forkJoin(getBillingAccountIdDetails, getDuplicateAccountDetails).subscribe((results: any[]) => {
      billingAccountIdDetails = results[0].data[0];
      duplicateAccountDetails = results[1].data[0];
      if (billingAccountIdDetails && duplicateAccountDetails) {
        this.billingAccount = BillingAccount.fromJSON(duplicateAccountDetails);
        this.setAccountDetails(accDetails, billingAccountIdDetails);
        this.openDialog();
      }
    });
  }

  setAccountDetails(accDetails: any, billingAccountIdDetails: BillingAccount) {
    this.billingAccount.acctLongName = accDetails.acctLongName;
    this.billingAccount.acctShortName = accDetails.acctShortName;
    this.billingAccount.billingKey = accDetails.billingKey;
    this.billingAccount.id = billingAccountIdDetails.id;
  }

  openDialog() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.autoFocus = false;
    dialogConfig.hasBackdrop = true;
    dialogConfig.disableClose = true;
    dialogConfig.panelClass = ['billingAcctDetPopup', 'billing'];
    dialogConfig.data = { "splBillinglegalEntities": this.splBillinglegalEntities, "accountBillingFrequencies": this.accountBillingFrequencies, "costCenters": this.costCenters, "billingCurrencies": this.billingCurrencies, "prepaidFees": this.prepaidFees, "feeBillingFrequencies": this.feeBillingFrequencies, "prorationRules": this.prorationRules, "feeAccrlMethods": this.feeAccrlMethods, "billingAccount": this.billingAccount, "deal": this.deal, "wizard": this.wizard, "readOnly": this.readOnly, "isNewBilling": this.isNewBilling };
    dialogConfig.maxWidth = '99vw';
    dialogConfig.width = '96vw';
    let dialogRef = this.dialog.open(AccountDetailComponent, dialogConfig);
    dialogRef.afterClosed().subscribe(data => {
      this.accountUpdate.emit();
    });
  }

  setAccountProperty(propertyKey: string, value: any) {
    if (value) {
      this.billingAccount[propertyKey] = value.code;
    }
    else {
      this.billingAccount[propertyKey] = null;
    }
  }

  setAccountArrayProperty(key: string, propertyKey: string, value: any, index: number) {
    if (value) {
      this.billingAccount[key][index][propertyKey] = value.code;
    }
    else {
      this.billingAccount[key][index][propertyKey] = null;
    }
  }


}
