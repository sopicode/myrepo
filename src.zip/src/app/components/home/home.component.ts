import {
  Component, OnInit, Inject, ViewChild,
  ViewContainerRef,
  ComponentFactoryResolver,
  ElementRef
} from '@angular/core';
import { forkJoin } from "rxjs";
import { MatDialogRef, MatDialog, MatDialogConfig } from "@angular/material";
import { DealService } from './../../services/deal.service';
import { PartiesService } from './../../services/parties.service';
import { ReferencesService } from './../../services/references.service';
import { HelperService } from './../../services/helper.service';
import { Deal } from 'src/app/models/deal';
import { Task } from 'src/app/models/task';
import { FormDetail } from 'src/app/models/form-detail';
import { RequestDetailsComponent } from '../request-details/request-details.component';
import { CustomerContactInformationComponent } from '../customer-contact-information/customer-contact-information.component';
import { ContactInformationComponent } from '../contact-information/contact-information.component';
import { AccountsComponent } from '../accounts/accounts.component';
import { DocumentsComponent } from '../documents/documents.component';
import { SpecialInstructionsComponent } from '../special-instructions/special-instructions.component';
import { Wizard } from 'src/app/models/wizard';
import { TeamComponent } from '../team/team.component';
import { SummaryComponent } from '../summary/summary.component';
import { FormService } from 'src/app/services/form.service';
import { AdditionalBillingDetailsComponent } from '../additional-billing-details/additional-billing-details.component';
import { ManualBillingComponent } from '../manual-billing/manual-billing.component';
import { BillingKeyDetailsComponent } from '../billing-key-details/billing-key-details.component';
import { RejectCommentsComponent } from '../reject-comments/reject-comments.component';
import { ErrorService } from 'src/app/services/error.service';
import { DataMismatchDetailsComponent } from '../data-mismatch-details/data-mismatch-details.component';

@Component({
  selector: 'billing-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
  host: { "class": "billing" }
})
export class HomeComponent implements OnInit {

  _deal: Deal; // holds deal informations
  _task: Task; // holds task information
  _wizard: Wizard;
  private _formDetails: FormDetail[] = []; // hold all form details
  private _formDetail: FormDetail; // hold current form detail
  riskRatingCode: string;
  dealTypeName: string;
  dealRegionName: string;
  majorProductTypeSource: string;
  componentRef: any;
  errorMessages: string[] = [];
  invalidForm: boolean;
  showFooter: boolean = false;
  lockData: any = {};

  @ViewChild('container', { read: ViewContainerRef }) entry: ViewContainerRef;
  @ViewChild('alertDiv') alertDiv: ElementRef;

  constructor(public dialogRef: MatDialogRef<HomeComponent>,
    private dealService: DealService, private helperService: HelperService,
    private partiesService: PartiesService, private referencesService: ReferencesService,
    @Inject("task") private task, private resolver: ComponentFactoryResolver,
    private formService: FormService, @Inject("unmountFunc") private unmountFunc, private dialog: MatDialog, private errorService: ErrorService) {
    this._task = Task.fromJSON(task);
    this.initializeFormDetails();
    this._formDetail = this.helperService.find(this._formDetails, "key", this._task.formKey);
    this.populateWizard();
  }

  ngOnInit() {
    let dealId = this._task.id;
    let billingRequestId = this._task.variables.billingRequestId;
    let dealInfoObs = this.dealService.getDealInformation(dealId);
    let ragRatingObs = this.dealService.getRagRating(dealId);
    let dealTypeObs = this.referencesService.getDealTypes();
    let dealRegionObs = this.partiesService.getDealRegionUrl();
    let reqDetails = this.dealService.getFormData(dealId + "/billing-requests/" + billingRequestId + "/billing-request-details");
    forkJoin(dealInfoObs, ragRatingObs, dealTypeObs, dealRegionObs, reqDetails).subscribe((results: any[]) => {
      this._deal = results[0].data ? Deal.fromJSON(results[0].data.deal) : null;
      this.riskRatingCode = results[1].data ? results[1].data.riskRatingCode : null;
      if (this._deal) {
        let dealType = this.helperService.find(results[2].data, "code", this._deal.dealTypeCode);
        if (dealType) {
          this.dealTypeName = dealType.name;
        }
        let dealRegion = this.helperService.find(results[3].data, "id", this._deal.regionId);
        if (dealRegion) {
          this.dealRegionName = dealRegion.name;
        }
        if (this._deal.productGroupId && this._deal.majorProductId) {
          this.referencesService.getMajorProducts(this._deal.productGroupId, this._deal.majorProductId).subscribe(
            data => {
              this.majorProductTypeSource = data.data;
            });
        }
      }
      if (this._formDetail.dataSource) {
        this.fetchFormData(this._formDetail.dataSource);
      }
      // Manual Billing Flow
      if (this._formDetail.key == "manual-billing-request") {
        this.createComponent();
        this.showFooter = true;
      }
      let reqDetail = results[4].data;
      if (reqDetail) {
        this._formDetails = [];
        this.updateFormDetails(reqDetail.billingTypeCode);
      }
    });
  }

  initializeFormDetails() {
    let billingRequestId = this._task.variables.billingRequestId;
    let dealId = this._task.id;
    let billingKey = this._task.variables.billingKey;
    let isApproveTask = this._task.variables.isApproveTask;
    let specialBillingIndicator = this._task.variables.specialBillingLegalEntity;
    this._formDetails.push({
      "key": "billing-request-details",
      "component": RequestDetailsComponent,
      "menuLabel": "Billing Request Details",
      "navigationEndPoint": "billing-request-details",
      "dataSource": this.getRequestDetailsDataSource(dealId, billingRequestId),
      "renderNext": true
    });
    this._formDetails.push({
      "key": "customer-contact-information",
      "component": CustomerContactInformationComponent,
      "menuLabel": "Customer & Consolidated Billing",
      "navigationEndPoint": "customer-deal-parties",
      "dataSource": this.getCustomerContactDataSource(dealId, billingRequestId),
      "renderNext": true,
      "renderBack": true
    });
    this._formDetails.push({
      "key": "billing-contact-information",
      "component": ContactInformationComponent,
      "menuLabel": "Billing Contact",
      "navigationEndPoint": "billing-requests/" + billingRequestId + "/billing-contacts",
      "dataSource": this.getBillingContactDataSource(dealId, billingRequestId),
      "renderNext": true,
      "renderBack": true
    });
    this._formDetails.push({
      "key": "billing-accounts",
      "component": AccountsComponent,
      "menuLabel": "Billing Accounts",
      "navigationEndPoint": "billing-requests/" + billingRequestId + "/billing-account-details",
      "dataSource": this.getBillingAccountsDataSource(dealId, billingRequestId),
      "renderNext": true,
      "renderBack": true
    });
    this._formDetails.push({
      "key": "additional-billing-details",
      "component": AdditionalBillingDetailsComponent,
      "menuLabel": "Additional Billing Details",
      "navigationEndPoint": "billing-requests/" + billingRequestId + "/additional-billing-details",
      "dataSource": this.getAdditionalBillingDetailsDataSource(dealId, billingRequestId),
      "renderNext": true,
      "renderBack": true
    });
    this._formDetails.push({
      "key": "billing-team",
      "component": TeamComponent,
      "menuLabel": "Billing Team",
      "navigationEndPoint": "billing-requests/" + billingRequestId + "/billing-team",
      "dataSource": this.getBillingTeamDataSource(dealId, billingRequestId),
      "renderNext": true,
      "renderBack": true
    });
    this._formDetails.push({
      "key": "billing-documents",
      "component": DocumentsComponent,
      "menuLabel": "Documents",
      "navigationEndPoint": "billing-requests/" + billingRequestId +"/billing-documents",
      "dataSource": this.getBillingDocumentsDataSource(dealId,billingRequestId),
      "renderNext": true,
      "renderBack": true
    });
    this._formDetails.push({
      "key": "special-instructions ",
      "component": SpecialInstructionsComponent,
      "menuLabel": "Special Billing Instructions",
      "navigationEndPoint": "billing-special-instruction",
      "dataSource": this.getBillingInstructionsDataSource(dealId, billingRequestId),
      "renderNext": true,
      "renderBack": true
    });
    this._formDetails.push({
      "key": "data-mismatch-details",
      "component": DataMismatchDetailsComponent,
      "menuLabel": "Data Mismatch Details",
      "navigationEndPoint": "billingRequestId/" + billingRequestId + "/data-mismatch-details",
      "dataSource": this.getDataMismatchDetailDataSource(dealId, billingRequestId, specialBillingIndicator),
      "renderNext": true,
      "renderBack": true
    });
    this._formDetails.push({
      "key": "billing-summary",
      "component": SummaryComponent,
      "menuLabel": "Summary",
      "navigationEndPoint": "billing-summary",
      "dataSource": this.getBillingSummaryDataSource(dealId, billingRequestId, specialBillingIndicator),
      "renderSubmit": isApproveTask ? false : true,
      "renderBack": isApproveTask ? false : true,
      "renderApprove": isApproveTask ? true : false,
      "renderReject": isApproveTask ? true : false,
      "hideMenu": isApproveTask ? true : false
    });
    this._formDetails.push({
      "key": "manual-billing-request",
      "component": ManualBillingComponent,
      "navigationEndPoint": "tasks/" + this._task.taskId + "/manual-billing-task",
      "renderSubmit": true,
      "renderCancel": true,
      "hideMenu": true
    });
    this._formDetails.push({
      "key": "billing-key-details",
      "component": BillingKeyDetailsComponent,
      "dataSource": this.getBillingKeysDataSource(dealId, billingKey),
      "navigationEndPoint": "billing-account-details",
      "renderSubmit": true,
      "renderCancel": true,
      "hideMenu": true
    });
  }


  initializeExistingBillingKeyFormDetails() {
    let billingRequestId = this._task.variables.billingRequestId;
    let dealId = this._task.id;
    let isApproveTask = this._task.variables.isApproveTask;
    let specialBillingIndicator = this._task.variables.specialBillingLegalEntity;
    let billingKey = this._task.variables.billingKey;
    this._formDetails.push({
      "key": "billing-request-details",
      "component": RequestDetailsComponent,
      "menuLabel": "Billing Request Details",
      "navigationEndPoint": "billing-request-details",
      "dataSource": this.getRequestDetailsDataSource(dealId, billingRequestId),
      "renderNext": true
    });
    this._formDetails.push({
      "key": "billing-team",
      "component": TeamComponent,
      "menuLabel": "Billing Team",
      "navigationEndPoint": "billing-requests/" + billingRequestId + "/billing-team",
      "dataSource": this.getBillingTeamDataSource(dealId, billingRequestId),
      "renderNext": true,
      "renderBack": true
    });
    this._formDetails.push({
      "key": "billing-documents",
      "component": DocumentsComponent,
      "menuLabel": "Documents",
      "navigationEndPoint": "billing-requests/" + billingRequestId +"/billing-documents",
      "dataSource": this.getBillingDocumentsDataSource(dealId,billingRequestId),
      "renderNext": true,
      "renderBack": true
    });
    this._formDetails.push({
      "key": "special-instructions ",
      "component": SpecialInstructionsComponent,
      "menuLabel": "Special Billing Instructions",
      "navigationEndPoint": "billing-special-instruction",
      "dataSource": this.getBillingInstructionsDataSource(dealId, billingRequestId),
      "renderNext": true,
      "renderBack": true
    });
    this._formDetails.push({
      "key": "billing-summary",
      "component": SummaryComponent,
      "menuLabel": "Summary",
      "navigationEndPoint": "billing-summary",
      "dataSource": this.getBillingSummaryDataSource(dealId, billingRequestId, specialBillingIndicator),
      "renderSubmit": isApproveTask ? false : true,
      "renderBack": isApproveTask ? false : true,
      "renderApprove": isApproveTask ? true : false,
      "renderReject": isApproveTask ? true : false,
      "hideMenu": isApproveTask ? true : false
    });
    this._formDetails.push({
      "key": "manual-billing-request",
      "component": ManualBillingComponent,
      "navigationEndPoint": "tasks/" + this._task.taskId + "/manual-billing-task",
      "renderSubmit": true,
      "renderCancel": true,
      "hideMenu": true
    });
    this._formDetails.push({
      "key": "billing-key-details",
      "component": BillingKeyDetailsComponent,
      "dataSource": this.getBillingKeysDataSource(dealId, billingKey),
      "navigationEndPoint": "billing-account-details",
      "renderSubmit": true,
      "renderCancel": true,
      "hideMenu": true
    });
  }


  createComponent(data?: any[]) {
    const factory = this.resolver.resolveComponentFactory(this._formDetail.component);
    this.componentRef = this.entry.createComponent(factory);
    let instance = this.componentRef.instance;
    this.componentRef.instance["deal"] = this._deal;
    this.componentRef.instance["data"] = data;
    this.componentRef.instance["wizard"] = this._wizard;
    if (instance.formInitialized) {
      instance.formInitialized.subscribe($event => {
        let form = $event;
        form.valueChanges.subscribe((data) => {
          this.errorMessages = this.formService.validateForm(form, instance.errors);
        });
      });
    }
    if (instance.billingTypeEvent) {
      instance.billingTypeEvent.subscribe($event => {
        this._formDetails = [];
        this.updateFormDetails($event);
      });
    }
  }

  updateFormDetails(billingTypeCode: string) {
    if (billingTypeCode == 'E') {
      this.initializeExistingBillingKeyFormDetails();
    }
    else {
      this.initializeFormDetails();
    }
  }

  clearError() {
    this.errorMessages = [];
    this.invalidForm = false;
  }

  goto(data: any) {
    this.clearError();
    this.showFooter = false;
    this.entry.clear();
    let reqBody = {};
    let formDetail = data.formDetail;
    this._wizard.formKey = formDetail.key; //pass selected form key in req body
    this._wizard.action = data.action;
    reqBody["wizard"] = Wizard.toJSON(this._wizard);
    reqBody["data"] = null;
    // pass previous selected navigation end point
    this.dealService.postForm(this._deal.id, this._formDetail.navigationEndPoint, reqBody).subscribe(
      data => {
        this._wizard.formKey = data.data.wizard.formKey;
        this._formDetail = this.helperService.find(this._formDetails, "key", this._wizard.formKey);
        this.fetchFormData(this._formDetail.dataSource);
      })
  }

  goNext() {
    this.showFooter = false;
    let cmpInstance = this.componentRef.instance;
    let form = cmpInstance.detailsForm;
    let data: any = {};
    let valid = true;
    if (form && !form.disabled) {
      this.formService.validateFormFields(form);
      valid = form.valid;
    }
    if (valid) {
      this.invalidForm = false;
      if (cmpInstance.getSubmissionData) {
        data = cmpInstance.getSubmissionData();
      } else {
        this.formService.collectData(form, data);
      }
      let reqBody = {};
      this._wizard.action = "next";
      reqBody["wizard"] = Wizard.toJSON(this._wizard);
      if (this._wizard.formKey == 'data-mismatch-details') {
        reqBody["data"] = data.dataMismatchDetails;
      }
      else {
        reqBody["data"] = data;
      }
      if(cmpInstance.getSearchExistingKeyData)
      {
        let endPoint="search-billing-accounts";
        let formData=cmpInstance.getSearchExistingKeyData();
        if(formData)
        {
          this.searchExisting(reqBody,endPoint,formData);
        }
        else{
          this.postFormData(reqBody);
        }
      }
      else{
        this.postFormData(reqBody);
      }
      
    } else {
      this.showFooter = true;
      this.invalidForm = true;
      if (this._wizard.formKey == 'data-mismatch-details') {
        this.errorMessages = [];
        this.errorMessages.push('Data Mismatch: Reason for not selecting the Legal Entity / CT Role is mandatory with appropriate comments.');
      }
      else {
        this.errorMessages = this.formService.validateForm(form, cmpInstance.errors);
      }
      setTimeout(() => { this.alertDiv.nativeElement.scrollIntoView() }, 500);
    }
  }

  searchExisting(reqBody:any,endPoint: any,formData:any)
  {
    this.dealService.postForm(null, endPoint, formData).subscribe(
      data => {
        if (data.data.accountLookupData == null || (data.data.accountLookupData != null && data.data.accountLookupData.length && data.data.accountLookupData.length >1)) {
              this.showErrorMessage('Invalid FiRRe Key. Please enter a valid Existing Billing Key.');
        }
        else {
          let accountStatus=data.data.accountLookupData[0].accountStatus;
          if(accountStatus=='Stopped'||accountStatus=='Closed')
          {
            this.showErrorMessage('Billing key with account status '+accountStatus+' cannot be selected.');
          }
          else{
            this.postFormData(reqBody);
          }
        }
      }, error => {
        this.errorService.show(error.error.metadata.error);
      });
  }

  showErrorMessage(msg:string)
  {
     this.showFooter = true;
     this.invalidForm = true;
     this.errorMessages = [];
     this.errorMessages.push(msg);
     setTimeout(() => { this.alertDiv.nativeElement.scrollIntoView() }, 500);
  }

  postFormData(reqBody:any)
  {
    this.dealService.postForm(this._deal.id, this._formDetail.navigationEndPoint, reqBody).subscribe(
        data => {
          this.entry.clear();
          this._wizard.formKey = data.data.wizard.formKey;
          this._formDetail = this.helperService.find(this._formDetails, "key", this._wizard.formKey);
          this.fetchFormData(this._formDetail.dataSource);
        }, error => {
          this.showFooter = true;
          setTimeout(() => { this.alertDiv.nativeElement.scrollIntoView() }, 500);
        })
  }

  approve() {
    let reqBody = { "action": "approve" };
    let endPoint = "tasks/" + this._task.taskId + "/complete";
    this.dealService.postForm(this._deal.id, endPoint, reqBody).subscribe(
      data => {
        this.closePopup();
      },
      error => {
        this.errorService.show(error.error.metadata.error);
      })
  }

  reject() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.autoFocus = false;
    dialogConfig.disableClose = true;
    dialogConfig.hasBackdrop = true;
    dialogConfig.width = '50vw';
    dialogConfig.panelClass = 'billing';
    dialogConfig.data = this._deal;
    this.dialog.open(RejectCommentsComponent, dialogConfig);
    this.dialog.afterAllClosed.subscribe(() => { this.unmountFunc() });
  }

  submit() {
    let reqBody = {};
    let valid = true;
    let cmpInstance = this.componentRef.instance;
    let form = cmpInstance.detailsForm;
    if (form) {
      this.formService.validateFormFields(form);
      valid = form.valid;
      this.formService.collectData(form, reqBody);
    } else {
      reqBody["data"] = {};
      this._wizard.action = "submit";
      reqBody["wizard"] = Wizard.toJSON(this._wizard);
    }
    if (valid) {
      this.invalidForm = false;
      // pass previous selected navigation end point
      this.dealService.postForm(this._deal.id, this._formDetail.navigationEndPoint, reqBody).subscribe(
        data => {
          this.closePopup();
        }, error => {
          this.showFooter = true;
          setTimeout(() => { this.alertDiv.nativeElement.scrollIntoView() }, 500);
        })
    } else {
      this.invalidForm = true;
      this.errorMessages = this.formService.validateForm(form, cmpInstance.errors);
      setTimeout(() => { this.alertDiv.nativeElement.scrollIntoView() }, 500);
    }
  }

  populateWizard() {
    this._wizard = new Wizard();
    this._wizard.dealId = this._task.id;
    this._wizard.processId = this._task.processInstanceId;
    this._wizard.taskId = this._task.taskId;
    this._wizard.formKey = this._task.formKey;
    this._wizard.action = "goto";
  }

  fetchFormData(dataSourceEndpoint: any[]): any {
    forkJoin(dataSourceEndpoint).subscribe((results: any[]) => {
      this.createComponent(results);
      this.showFooter = true;
    });
  }

  closePopup() {
    this.dialogRef.close();
  }

  // Request Details Data Source
  getRequestDetailsDataSource(dealId, billingRequestId) {
    return [
      this.dealService.getFormData(dealId + "/billing-requests/" + billingRequestId + "/billing-request-details"),
      this.dealService.getDealAssignments(dealId),
      this.partiesService.getSMUsers(),
      this.partiesService.getSMAssignerUsers(),
      this.referencesService.getProductGroups(),
      //this.dealService.getFormData(dealId + "/billing-requests/" + billingRequestId + "/billing-comments")
    ]
  }

  // Customer contact data source
  getCustomerContactDataSource(dealId, billingRequestId) {
    return [
      this.dealService.getFormData(dealId + "/billing-requests/" + billingRequestId + "/customer-deal-parties"),
      this.referencesService.getCountry()
    ]
  }

  // Billing contact data source
  getBillingContactDataSource(dealId, billingRequestId) {
    return [
      this.dealService.getFormData(dealId + "/billing-requests/" + billingRequestId + "/billing-parties"),
      this.referencesService.getPartyRoleTypes(),
      this.dealService.getFormData(dealId + "/billing-requests/" + billingRequestId + "/billing-request-details"),
      this.referencesService.getCountry()
    ]
  }

  // Billing accounts data source
  getBillingAccountsDataSource(dealId, billingRequestId) {
    return [
      this.dealService.getFormData(dealId + "/billing-requests/" + billingRequestId + "/billing-account-details"),
      this.dealService.getLegalEntities(dealId),
      this.dealService.getFormData(dealId + "/billing-requests/" + billingRequestId + "/billing-request-details")
    ]
  }

  // Additional Billing details data source
  getAdditionalBillingDetailsDataSource(dealId, billingRequestId) {
    return [
      this.dealService.getFormData(dealId + "/billing-requests/" + billingRequestId + "/additional-billing-details"),
      this.dealService.getFormData(dealId + "/billing-requests/" + billingRequestId + "/billing-request-details"),
      this.dealService.getFormData(dealId + "/billing-requests/" + billingRequestId + "/billing-account-details"),
      this.dealService.getFormData(dealId + "/billing-requests/" + billingRequestId + "/customer-deal-parties"),
      this.referencesService.getFeeTemplate(),
      this.referencesService.getwithholdingTaxBearerCode(),
      this.referencesService.getwithHoldingTypeCode(),
      this.referencesService.getCountry(),
      this.dealService.getLegalEntities(dealId)
    ]
  }

  // Billing team data source
  getBillingTeamDataSource(dealId, billingRequestId) {
    let groupType = this._task.variables && this._task.variables.specialBillingLegalEntity ? "SPCL_BILL" : "BILL";
    return [
      this.dealService.getFormData(dealId + "/billing-requests/" + billingRequestId + "/billing-team"),
      this.referencesService.getBillingTeamGroups(groupType)
    ]
  }

  // Billing documents data source
  getBillingDocumentsDataSource(dealId,billingRequestId) {
    return [
      this.dealService.getFormData(dealId + "/billing-requests/" + billingRequestId +"/billing-documents"),
      this.referencesService.getBillingDocumentTypes()
    ]
  }

  // Billing instructions data source
  getBillingInstructionsDataSource(dealId, billingRequestId) {
    return [
      this.dealService.getFormData(dealId + "/billing-requests/" + billingRequestId + "/billing-special-instruction"),
      this.dealService.getFormData(dealId + "/billing-requests/" + billingRequestId + "/billing-request-details")
    ]
  }

  // Data mismatch data source
  getDataMismatchDetailDataSource(dealId, billingRequestId, specialBillingIndicator) {
    return [
      this.dealService.getFormData(dealId + "/billing-requests/" + billingRequestId + "/billing-request-details"),
      this.dealService.getFormData(specialBillingIndicator ? dealId + "/billingRequestId/" + billingRequestId + "/data-mismatch-details?isSpecialBilling=" + specialBillingIndicator : dealId + "/billingRequestId/" + billingRequestId + "/data-mismatch-details")
    ]
  }


  // Billing keys details data source
  getBillingKeysDataSource(dealId, billingKey) {
    return [
      this.dealService.getBillingKeyComponentDetails(dealId, billingKey),
      this.dealService.getBillingKeyInvoiceDetails(dealId, billingKey)
    ]
  }

  //Billing summary data source
  getBillingSummaryDataSource(dealId, billingRequestId, specialBillingIndicator) {
    let groupType = this._task.variables && this._task.variables.specialBillingLegalEntity ? "SPCL_BILL" : "BILL";
    let billingStatus = this._task.variables && this._task.variables.billingStatus ? this._task.variables.billingStatus : '';
    let dataMismatchDetails = specialBillingIndicator ? dealId + "/billingRequestId/" + billingRequestId + "/data-mismatch-details?isSpecialBilling=" + specialBillingIndicator : dealId + "/billingRequestId/" + billingRequestId + "/data-mismatch-details";
    let dataMismatchDetailsView = specialBillingIndicator ? dealId + "/billingRequestId/" + billingRequestId + "/data-mismatch-details-view?isSpecialBilling=" + specialBillingIndicator : dealId + "/billingRequestId/" + billingRequestId + "/data-mismatch-details-view";
    if ("Sent To Billing" != billingStatus && "Billing Success" != billingStatus) {
      return [
        this.dealService.getFormData(dealId + "/billing-requests/" + billingRequestId + "/billing-request-details"),
        this.dealService.getDealAssignments(dealId),
        this.partiesService.getSMUsers(),
        this.partiesService.getSMAssignerUsers(),
        this.referencesService.getProductGroups(),
        this.dealService.getFormData(dealId + "/billing-requests/" + billingRequestId + "/customer-deal-parties"),
        this.referencesService.getCountry(),
        this.dealService.getFormData(dealId + "/billing-requests/" + billingRequestId + "/billing-parties"),
        this.referencesService.getPartyRoleTypes(),
        this.dealService.getFormData(dealId + "/billing-requests/" + billingRequestId + "/billing-account-details"),
        this.dealService.getLegalEntities(dealId),
        this.dealService.getFormData(dealId + "/billing-requests/" + billingRequestId + "/additional-billing-details"),
        this.dealService.getFormData(dealId + "/billing-requests/" + billingRequestId + "/billing-team"),
        this.referencesService.getBillingTeamGroups(groupType),
        this.dealService.getFormData(dealId + "/billing-requests/" + billingRequestId + "/billing-documents"),
        this.referencesService.getBillingDocumentTypes(),
        this.dealService.getFormData(dealId + "/billing-requests/" + billingRequestId + "/billing-special-instruction"),
        this.referencesService.getFeeTemplate(),
        this.referencesService.getwithholdingTaxBearerCode(),
        this.referencesService.getwithHoldingTypeCode(),
        this.dealService.getFormData(dealId + "/billing-requests/" + billingRequestId + "/billing-comments"),
        this.dealService.getFormData(dataMismatchDetails)
      ]
    } else {
      return [
        this.dealService.getFormData(dealId + "/billing-requests/" + billingRequestId + "/billing-snapshot-details"),
        this.dealService.getFormData(dealId + "/billing-requests/" + billingRequestId + "/billing-account-snapshot-details"),
        this.dealService.getFormData(dealId + "/billing-requests/" + billingRequestId + "/billing-documents-snapshot"),
        this.dealService.getDealAssignments(dealId),
        this.partiesService.getSMUsers(),
        this.partiesService.getSMAssignerUsers(),
        this.referencesService.getProductGroups(),
        this.referencesService.getCountry(),
        this.referencesService.getPartyRoleTypes(),
        this.dealService.getLegalEntities(dealId),
        this.referencesService.getBillingTeamGroups(groupType),
        this.referencesService.getBillingDocumentTypes(),
        this.referencesService.getFeeTemplate(),
        this.referencesService.getwithholdingTaxBearerCode(),
        this.referencesService.getwithHoldingTypeCode(),
        this.dealService.getFormData(dataMismatchDetailsView)
      ]
    }
  }

}