import { Component, OnInit, Input, Output, EventEmitter,ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'billing-client-error',
  templateUrl: './client-error.component.html',
  styleUrls: ['./client-error.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ClientErrorComponent implements OnInit {

  @Input() errorMessages: String[];
  @Input() hasCloseIcon: boolean = false;
  @Input() showTotalErrorCount: boolean = true;
  @Input() showErrorsAsList: boolean = true;

  @Output() closeClick = new EventEmitter();


  constructor() {

  }

  ngOnInit() {
  }

  close() {
    this.closeClick.emit();
  }


}
