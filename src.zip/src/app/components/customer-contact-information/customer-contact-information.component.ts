import { Component, OnInit, Input, Inject, EventEmitter, Output } from '@angular/core';
import { HelperService } from './../../services/helper.service';
import { Deal } from 'src/app/models/deal';
import { CustomerDetail } from 'src/app/models/customer-details';
import { ErrorService } from 'src/app/services/error.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'billing-customer-contact-information',
  templateUrl: './customer-contact-information.component.html',
  styleUrls: ['./customer-contact-information.component.scss']
})
export class CustomerContactInformationComponent implements OnInit {

  @Input() deal: Deal;
  @Input() data: any;
  @Input() readOnly: boolean;
  countryOfDomicile: string;
  selectedCustomer: any;
  singleCustomer: boolean = true;
  showAllCustomers: boolean = false;
  countryList: any;
  customers: CustomerDetail[];
  detailsForm: FormGroup;
  consolidatedBillingOptions: any[] = [];

  constructor(private helperService: HelperService, private errorService: ErrorService,
    private _fb: FormBuilder) {

  }

  extractCustomer() {
    let d = this.customers ? this.customers : null;
    if (d.length > 1) {
      let selectedCust = this.helperService.filterByKey(d, "isSelected", true);
      this.singleCustomer = false;
      // if there are no selected customers, show grid
      if (selectedCust && selectedCust.length > 0) {
        this.selectedCustomer = selectedCust[0];
      } else {
        this.showAllCustomers = true;
      }
    } else {
      this.selectedCustomer = d[0];
      this.singleCustomer = true;
    }
  }

  ngOnInit() {
    this.detailsForm = this._fb.group({
      consolidatedBillingIndicator: [{ value: false, disabled: true }, Validators.required]
    });
    this.customers = this.buildCustomer(this.data[0].data);
    this.extractCustomer();
    this.countryList = this.data[1].data;
    if (this.selectedCustomer) {
      let countryCode = this.selectedCustomer.country;
      let countrySource = this.helperService.find(this.countryList, "code", countryCode);
      if (countrySource) {
        this.countryOfDomicile = countrySource.name;
      }
    }
    //if there is no selected customer, then in summary page show empty customer
    if(this.readOnly && !this.selectedCustomer){
      this.selectedCustomer = new CustomerDetail();
    }
    this.getConsolidatedBillingOptions();
  }

  buildCustomer(customerList: any): CustomerDetail[] {
    let customer: CustomerDetail[] = [];
    if (Array.isArray(customerList)) {
      customerList.forEach((customers, index) => {
        let customerDetail: CustomerDetail = CustomerDetail.fromJSON(customers)
        customerDetail.position = index % 2 == 0 ? 'even' : 'odd';
        customer.push(customerDetail);
      });
      return customer;
    }
  }

  selectCustomer(data: any) {
    this.showAllCustomers = false;
    this.selectedCustomer = data;
    let countryCode = this.selectedCustomer.country;
    let countrySource = this.helperService.find(this.countryList, "code", countryCode);
    if (countrySource) {
      this.countryOfDomicile = countrySource.name;
    }
    this.errorService.hide();
  }

  changeCustomer() {
    this.showAllCustomers = true;
    this.selectedCustomer = null;
    this.errorService.hide();
  }

  getSubmissionData() {
    let data: any = null;
    if (this.selectedCustomer) {
      data = {};
      data.addressLine1 = this.selectedCustomer.addressLine1;
      data.addressLine2 = this.selectedCustomer.addressLine2;
      data.city = this.selectedCustomer.city;
      data.country = this.selectedCustomer.country;
      data.countryName = this.selectedCustomer.countryName;
      data.dealId = this.selectedCustomer.dealId;
      data.dealPartyRoleId = this.selectedCustomer.dealPartyRoleId;
      data.entitySubTypeCode = this.selectedCustomer.entitySubTypeCode;
      data.entitySubTypeDesc = this.selectedCustomer.entitySubTypeDesc;
      data.entityTypeCode = this.selectedCustomer.entityTypeCode;
      data.entityTypeDesc = this.selectedCustomer.entityTypeDesc;
      data.cid = this.selectedCustomer.cid;
      data.id = this.selectedCustomer.id;
      data.ipid = this.selectedCustomer.ipid;
      data.legalEntityIndicator = this.selectedCustomer.legalEntityIndicator;
      data.legalName = this.selectedCustomer.legalName;
      data.locationId = this.selectedCustomer.locationId;
      data.partyId = this.selectedCustomer.partyId;
      data.partyRoleId = this.selectedCustomer.partyRoleId;
      data.partyRoleTypeCode = this.selectedCustomer.partyRoleTypeCode;
      data.partyRoleTypeDescription = this.selectedCustomer.partyRoleTypeDescription;
      data.relationId = this.selectedCustomer.relationId;
      data.state = this.selectedCustomer.state;
      data.vat = this.selectedCustomer.vat;
      data.zip = this.selectedCustomer.zip;
      data.consolidatedBillingIndicator = this.detailsForm.get('consolidatedBillingIndicator').value;
    }
    return data;
  }

  getConsolidatedBillingOptions() {
    this.consolidatedBillingOptions.push(this.helperService.buildOption('Y', "Yes"));
    this.consolidatedBillingOptions.push(this.helperService.buildOption('N', "No"));
  }

}

