import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerContactInformationComponent } from './customer-contact-information.component';

describe('CustomerContactInformationComponent', () => {
  let component: CustomerContactInformationComponent;
  let fixture: ComponentFixture<CustomerContactInformationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomerContactInformationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerContactInformationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
