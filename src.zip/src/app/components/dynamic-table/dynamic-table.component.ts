import { Component, OnInit, Input, TemplateRef } from '@angular/core';
import { FormArray, FormGroup } from '@angular/forms';
import { Column } from 'src/app/models/column';

@Component({
  selector: 'billing-dynamic-table',
  templateUrl: './dynamic-table.component.html',
  styleUrls: ['./dynamic-table.component.scss']
})
export class DynamicTableComponent implements OnInit {

  @Input()
  rows: FormArray;
  @Input()
  row: FormGroup;
  @Input()
  columns: Column[];
  @Input()
  rowTemplate: TemplateRef<any>;
  @Input()
  hasAdd: boolean = true;
  @Input()
  hasDelete: boolean = true;

  constructor() { }

  ngOnInit() {
    if (this.hasAdd && this.rows.length == 0) {
      this.addRow();
    }
  }

  addRow() {
    this.rows.push(this.row);
  }

  removeRow(index: number) {
    this.rows.removeAt(index);
    if (this.rows.length == 0) {
      this.addRow();
    }
  }

}
