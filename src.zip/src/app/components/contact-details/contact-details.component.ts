import { Component, OnInit, Inject, Input, Output, EventEmitter } from '@angular/core';
import { ContactDetail } from 'src/app/models/contact-detail';

@Component({
  selector: 'billing-contact-details',
  templateUrl: './contact-details.component.html',
  styleUrls: ['./contact-details.component.scss']
})
export class ContactDetailsComponent implements OnInit {

  @Input() dataSource: any;
  @Input() partyId: number;
  @Output() selectContact = new EventEmitter();
  @Output() editContact = new EventEmitter();
  dealPartyName;
  columnsToDisplay = ["icon", "name", "firreAddressNumber", "acsNameKey", "eagleIntPartyId", "nexenClientId", "action"];
  columnsDisplayNames =
    {
      "icon": "",
      "name": "Contact Name/Title",
      "firreAddressNumber": "Firre Address Number",
      "acsNameKey": "ACS Name Key",
      "eagleIntPartyId": "EAGLE Interested Party ID",
      "nexenClientId": "NEXEN ID"
    };
  dialog: any;

  constructor() { }

  ngOnInit() {
  }

  ngOnChanges(){
  }


  selectContactDetail(data: any) {
    this.selectContact.emit(data);
  }

  viewEdit(data) {
    this.editContact.emit(data);
  }

}
