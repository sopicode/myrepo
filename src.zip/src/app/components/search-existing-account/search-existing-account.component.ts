import { Component, OnInit, Inject, ViewChild, ElementRef, Output, EventEmitter, ViewEncapsulation } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { HelperService } from 'src/app/services/helper.service';
import { Error } from 'src/app/models/error';
import { FormService } from 'src/app/services/form.service';
import { BillingExistingAccount } from 'src/app/models/billing-existing-account';
import { DealService } from 'src/app/services/deal.service';
import { ErrorService } from 'src/app/services/error.service';
import { Deal } from 'src/app/models/deal';
import { PartiesService } from 'src/app/services/parties.service';

@Component({
  selector: 'billing-search-existing-account',
  templateUrl: './search-existing-account.component.html',
  styleUrls: ['./search-existing-account.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class SearchExistingAccount implements OnInit {

  @ViewChild('alertDiv') alertDiv: ElementRef;

  deal: Deal;
  searchAccountForm: FormGroup;
  copyAccountCountForm: FormGroup;
  accountsFormArray: FormArray;
  numberOfAccountCopyOptions: any[] = [];
  errors: Error[] = [];
  errorMessages: string[] = [];
  invalidForm: boolean;
  accountCount: number;
  showSearchResult: boolean = false;
  selectedBillingKey: string;
  dialogTitle: string;
  buttonText: string;
  managerOptions: any[] = [];
  adminOptions: any[] = [];
  readOnly: boolean;
  displayNote: boolean;
  displayServerError: boolean = true;
  accountKey: string;
  isFromRequestDetails: boolean = false;
  existingAccountData: any[] = [];
  isExistingKeySelected: boolean = false;
  isAccountStatus: boolean = false;
  dataSource = [];
  warningMessage;
  columnsToDisplay = ['outputKey', 'shortName', 'cid', 'longName', 'manager', 'admin','accountStatus'];
  columnsDisplayNames =
    {
      "outputKey": "Billing Key",
      "shortName": "Short Name",
      "cid": "CID",
      "longName": "Long Name",
      "manager": "Manager",
      "admin": "Admin",
      "accountStatus":"Account Status"
    };

  columnsToDisplayIfFromRequestDetails = ['icon', 'outputKey','shortName','longName','fullName', 'cid', 'manager','admin','accountStatus'];
  columnsDisplayNamesIfFromRequestDetails =
    {
      "icon": "",
      "outputKey": "Billing Key",
      "shortName": "Short Name",
      "longName":"Full Name",
      "cid": "CID",
      "manager":"Manager",
      "admin": "Admin",
      "accountStatus": "Account Status",

    };

  constructor(private _fb: FormBuilder, private partiesService: PartiesService, private errorService: ErrorService, private dealService: DealService, private formService: FormService, private helperService: HelperService, @Inject(MAT_DIALOG_DATA) data, private dialogRef: MatDialogRef<SearchExistingAccount>) {
    this.accountCount = data.accountCount;
    this.deal = data.deal;
    this.dialogTitle = data.title;
    this.buttonText = data.buttonText;
    this.isFromRequestDetails = data.isFromRequestDetails;
    if (data.accountKey && data.isFromRequestDetails) {
      this.accountKey = data.accountKey;
    }
  }

  ngOnInit() {
    this.searchAccountForm = this._fb.group({
      accountKey: [this.accountKey ? this.accountKey : ''],
      cid: [],
      manager: [],
      shortname: [],
      longname: [],
      admin: []
    });
    this.copyAccountCountForm = this._fb.group({
      numberOfAccountCopies: ['1', Validators.required],
    });
    this.setNumberOfCopyAccounts();
    this.initErrors();
    this.readOnly = false;
    this.initializeOptions();
    if (this.accountKey) {
      this.search();
    }
  }

  initErrors() {
    this.errors.push(this.helperService.buildError("numberOfAccountCopies", "Number Of Billing Account Copies - This field is required", "required"));
  }

  initializeOptions() {
    this.searchAccountForm.get('manager').valueChanges.subscribe(text => {
      if (text && text.length >= 3) {
        this.partiesService.getListOfUsers(text).subscribe(data => {
          this.managerOptions = data.data;
        })
      }
    });
    this.searchAccountForm.get('admin').valueChanges.subscribe(text => {
      if (text && text.length >= 3) {
        this.partiesService.getListOfUsers(text).subscribe(data => {
          this.adminOptions = data.data;
        })
      }
    });
  }

  search() {
    let formData = {};
    this.displayServerError = true;
    this.formService.collectData(this.searchAccountForm, formData);
    let endPoint = "search-billing-accounts";
    this.dealService.postForm(null, endPoint, formData).subscribe(
      data => {
        if (data.data.accountLookupData == null || (data.data.accountLookupData != null && !data.data.accountLookupData.length)) {
          this.showSearchResult = false;
          this.displayNote = false;
          this.dataSource = null;
        }
        else {
          let responseData = data.data.accountLookupData;
          this.dataSource = BillingExistingAccount.buildExistingAccountDetails(responseData);
          this.showSearchResult = true;
          if (responseData.length >= 100) {
            this.displayNote = true;
          }
          else {
            this.displayNote = false;
          }
        }
      }, error => {
        this.errorService.show(error.error.metadata.error);
        this.showSearchResult = false;
        this.displayNote = false;
        this.dataSource = [];
      });
  }

  rowClick(account: any) {
    this.selectedBillingKey = account.outputKey;
    this.existingAccountData = account;
    if (this.isFromRequestDetails) {
      this.validateClick(account);
    }
  }

  validateClick(account: any) {
    if (account.accountStatus == 'Stopped' || account.accountStatus == 'Closed') {
      this.isAccountStatus = true;
      this.warningMessage = "Billing Key with account status " + account.accountStatus + " cannot be selected"
      setTimeout(() => { this.alertDiv.nativeElement.scrollIntoView() }, 500);
    }
    else {
      this.isAccountStatus = false;
    }
  }

  clear() {
    this.searchAccountForm.reset();
    this.initializeOptions();
    this.showSearchResult = false;
    this.invalidForm = false;
    this.displayNote = false;
    this.displayServerError = false;
    this.dataSource = [];
    this.isAccountStatus = false;
  }

  copyBillingAccount() {
    let form = this.copyAccountCountForm;
    let data;
    this.displayServerError = true;
    this.formService.validateFormFields(form);
    if (!form.valid || !this.selectedBillingKey) {
      this.invalidForm = true;
      this.populateErrorMessages();
    }
    else {
      this.invalidForm = false;
      if (this.isFromRequestDetails) {
        data = { "existingAccountKey": this.existingAccountData, "isExistingKeySelected": true, "selectedBillingKey": this.selectedBillingKey };
      }
      else {
        data = { "count": this.copyAccountCountForm.get('numberOfAccountCopies').value, "selectedBillingKey": this.selectedBillingKey };
      }
      this.dialogRef.close(data);
    }
  }

  populateErrorMessages() {
    this.errorMessages = [];
    this.errorMessages = this.formService.validateForm(this.copyAccountCountForm, this.errors);
    if (!this.selectedBillingKey) {
      this.errorMessages.push("Please select a Billing Key to copy.");
    }
    setTimeout(() => { this.alertDiv.nativeElement.scrollIntoView() }, 500);
  }

  cancel() {
    this.closePopup();
  }

  closePopup() {
    this.dialogRef.close();
  }

  setNumberOfCopyAccounts() {
    for (let i = 1; i <= 10 - this.accountCount; i++) {
      this.numberOfAccountCopyOptions.push(this.helperService.buildOption(i + '', i + ''));
    }
  }

}