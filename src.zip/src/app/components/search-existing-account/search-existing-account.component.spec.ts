import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchExistingAccount } from './search-existing-account.component';

describe('SearchExistingAccount', () => {
  let component: SearchExistingAccount;
  let fixture: ComponentFixture<SearchExistingAccount>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchExistingAccount ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchExistingAccount);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
