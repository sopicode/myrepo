import {MatAutocompleteSelectedEvent} from '@angular/material/autocomplete/typings';
import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { FormGroup, FormArray } from '@angular/forms';
import {COMMA, ENTER} from '@angular/cdk/keycodes';
import { HelperService } from 'src/app/services/helper.service';
import { MatInput } from '@angular/material';

export function arrayDiffObj(s: any[], v: any[], key: string) {
  let reducedIds = v.map((o) => o[key]);
  return s.filter((obj: any) => reducedIds.indexOf(obj[key]) === -1);
};

@Component({
  selector: 'billing-chips-multiselect',
  templateUrl: './chips-multiselect.component.html',
  styleUrls: ['./chips-multiselect.component.scss']
})
export class ChipsMultiselectComponent implements OnInit {

  @ViewChild('chipInput') chipInput: MatInput;

  @Input()
  options: any[] = []; // dropdown options
  @Input()
  optionKeyProp: string; // dropdown options
  @Input()
  optionValueProp: string; // dropdown options
  @Input()
  placeholder:string;
  @Input()
  chips:FormArray;
  @Input()
  chipGroup:FormGroup;
  @Input() readOnly: boolean;

  selectable: boolean = true;
  removable: boolean = true;
  addOnBlur = true;
  readonly separatorKeysCodes: number[] = [ENTER, COMMA];

  constructor(private helperService: HelperService) { }

  ngOnInit() {
  }

  getValue(key:string):string{
    let selectedOption = this.helperService.find(this.options, this.optionKeyProp, key);
    return selectedOption ? selectedOption[this.optionValueProp] : '';
  }

  selected(event: MatAutocompleteSelectedEvent): void {
    let key = event.option.value;
    this.chips.push(this.chipGroup);
    let chipsLength = this.chips.length;
    let chipGrp:any = this.chips.controls[chipsLength-1];
    chipGrp.controls[this.optionKeyProp].setValue(key);
    this.chips.markAsTouched({ onlySelf: true });
    this.chipInput['nativeElement'].blur();
  }

  sourceFiltered(): any[] {
    return arrayDiffObj(this.options, this.chips.getRawValue(), this.optionKeyProp);
}

  remove(index: number): void {
    this.chips.removeAt(index);
    this.chips.markAsTouched({ onlySelf: true });
  }

  onChipInputBlur() {
    this.chips.markAsTouched({ onlySelf: true });
  }

}
