import { Component, OnInit, Input, Output, EventEmitter, Inject } from '@angular/core';
import { DealPartyInfo } from 'src/app/models/dealPartyInfo';

@Component({
  selector: 'billing-contact-dealparty-details',
  templateUrl: './contact-dealparty-details.component.html',
  styleUrls: ['./contact-dealparty-details.component.scss']
})
export class ContactDealpartyDetailsComponent implements OnInit {

  @Input() data: any;
  @Input() partyId: number;
  @Output() selectDealParty = new EventEmitter();
  private _dealPartyDetails: DealPartyInfo[];
  dataSource;
  columnsToDisplay = ["dealPartyName", "roleCSV", "countExistingContacts", "action"];
  columnsDisplayNames =
    {
      "dealPartyName": "Deal Party",
      "roleCSV": "Role(s)",
      "countExistingContacts": "Number of Existing Contacts"
    };

  constructor() { }

  ngOnInit() {
    this.dataSource = this.buildDealParty(this.data);
  }

  buildDealParty(dealPartyList: any): DealPartyInfo[] {
    let dealParties: DealPartyInfo[] = [];
    if (Array.isArray(dealPartyList)) {
      dealPartyList.forEach((dealParty, index) => {
        let dealPartyDetail: DealPartyInfo = DealPartyInfo.fromJSON(dealParty);
        dealPartyDetail.position = index % 2 == 0 ? 'even' : 'odd';
        dealParties.push(dealPartyDetail);
      });
      return dealParties;
    }
  }

  selectDealPartyDetail(data: any) {
    this.selectDealParty.emit(data);
  }

}
