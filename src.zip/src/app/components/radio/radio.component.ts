import { Component, OnInit, Input } from '@angular/core';
import { FormControl } from '@angular/forms';
import { HelperService } from 'src/app/services/helper.service';

@Component({
  selector: 'billing-radio',
  templateUrl: './radio.component.html',
  styleUrls: ['./radio.component.scss']
})
export class RadioComponent implements OnInit {

  @Input()
  options: any[]
  @Input()
  optionKeyProp: string; // dropdown options
  @Input()
  optionValueProp: string;
  @Input()
  label: string;
  @Input()
  radioCtrl: FormControl;
  @Input()
  optional: boolean = false;
  @Input()
  errorMsg: string;
  @Input()
  readOnly: boolean = false;

  constructor(private helperService: HelperService) { }

  ngOnInit() {
  }

  getLabel(key: any) {
    if (this.options) {
      let option = this.helperService.find(this.options, this.optionKeyProp, key);
      return option ? option[this.optionValueProp] : '';
    } else {
      return key ? "Yes" : key == false ? "No" : '';
    }
  }

}
