import { Component, OnInit, Inject, ViewChild, ElementRef, Input } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { BillingAccount } from 'src/app/models/billing-account';
import { MAT_DIALOG_DATA, MatDialogRef } from "@angular/material";
import { HelperService } from 'src/app/services/helper.service';
import { Deal } from 'src/app/models/deal';
import { MomentDateAdapter, MAT_MOMENT_DATE_ADAPTER_OPTIONS } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { FormService } from 'src/app/services/form.service';
import { DealService } from 'src/app/services/deal.service';
import { Wizard } from 'src/app/models/wizard';
import { Error } from 'src/app/models/error';
import { forkJoin } from 'rxjs';
import { ReferencesService } from 'src/app/services/references.service';
import { ServicesFeesComponent } from '../services-fees/services-fees.component';
import { Task } from 'src/app/models/task';

export const BILLING_FORMATS = {
  parse: {
    dateInput: 'DD MMM YYYY',
  },
  display: {
    dateInput: 'DD MMM YYYY',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'DD MMM YYYY',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};

@Component({
  selector: 'billing-account-detail',
  templateUrl: './account-detail.component.html',
  styleUrls: ['./account-detail.component.scss'],
  providers: [
    { provide: DateAdapter, useClass: MomentDateAdapter },
    { provide: MAT_DATE_FORMATS, useValue: BILLING_FORMATS },
    { provide: MAT_MOMENT_DATE_ADAPTER_OPTIONS, useValue: { useUtc: true } }
  ],
})
export class AccountDetailComponent implements OnInit {

  @ViewChild('alertDiv') alertDiv: ElementRef;
  @ViewChild(ServicesFeesComponent) servicesFeesComponent: ServicesFeesComponent;

  billingAccount: BillingAccount;
  deal: Deal;
  accountDetailForm: FormGroup;
  wizard: Wizard;
  readOnly: boolean;
  _onetimeBillingIndctr: boolean;
  _task: Task;
  errorMessages: string[] = [];
  invalidForm: boolean;
  errors: Error[] = [];
  partialForms: any[] = [];
  prorationRules: any[];
  feeAccrlMethods: any[];
  billingFrequency: any[];
  prepaidFees: any[];
  billingCurrencies: any[];
  costCenters: any[];
  accountBillingFrequencies: any[] = [];
  splBillinglegalEntities: any[] = [];

  legalEntities: any[] = [];
  modalTitle;
  isNewBilling: boolean;
  readOnlyForReject: boolean = false;
  legalEntityReady: boolean = false;
  private _upfrntFeesIndctr: boolean;
  @Input() set upfrntFeesIndctr(value: boolean) {
    this._upfrntFeesIndctr = value;
  }

  constructor(private _fb: FormBuilder, private dialogRef: MatDialogRef<AccountDetailComponent>,
    @Inject(MAT_DIALOG_DATA) data, private helperService: HelperService,
    private formService: FormService, private dealService: DealService, private referencesService: ReferencesService,
    @Inject("task") private task) {
    this._task = Task.fromJSON(task);
    this.billingAccount = data.billingAccount;
    this.deal = data.deal;
    this.wizard = data.wizard;
    this.readOnly = data.readOnly;
    this.isNewBilling = data.isNewBilling;
    this.prorationRules = data.prorationRules;
    this.feeAccrlMethods = data.feeAccrlMethods;
    this.billingFrequency = data.feeBillingFrequencies;
    this.prepaidFees = data.prepaidFees;
    this.billingCurrencies = data.billingCurrencies;
    this.costCenters = data.costCenters;
    this.accountBillingFrequencies = data.accountBillingFrequencies;
    this.splBillinglegalEntities = data.splBillinglegalEntities;
  }

  ngOnInit() {
    this._onetimeBillingIndctr = this.billingAccount.onetimeBillingIndctr ? this.billingAccount.onetimeBillingIndctr : false;
    this.accountDetailForm = this._fb.group({
      id: [this.billingAccount.id],
      billingRequestId: [this.billingAccount.billingRequestId],
      billingKey: [this.billingAccount.billingKey, Validators.required],
      acctShortName: [this.billingAccount.acctShortName, Validators.required],
      acctLongName: [this.billingAccount.acctLongName, Validators.required]
    });
    if (this.readOnly) {
      this.accountDetailForm.disable();
    }
    if (null != this._task.variables.rejectReason && this._task.variables.rejectReason != "Incorrect request type" && !this._task.variables.isApproveTask) {
      this.readOnlyForReject = true;
    }
    this.initErrors();
    this.modalTitle = (!this.readOnly) ? "Add Billing Account" : "Billing Account Details";
    // let legalEntities = this.dealService.getBillingLegalEntities(this.deal.id, this._task.variables.specialBillingLegalEntity);
    // legalEntities.subscribe((results: any[]) => {
    //   this.getLegalEntityOptions(results[0].data);
    // });
    this.getLegalEntityOptions(this.splBillinglegalEntities);
  }

  initErrors() {
    this.errors.push(this.helperService.buildError("billingKey", "Proposed Billing Key - This field is required", "required"));
    this.errors.push(this.helperService.buildError("acctShortName", "Billing Account Short Name - This field is required", "required"));
    this.errors.push(this.helperService.buildError("acctLongName", "Billing Account Long Name - This field is required", "required"));
    this.errors.push(this.helperService.buildError("partyId", "BNYM Legal Entity - This field is required", "required"));
    this.errors.push(this.helperService.buildError("roles", "BNYM Corporate Trust Role(s) - This field is required", "required"));
    this.errors.push(this.helperService.buildError("currencyCd", "Billing Currency - This field is required", "required"));
    this.errors.push(this.helperService.buildError("clientCategoryIndctr", "Are services provided to special investment funds (including SICAV and pension funds) subject to the supervision of the CSSF or CAA, or subject to similar supervision?  - This field is required", "required"));
    this.errors.push(this.helperService.buildError("invcLanguageCode", "Language On Invoice - This field is required", "required"));
    this.errors.push(this.helperService.buildError("gvrnmntClntIndctr", "National or Provincial Canadian Government Client - This field is required", "required"));
    this.errors.push(this.helperService.buildError("costCenterCode", "Cost Center - This field is required", "required"));
    this.errors.push(this.helperService.buildError("billingStartDate", "Billing Start Date - This field is required", "required"));
    this.errors.push(this.helperService.buildError("dateGroup", "Maturity Date should be greater than or equal to Billing Start Date and greater than or equal to Next Bill Date.", "maturityDateError"));
    this.errors.push(this.helperService.buildError("billingFrequency", "Billing Frequency - This field is required", "required"));
    this.errors.push(this.helperService.buildError("nextBillDate", "Next Bill Date - This field is required", "required"));
    this.errors.push(this.helperService.buildError("dateGroup", "Next Bill Date should be greater than or equal to Billing Start Date and less than or equal to Maturity Date (if entered).", "nextBillDateError"));
    this.errors.push(this.helperService.buildError("billDay", "Bill Day - This field is required", "required"));
    this.errors.push(this.helperService.buildError("initInvcRqrdIndctr", "Initial Invoice Required - This field is required", "required"));
    this.errors.push(this.helperService.buildError("initInvcDstrbtn", "Initial Invoice Distribution - This field is required", "required"));
    this.errors.push(this.helperService.buildError("cyclicalInvcDstrbtn", "Cyclical Invoice Distribution - This field is required", "required"));
    this.errors.push(this.helperService.buildError("separateBillingDisplayIndctr", "Source Detail - This field is required", "required"));
    this.errors.push(this.helperService.buildError("billedServiceName", "Services To Be Billed - This field is required", "required"));
    this.errors.push(this.helperService.buildError("billedAmount", "Amount - This field is required", "required"));
    this.errors.push(this.helperService.buildError("billedAmount", "Please enter a value greater than or equal to 0.01", "amountError"));
    this.errors.push(this.helperService.buildError("feeScheduleMatchIndctr", "Are services (CT Roles) and fees to be billed identical to the fee schedule? - This field is required", "required"));
    this.errors.push(this.helperService.buildError("componentName", "Component Name - This field is required", "required"));
    this.errors.push(this.helperService.buildError("prorationRuleCode", "Proration Rule - This field is required", "required"));
    this.errors.push(this.helperService.buildError("advanceOrArrearsCode", "Advance/Arrears - This field is required", "required"));
    this.errors.push(this.helperService.buildError("", "Please enter value for Rate Per Item or Flat Fee or Tier", "flatFeeRateTierError"));
    this.errors.push(this.helperService.buildError("", "Both Rate Per Item and Tier cannot be entered. Please enter only one", "rateTierError"));
    this.errors.push(this.helperService.buildError("", "Minimum Amount should be less than or equal to Maximum Amount", "maxAmountError"));
    this.errors.push(this.helperService.buildError("billingFrequencyCode", "Billing Frequency - This field is required", "required"));
    this.errors.push(this.helperService.buildError("upfrontOrPrepaidFees", "Upfront/Prepaid Fees - This field is required", "required"));
    this.errors.push(this.helperService.buildError("ratePerItem", "Please enter a valid value for Rate Per Item", "pattern"));
  }


  formInitialized(name: string, form: FormGroup) {
    this.accountDetailForm.setControl(name, form);
    if (name == "accountDetails") {
      form.get('onetimeBillingIndctr').valueChanges.subscribe(selectedValue => {
        this._onetimeBillingIndctr = selectedValue;
      });
    }
    if (name == "invoiceForm") {
      form.get('upfrntFeesIndctr').valueChanges.subscribe(selectedValue => {
        this._upfrntFeesIndctr = selectedValue;
      });
    }
    this.partialForms.push(name);
    if (this.readOnly) {
      form.disable();
    }
    if (this.partialForms.length == 4) {
      this.accountDetailForm.valueChanges.subscribe((data) => {
        this.errorMessages = this.formService.validateForm(this.accountDetailForm, this.errors);
      });
    }
  }

  getLegalEntityOptions(data: any) {
    let legalEntitiesData: any[] = BillingAccount.buildLegalEntities(data);
    for (let i = 0; i < legalEntitiesData.length; i++) {
      this.legalEntities.push({ "key": legalEntitiesData[i]._id, "value": legalEntitiesData[i]._externalLegalEntityId + ' ' + legalEntitiesData[i]._legalName });
      if (i == legalEntitiesData.length - 1) {
        this.legalEntityReady = true;
      }
    }
    if (!legalEntitiesData || legalEntitiesData.length == 0) {
      this.legalEntityReady = true;
    }
  }

  closePopup() {
    this.dialogRef.close();
  }

  discardChanges() {
    this.closePopup();
  }

  save(checkValid?: boolean) {
    let form = this.accountDetailForm;
    if (checkValid) {
      this.formService.validateFormFields(form);
    }
    let valid = form.valid;
    let endPoint = "billing-requests/" + this._task.variables.billingRequestId + "/billing-account-details"
    let reqBody = {};
    let data = [];
    this.wizard.action = checkValid ? "save" : "SaveDraft";
    reqBody["wizard"] = Wizard.toJSON(this.wizard);
    let formData = {};
    this.formService.collectData(form, formData);
    formData["action"] = "update";
    if (formData["billingFrequency"] == "N/A") {
      formData["billingFrequency"] = null;
    }
    data.push(formData);
    reqBody["data"] = data;
    if ((checkValid && valid) || !checkValid) {
      this.dealService.postForm(this.deal.id, endPoint, reqBody).subscribe(
        data => {
          this.closePopup();
        }, error => {
          setTimeout(() => { this.alertDiv.nativeElement.scrollIntoView() }, 500);
        })
    } else {
      this.invalidForm = true;
      this.servicesFeesComponent.updateDataSource();
      this.errorMessages = this.formService.validateForm(this.accountDetailForm, this.errors);
      setTimeout(() => { this.alertDiv.nativeElement.scrollIntoView() }, 500);
    }
  }

}