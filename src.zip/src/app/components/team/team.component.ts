import { Component, OnInit, Input, Output, EventEmitter, Inject,ViewEncapsulation } from '@angular/core';
import { DealService } from './../../services/deal.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Deal } from '../../models/deal';
import { HelperService } from 'src/app/services/helper.service';
import { Error } from 'src/app/models/error';
import { PartiesService } from 'src/app/services/parties.service';
import { Task } from 'src/app/models/task';

@Component({
  selector: 'billing-team',
  templateUrl: './team.component.html',
  styleUrls: ['./team.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class TeamComponent implements OnInit {

  @Input() deal: Deal;
  @Input() data: any;
  @Input() readOnly: boolean;
  @Output() formInitialized = new EventEmitter<FormGroup>();

  detailsForm: FormGroup;
  team: any[];
  adminManager: any = {};
  errors: Error[] = [];
  splBilling: boolean = false;
  manager: any[] = [];
  admin: any[] = [];
  showAdminAndMgrDropdown: boolean = false;

  constructor(private dealService: DealService, private _fb: FormBuilder, private helperService: HelperService, private partiesService: PartiesService, @Inject("task") private task) {
    let taskObj = Task.fromJSON(this.task);
    this.splBilling = taskObj.variables && taskObj.variables.specialBillingLegalEntity ? true : false;
  }

  onSelectTeam(groupId: number, isGroupIdChanged: boolean) {
    if (isGroupIdChanged) {
      this.detailsForm.get('admin').setValue(null);
      this.detailsForm.get('manager').setValue(null);
    }
    if (groupId) {
      if (this.splBilling || groupId == 1030 || groupId == 1031) {
        this.showAdminAndMgrDropdown = true;
        this.partiesService.getUsersByGroupId(groupId).subscribe((value: any) => {
          let data = value.data;
          this.admin = this.helperService.filterByKey(data, "functionalTtlCode", "TITLE_CSM");
          this.manager = this.helperService.filterByKey(data, "functionalTtlCode", "TITLE_CSM-TL");
        });
      } else {
        this.showAdminAndMgrDropdown = false;
        let dealId = this.deal.id;
        this.dealService.getBillingAdminManager(dealId, groupId).subscribe((value: any) => {
          this.adminManager = value.data;
          if (this.adminManager) {
            this.detailsForm.get('admin').setValue(this.adminManager.adminComitId);
            this.detailsForm.get('manager').setValue(this.adminManager.managerComitId);
          }
        });
      }
    }
  }

  ngOnInit() {
    let data = this.data[0].data;
    let groupId = data.billingTeamGroupId;
    let admin = this.splBilling || groupId == 1030 || groupId == 1031 ? data.admin : null;
    let manager = this.splBilling || groupId == 1030 || groupId == 1031 ? data.manager : null;
    this.detailsForm = this._fb.group({
      id: [data.id],
      billingTeamGroupId: [groupId, Validators.required],
      admin: [admin],
      manager: [manager]
    });
    if (this.splBilling) {
      this.helperService.addValidation(this.detailsForm,"admin",Validators.required);
      this.helperService.addValidation(this.detailsForm,"manager",Validators.required);
    }
    this.team = this.data[1].data;
    if (this.readOnly) {
      this.detailsForm.disable();
    }
    this.formInitialized.emit(this.detailsForm);
    this.initErrors();
    this.onSelectTeam(groupId, false);
  }

  initErrors() {
    this.errors.push(this.helperService.buildError("billingTeamGroupId", "Team Name - This field is required", "required"));
  }
}
