import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormControl } from '@angular/forms';
import { HelperService } from 'src/app/services/helper.service';
import { MatInput } from '@angular/material';

@Component({
  selector: 'billing-select',
  templateUrl: './select.component.html',
  styleUrls: ['./select.component.scss']
})
export class SelectComponent implements OnInit {

  @Input()
  options: any[] = []; // dropdown options
  @Input()
  optionKeyProp: string; // dropdown options
  @Input()
  optionValueProp: string; // dropdown options
  @Input()
  placeholder: string;
  @Input()
  selectCtrl: FormControl;
  @Input()
  optional: boolean = false;
  @Input()
  errorMsg: string;
  @Input()
  readOnly: boolean = false;
  showFilter: boolean = false;
  @Input()
  hideLabelIfReadOnly: boolean = false;
  @Input()
  selectedOption: string;

  @Input()
  panelClass:string;
  @Output() selectionChange = new EventEmitter();
  activeOptions: any[] = [];
  filteredOptions: any[] = [];

  constructor(private helperService: HelperService) { }

  ngOnInit() {
  }

  ngOnChanges() {
    if(this.options && this.options.length>0){
      this.activeOptions = this.helperService.filterActiveValues(this.options);
      this.filteredOptions = this.activeOptions;
      if(this.activeOptions.length > 5){
        this.showFilter = true;
      }
    }
  }

  onSelect($event) {
    this.selectionChange.emit($event);
  }

  getLabel(key: any) {
    let option = this.helperService.find(this.activeOptions, this.optionKeyProp, key);
    return option ? option[this.optionValueProp] : '';
  }

  filter(query: string) {
    this.filteredOptions = this.select(query);
  }

  select(query: string): any[] {
    let result: any[] = [];
    for (let option of this.activeOptions) {
      let value: string = option[this.optionValueProp];
      if (value.toLowerCase().startsWith(query.toLowerCase())) {
        result.push(option);
      }
    }
    return result;
  }

  onOpenSelect(searchInput: MatInput) {
    this.filteredOptions = this.options;
    searchInput.value = "";
    searchInput.focus();
  }

}
