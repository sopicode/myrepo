import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DataMismatchDetailsComponent } from './data-mismatch-details.component';

describe('DataMismatchDetailsComponent', () => {
  let component: DataMismatchDetailsComponent;
  let fixture: ComponentFixture<DataMismatchDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DataMismatchDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DataMismatchDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
