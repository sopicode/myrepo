import { Component, OnInit, Input, ViewEncapsulation, Inject } from '@angular/core';
import { DataMismatchDetails } from 'src/app/models/data-mismatch';
import { FormGroup, FormBuilder, FormArray, Validators } from '@angular/forms';
import { HelperService } from 'src/app/services/helper.service';
import { ReferencesService } from 'src/app/services/references.service';
import { Task } from 'src/app/models/task';

@Component({
  selector: 'billing-data-mismatch-details',
  templateUrl: './data-mismatch-details.component.html',
  styleUrls: ['./data-mismatch-details.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class DataMismatchDetailsComponent implements OnInit {

  columnsToDisplay = ["_legalEntityName", "_ctRoleName", "_datamismatchReasonCode", "_datamismatchComment"];
  dataSource;
  @Input() data: any[];
  @Input() readOnly: boolean;
  reasonOptions: any[] = [];
  detailsForm: FormGroup;
  billingSequenceNumber: number;
  specialBillingLegalEntity: string;
  part: string;
  dataMismatchDetailsDoNotApply: boolean = false;
  private _task: Task; // holds task information

  constructor(private _fb: FormBuilder, @Inject("task") private task, private helperService: HelperService, private referencesService: ReferencesService) {
    this._task = Task.fromJSON(task);
  }

  ngOnInit() {
    if (this.data[1].data && this.data[1].data.length === 0) {
      this.dataMismatchDetailsDoNotApply = true;
    }
    this.dataSource = this.buildDataMismatchDetails(this.data[1].data);
    this.billingSequenceNumber = this._task.variables.billingSequence;
    this.specialBillingLegalEntity = this._task.variables.specialBillingLegalEntity;
    this.detailsForm = this._fb.group({
      dataMismatchDetails: this._fb.array([]),
    });
    this.initDataMismatchForm();
    this.referencesService.getReason('BIL_DATA_MMTCH_USR').subscribe((value: any) => {
      this.reasonOptions = value.data;
      this.reasonOptions = [{}].concat(this.reasonOptions);
    });
  }

  getSelectedOption(key) {
    let reason = this.helperService.find(this.reasonOptions, "reasonCode", key);
    if (reason)
      return reason.reasonDesc;
    return '';
  }

  getDataMismatchDetailsFormArray(): FormArray {
    return this.detailsForm.get('dataMismatchDetails') as FormArray;
  }

  initDataMismatchForm() {
    let dataMismatchControl = this.getDataMismatchDetailsFormArray();
    if (this.dataSource) {
      this.dataSource.forEach(data => {
        let partOfReqNo;
        if (this.readOnly) {
          partOfReqNo = data.partOfReqNo;
        }
        else {
          partOfReqNo = this.getPartOfReq(data.partOfReqNo);
        }
        dataMismatchControl.push(
          this._fb.group({
            billingDataMismatchId: [data.billingDataMismatchId],
            legalEntityCode: [data.legalEntityCode],
            legalEntityName: [data.legalEntityName],
            partyRoleId: [data.partyRoleId],
            ctRoleName: [data.ctRoleName],
            dataMismatchReasonCode: [data.dataMismatchReasonCode, Validators.required],
            dataMismatchComment: [data.dataMismatchComment, Validators.required],
            partOfReqNo: [partOfReqNo],
            requestNosList: [],
            partyId:[data.partyId],
            partyRoleTypeCode: [data.partyRoleTypeCode]
          }))
      })
    }
  }

  getPartOfReq(partOfReqNo) {
    let currentPartOfReqNo = this.specialBillingLegalEntity ? this.specialBillingLegalEntity + this.billingSequenceNumber : this.billingSequenceNumber.toString();
    if (partOfReqNo && partOfReqNo.indexOf(currentPartOfReqNo) != -1)
      return partOfReqNo;
    else
      return partOfReqNo ? partOfReqNo + ',' + currentPartOfReqNo : currentPartOfReqNo;
  }

  buildDataMismatchDetails(dataMismatchList: any): DataMismatchDetails[] {
    let dataMismatchDetails: DataMismatchDetails[] = [];
    if (Array.isArray(dataMismatchList)) {
      dataMismatchList.forEach((datamismatchdetail, index) => {
        let dataMismatchList: DataMismatchDetails = DataMismatchDetails.fromJSON(datamismatchdetail);
        dataMismatchList.position = index % 2 == 0 ? 'even' : 'odd';
        dataMismatchDetails.push(dataMismatchList);
      });
      return dataMismatchDetails;
    }
  }

  hasError(rowIndex: number, fieldName: string) {
    let field = this.getField(rowIndex, fieldName);
    return field.touched && field.invalid;
  }

  getField(rowIndex: number, fieldName: string) {
    return this.getDataMismatchDetailsFormArray().controls[rowIndex].get(fieldName);
  }

}