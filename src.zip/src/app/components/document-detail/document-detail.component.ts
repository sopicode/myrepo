import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Document } from 'src/app/models/document';
import { DealService } from 'src/app/services/deal.service';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'billing-document-detail',
  templateUrl: './document-detail.component.html',
  styleUrls: ['./document-detail.component.scss']
})
export class DocumentDetailComponent implements OnInit {

  @Input() doc: Document;
  @Input() index: number;
  @Input() isHTML5: boolean;
  @Input() docTypes: any[];
  @Input() docForm: FormGroup;
  @Input() selected: boolean;
  @Input() readOnly: boolean;
  @Output() deleteDocument = new EventEmitter();
  @Output() selectDocument = new EventEmitter();

  _item: any;
  _selected: boolean;

  constructor(private dealService: DealService) { }

  ngOnInit() {
    this._item = this.doc.item;
  }

  getFileIcon(fileName: string) {
    var classes = '',
      ext = fileName;
    if (ext.lastIndexOf('.') > -1) {
      ext = fileName.slice(fileName.lastIndexOf('.') + 1).toLowerCase();
    }
    if (['doc', 'docx'].indexOf(ext) !== -1) {
      classes = 'doc';
    } else if (['js', 'css', 'html', 'scss'].indexOf(ext) !== -1) {
      classes = 'glyphicon glyphicon-file';
    } else if (['png', 'gif', 'jpg', 'svg'].indexOf(ext) !== -1) {
      classes = 'glyphicon glyphicon-picture';
    } else if (['pdf'].indexOf(ext) !== -1) {
      classes = 'pdf';
    } else if (['ppt', 'pptx'].indexOf(ext) !== -1) {
      classes = 'glyphicon glyphicon-file';
    } else if (['xls', 'xlsx'].indexOf(ext) !== -1) {
      classes = 'xls';
    } else {
      classes = 'glyphicon glyphicon-file';
    }
    return classes;
  };

  downloadDoc() {
    this.dealService.getDocument(this.doc.fileId).subscribe((d: any) => {
      if (!d.data || !d.data.url) {
        return;
      }
      var download = document.createElement('a');
      download.href = d.data.url;
      download.target = '_blank';
      download.classList.add('display-none');
      document.body.appendChild(download);
      download.click();
      document.body.removeChild(download);
    });
  }

  chooseDocument() {
    this.selectDocument.emit(this.index);
  }

  deleteDoc(){
    this.deleteDocument.emit(this.index);
  }

}
