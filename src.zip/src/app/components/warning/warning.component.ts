import { Component, OnInit, Input, TemplateRef } from '@angular/core';

@Component({
  selector: 'billing-warning',
  templateUrl: './warning.component.html',
  styleUrls: ['./warning.component.scss']
})
export class WarningComponent implements OnInit {

  @Input() warningMessage: String;
  @Input()
  actionTemplate: TemplateRef<any>;

  constructor() { }

  ngOnInit() {
  }

}
