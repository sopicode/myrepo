import { FormControl, ValidatorFn, FormGroupDirective, NgForm, FormGroup } from "@angular/forms";
import { ErrorStateMatcher } from "@angular/material";
import * as moment from 'moment';

export class DateValidators {

    static nextBillDateValidator: ValidatorFn = (formGroup: FormGroup) => {
        let billingStartDateValue = formGroup.controls.billingStartDate.value;
        let billingStartDate = billingStartDateValue ? moment(billingStartDateValue) : null;
        let maturityDateValue = formGroup.controls.maturityDate.value;
        let maturityDate = maturityDateValue ? moment(maturityDateValue) : null;
        let nextBillDateValue = formGroup.controls.nextBillDate.value;
        let nextBillDate = nextBillDateValue ? moment(nextBillDateValue) : null;
        if (nextBillDate && (nextBillDate.isBefore(billingStartDate,'day') || nextBillDate.isAfter(maturityDate,'day'))) {
            return { nextBillDateError: true };
        }
        return null;
    }


    static maturityDateValidator: ValidatorFn = (formGroup: FormGroup) => {
        let billingStartDateValue = formGroup.controls.billingStartDate.value;
        let billingStartDate = billingStartDateValue ? moment(billingStartDateValue) : null;
        let maturityDateValue = formGroup.controls.maturityDate.value;
        let maturityDate = maturityDateValue ? moment(maturityDateValue) : null;
        let nextBillDateValue = formGroup.controls.nextBillDate.value;
        let nextBillDate = nextBillDateValue ? moment(nextBillDateValue) : null;
        if (maturityDate && (maturityDate.isBefore(billingStartDate,'day') || maturityDate.isBefore(nextBillDate,'day'))) {
            return { maturityDateError: true };
        }
        return null;
    }
}

export class NextBillDateValidMatcher implements ErrorStateMatcher{
    isErrorState(control: FormControl, form: FormGroupDirective | NgForm): boolean {
        return (control.parent.invalid && control.touched && control.parent.hasError('nextBillDateError')
        || control.invalid && control.touched && control.hasError('required'));
    }
}

export class MaturityDateValidMatcher implements ErrorStateMatcher{
    isErrorState(control: FormControl, form: FormGroupDirective | NgForm): boolean {
        return control.parent.invalid && control.touched && control.parent.hasError('maturityDateError');
    }
}