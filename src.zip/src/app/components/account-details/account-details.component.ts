import { Component, OnInit, Input, Output, EventEmitter, Inject } from '@angular/core';
import { BillingAccount } from 'src/app/models/billing-account';
import { FormGroup, FormBuilder, Validators, FormArray } from '@angular/forms';
import * as moment from 'moment';
import { Deal } from 'src/app/models/deal';
import { Role } from 'src/app/models/role';
import { HelperService } from 'src/app/services/helper.service';
import { DealService } from 'src/app/services/deal.service';
import { ReferencesService } from 'src/app/services/references.service';
import { forkJoin } from 'rxjs';
import { DateValidators, NextBillDateValidMatcher, MaturityDateValidMatcher } from './date-validation';
import { Task } from 'src/app/models/task';

@Component({
  selector: 'billing-account-details',
  templateUrl: './account-details.component.html',
  styleUrls: ['./account-details.component.scss']
})
export class AccountDetailsComponent implements OnInit {

  @Input() readOnly: boolean;
  @Input()
  billingAccount: BillingAccount;
  @Input()
  deal: Deal;
  @Input()
  legalEntities: any[] = [];
  @Input() isNewBilling: boolean;
  @Output() formReady = new EventEmitter<FormGroup>();
  private _upfrntFeesIndctr: boolean;
  @Input() set upfrntFeesIndctr(value: boolean) {
    this._upfrntFeesIndctr = value;
  }
  @Input() _billingCurrencies: any[];
  @Input() _costCenters: any[];
  @Input() _billingFrequencies: any[] = [];
  _roles: Role[] = [];
  _billDayTypes: any[];
  _billingInvoiceLang: any[];
  accountDetailsForm: FormGroup;
  billingFrequencyMap: any = { 'ANLY': 12, 'MNTHLY': 1, 'SEMIANLY': 6, 'QRTLY': 3 };
  billingLegalEntity: any;
  clientCatIndicatorOptions: any[] = [];
  gvrnmntClntIndctrOptions: any[] = [];
  billingFrequency: string;
  billDay: string;
  nextBillDateValidMatcher: NextBillDateValidMatcher = new NextBillDateValidMatcher();
  maturityDateValidMatcher: MaturityDateValidMatcher = new MaturityDateValidMatcher();
  readOnlyForReject: boolean = false;
  _task: Task;

  constructor(private _fb: FormBuilder, private helperService: HelperService,
    private dealService: DealService, private referencesService: ReferencesService, @Inject("task") private task) {
    this._task = Task.fromJSON(task);
  }

  ngOnInit() {
    let oneTimeBillIndicator = this.billingAccount.onetimeBillingIndctr ? this.billingAccount.onetimeBillingIndctr : false;
    let billingStartDate = this.billingAccount.billingStartDate ? this.billingAccount.billingStartDate : this.deal.proposedClosingDate;
    let maturityDate = this.billingAccount.maturityDate ? this.billingAccount.maturityDate : null;
    let nextBillDate = this.billingAccount.nextBillDate ? this.billingAccount.nextBillDate : null;
    let partyId = this.billingAccount.partyId;
    let upfrntFeesIndctr = this.billingAccount.upfrntFeesIndctr;

    if (upfrntFeesIndctr) {
      this._upfrntFeesIndctr = true;
    }
    //initialize form
    this.accountDetailsForm = this._fb.group({
      currencyCd: [this.billingAccount.currencyCd, Validators.required],
      invcLanguageCode: [this.billingAccount.invcLanguageCode, Validators.required],
      costCenterCode: [this.billingAccount.costCenterCode, Validators.required],
      billDay: [this.billingAccount.billDay, Validators.required],
      billingFrequency: [{ value: this.billingAccount.billingFrequency, disabled: oneTimeBillIndicator }, Validators.required],
      gvrnmntClntIndctr: [this.billingAccount.gvrnmntClntIndctr, Validators.required],
      onetimeBillingIndctr: [oneTimeBillIndicator],
      dateGroup: this._fb.group({
        billingStartDate: [billingStartDate, Validators.required],
        maturityDate: [{ value: maturityDate, disabled: oneTimeBillIndicator }],
        nextBillDate: [{ value: nextBillDate, disabled: oneTimeBillIndicator }, Validators.required]
      }, {
          validator: [DateValidators.nextBillDateValidator, DateValidators.maturityDateValidator]
        }),
      partyId: [partyId, Validators.required],
      clientCategoryIndctr: [this.billingAccount.clientCategoryIndctr, Validators.required],
      roles: this._fb.array([], Validators.required)
    })

    this.initRoles();
    if (oneTimeBillIndicator) { // if one time indicator is yes, apply all rules
      this.onOneTimeBillingChange(oneTimeBillIndicator);
    } else {
      this.applyBillDayChanges();
    }
    if (!this.readOnly) {
      this.OnBillingFrequencyChange();
      this.onChangeStartDate();
      this.onPartyIdChange(partyId);
      this.accountDetailsForm.get('onetimeBillingIndctr').valueChanges.subscribe(selectedValue => {
        this.onOneTimeBillingChange(selectedValue);
        if (!selectedValue && !this._upfrntFeesIndctr) {
          this._upfrntFeesIndctr = false;
        }
      });
      this.accountDetailsForm.get('partyId').valueChanges.subscribe(selectedValue => {
        this.onPartyIdChange(selectedValue);
      });
    }
    this.formReady.emit(this.accountDetailsForm);
    this.getClientCatIndicatorOptions();
    this.getGvrnmntClntIndctrOptions();
    let billDayTypesPromise = this.referencesService.getBillDayTypes();
    let billingInvLang = this.referencesService.getBillingInvoiceLanguage();
    this.helperService.find(this._billingFrequencies, "code", "N/A");
    if (oneTimeBillIndicator) {
      this._billingFrequencies.push({ "code": "N/A", "name": "N/A" });
    }
    forkJoin(billDayTypesPromise, billingInvLang).subscribe((results: any[]) => {
      this._billDayTypes = results[0].data;
      this._billingInvoiceLang = results[1].data;
    });
    if (partyId) {
      this.dealService.getBillingRoles(this.deal.id, partyId, this._task.variables.specialBillingLegalEntity).subscribe(
        data => {
          this.buildRoles(data.data, partyId);
        });
    }
    if (null != this._task.variables.rejectReason && this._task.variables.rejectReason != "Incorrect request type" && !this._task.variables.isApproveTask) {
      this.readOnlyForReject = true;
    }
  }

  getRoles(): FormArray {
    return this.accountDetailsForm.get('roles') as FormArray;
  }

  initRoles() {
    let rolesControl = this.getRoles();
    if (this.billingAccount.roles) {
      this.billingAccount.roles.forEach(role => {
        rolesControl.push(
          this._fb.group({
            partyRoleId: [role.partyRoleId]
          }))
      })
    }
  }

  getRoleGroup() {
    return this._fb.group({
      partyRoleId: []
    })
  }

  onSelectLegalEntity(legalEntity: number) {
    let rolesArray = this.getRoles();
    if (legalEntity) {
      this._roles = [];
      // clear roles selected
      this.helperService.clearFormArray(rolesArray);
      this.dealService.getBillingRoles(this.deal.id, legalEntity, this._task.variables.specialBillingLegalEntity).subscribe(
        data => {
          this.buildRoles(data.data, legalEntity);
        });
    }
  }

  buildRoles(data: any, legalEntity: number) {
    let roles = BillingAccount.buildRoles(data);
    this._roles = roles;
  }

  get upfrntFeesIndctr(): boolean {
    return this._upfrntFeesIndctr;
  }

  onPartyIdChange(value: number) {
    if (value == 102832) {
      this.helperService.showFormControl(this.accountDetailsForm, "invcLanguageCode");
      this.helperService.showFormControl(this.accountDetailsForm, "gvrnmntClntIndctr");
    } else {
      this.helperService.hideFormControl(this.accountDetailsForm, "invcLanguageCode");
      this.helperService.hideFormControl(this.accountDetailsForm, "gvrnmntClntIndctr");
    }
    if ((value == 102846 || value == 102845) && this.billingAccount.isEU) {
      this.helperService.showFormControl(this.accountDetailsForm, "clientCategoryIndctr");
    } else {
      this.helperService.hideFormControl(this.accountDetailsForm, "clientCategoryIndctr");
    }
  }

  // if next bill date is greater than or equal to 28, enable bill day
  applyBillDayChanges() {
    let nextBillDateValue = this.accountDetailsForm.get('dateGroup').get('nextBillDate').value;
    let billDay = this.accountDetailsForm.get('billDay');
    if (nextBillDateValue) {
      let nextBillDate = moment(nextBillDateValue);
      if (nextBillDate.date() >= 28) {
        billDay.enable();
      }
      else {
        billDay.setValue('SLCTD_DAY');
        billDay.disable();
      }
    } else if (!billDay.value) {
      billDay.setValue('SLCTD_DAY');
    }
  }

  onChangeStartDate() {
    let dateGroup = this.accountDetailsForm.get('dateGroup');
    let nextBillDateControl = dateGroup.get('nextBillDate');
    dateGroup.get('billingStartDate').valueChanges.subscribe(selectedValue => {
      let billingStDate = selectedValue;
      let onetimeBillingIndctr = this.accountDetailsForm.get('onetimeBillingIndctr').value;
      let nextDay = moment(billingStDate).add(1, 'days');
      // if one time billing is yes
      if (onetimeBillingIndctr) {
        nextBillDateControl.setValue(nextDay);
        dateGroup.get('maturityDate').setValue(nextDay);
      } else {
        if (this.accountDetailsForm.get('billingFrequency').value) {
          let billingFrequency = this.accountDetailsForm.get('billingFrequency').value;
          let nextBillDate = moment(billingStDate, 'YYYY-MM-DD').add(this.billingFrequencyMap[billingFrequency], 'M');
          nextBillDateControl.setValue(nextBillDate);
        } else {
          nextBillDateControl.setValue(billingStDate);
        }
        this.applyBillDayChanges();
      }
    });
  }

  //on change of one time billing 
  onOneTimeBillingChange(value: boolean) {
    let dateGroup = this.accountDetailsForm.get('dateGroup');
    let maturityDateControl = dateGroup.get('maturityDate');
    let nextBillDateControl = dateGroup.get('nextBillDate');
    let billFreqControl = this.accountDetailsForm.get('billingFrequency');
    let billDayControl = this.accountDetailsForm.get('billDay');

    if (value) {
      maturityDateControl.disable();
      nextBillDateControl.disable();
      billFreqControl.disable();
      this.accountDetailsForm.get('billDay').disable();

      this._billingFrequencies.push({ "code": "N/A", "name": "N/A" });
      this._billingFrequencies = [].concat(this._billingFrequencies);
      this.billingFrequency = billFreqControl.value;
      this.billDay = billDayControl.value;
      billFreqControl.setValue('N/A');
      billDayControl.setValue('SLCTD_DAY');

      let billingStDate = dateGroup.get('billingStartDate').value;
      let nextBilldate = moment.utc(billingStDate).add(1, 'days');
      maturityDateControl.setValue(nextBilldate);
      nextBillDateControl.setValue(nextBilldate);
    } else {
      maturityDateControl.enable();
      nextBillDateControl.enable();
      billFreqControl.enable();
      this.accountDetailsForm.get('billDay').enable();
      // Bill day and billing frequency should retain previous values
      billFreqControl.setValue(this.billingFrequency);
      billDayControl.setValue(this.billDay);
      maturityDateControl.setValue(null);
      // remove N/A option
      this._billingFrequencies = this.helperService.filter(this._billingFrequencies, "code", "N/A");
      this._billingFrequencies = [].concat(this._billingFrequencies);
    }

  }

  // on change of billing frequency
  OnBillingFrequencyChange() {
    let dateGroup = this.accountDetailsForm.get('dateGroup');
    this.accountDetailsForm.get('billingFrequency').valueChanges.subscribe(selectedValue => {
      let onetimeBillingIndctr = this.accountDetailsForm.get('onetimeBillingIndctr').value;
      let billingFrequency = this.accountDetailsForm.get('billingFrequency').value;
      // only if one time billing is false, listen to frequency change
      if (!onetimeBillingIndctr && billingFrequency && billingFrequency != "N/A") {
        let billingStDate = dateGroup.get('billingStartDate').value;
        let nextBillDate = moment.utc(billingStDate).add(this.billingFrequencyMap[billingFrequency], 'M').format();
        dateGroup.get('nextBillDate').setValue(nextBillDate);
        this.applyBillDayChanges();
      }
    });
  }


  getClientCatIndicatorOptions() {
    this.clientCatIndicatorOptions.push(this.helperService.buildOption(true, "Yes-Category 1"));
    this.clientCatIndicatorOptions.push(this.helperService.buildOption(false, "No-Category 2"));
  }

  getGvrnmntClntIndctrOptions() {
    this.gvrnmntClntIndctrOptions.push(this.helperService.buildOption('Y', "Yes"));
    this.gvrnmntClntIndctrOptions.push(this.helperService.buildOption('N', "No"));
  }

  onDestroy() {

  }

}