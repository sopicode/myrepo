import { Component, OnInit, Input, Output, EventEmitter, Inject } from '@angular/core';
import { CustomerDetail } from '../../models/customer-details';

@Component({
  selector: 'billing-customer-contact-details',
  templateUrl: './customer-contact-details.component.html',
  styleUrls: ['./customer-contact-details.component.scss']
})
export class CustomerContactDetailsComponent implements OnInit {

  @Input() dataSource: any;
  @Output() selectCustomer = new EventEmitter();
  columnsToDisplay = ["legalName", "cid", "countryName", "addressLine1","action"];
  columnsDisplayNames =
    {
      "legalName": "Customer Name",
      "cid": "CID",
      "countryName": "Country of Domicile",
      "addressLine1": "Address"
    };

  constructor() { }

  ngOnInit() {
  }

  selectCustomerDetail(data: any) {
    this.selectCustomer.emit(data);
  }

}
