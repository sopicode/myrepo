import { Component, OnInit, Input, TemplateRef, Output, EventEmitter } from '@angular/core';
import { TableModel } from 'src/app/models/table-model';
import { animate, state, style, transition, trigger } from '@angular/animations';

@Component({
  selector: 'billing-expanded-table',
  templateUrl: './expanded-table.component.html',
  styleUrls: ['./expanded-table.component.scss'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0', display: 'none' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class ExpandedTableComponent implements OnInit {

  @Input()
  actionTemplate: TemplateRef<any>;
  @Input()
  detailTemplate: TemplateRef<any>;
  @Input()
  dataSource: TableModel[];
  @Input()
  columnsToDisplay: string[];
  @Input()
  columnsDisplayNames: any;
  @Input()
  dataSourceEmptyMsg:string;
  expandedElement: TableModel;

  @Output() rowClick = new EventEmitter();

  constructor() { }

  ngOnInit() {
  }

  ngOnChanges(){
  }

  toggleRow(element: any) {
    element.expanded = !element.expanded;
    this.rowClick.emit(element);
  }

  /*onTableScroll(e) {
    const tableViewHeight = e.target.offsetHeight;
    const tableScrollHeight = e.target.scrollHeight;
    const scrollLocation = e.target.scrollTop;

    const buffer = 200;
    const limit = tableScrollHeight - tableViewHeight - buffer;
    if (scrollLocation > limit) {
      this.dataSource = this.dataSource.concat();
    }
  }*/

}
