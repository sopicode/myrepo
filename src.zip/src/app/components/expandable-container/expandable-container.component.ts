import { Component, OnInit, Input, ViewChild, ElementRef, AfterViewInit, ChangeDetectorRef } from '@angular/core';

@Component({
  selector: 'billing-expandable-container',
  templateUrl: './expandable-container.component.html',
  styleUrls: ['./expandable-container.component.scss']
})
export class ExpandableContainerComponent implements OnInit, AfterViewInit {

  @ViewChild('expandableElement') expandableElement: ElementRef;
  @ViewChild('expandableContainer') expandableContainer: ElementRef;

  @Input()
  text: string;

  showTooltip: boolean = false;
  enableExpand: boolean = false;
  expand: boolean = false;
  toggleLabel = 'Show More';

  constructor(private ref: ChangeDetectorRef) { }

  ngOnInit() {

  }

  ngAfterViewInit() {
    var containerHeight = this.expandableElement.nativeElement.scrollHeight;
    this.enableExpand = containerHeight <= 48 ? false : true;
    if (this.enableExpand) {
      this.expandableContainer.nativeElement.addEventListener('click', this.toggleExpand.bind(this));
    }
    this.ref.detectChanges();
  }

  toggleExpand() {
    this.expand ? this.applyExpandActions() : this.applyCollapseActions();
    this.expand = !this.expand;
  }

  applyExpandActions() {
    this.toggleLabel = 'Show More';
    this.expandableElement.nativeElement.setAttribute("style", "max-height:47px;height:100%")
  }

  applyCollapseActions() {
    this.toggleLabel = 'Show Less';
    let htmlElement = this.expandableElement.nativeElement;
    htmlElement.setAttribute("style", "max-height:" + htmlElement.scrollHeight + "px;height:" + htmlElement.scrollHeight + "px");
  }

}
