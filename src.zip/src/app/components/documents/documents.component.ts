import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FileUploader } from 'ng2-file-upload';
import { Deal } from 'src/app/models/deal';
import { Document } from 'src/app/models/document';
import { FormGroup, Validators, FormBuilder, FormArray} from '@angular/forms';
import { Error } from 'src/app/models/error';
import { FormService } from 'src/app/services/form.service';
import { ErrorService } from 'src/app/services/error.service';
import { HelperService } from 'src/app/services/helper.service';

@Component({
  selector: 'billing-documents',
  templateUrl: './documents.component.html',
  styleUrls: ['./documents.component.scss']
})
export class DocumentsComponent implements OnInit {

  @Input() deal: Deal;
  @Input() data: any;
  @Input() readOnly: boolean;
  @Output() formInitialized = new EventEmitter<FormGroup>();

  detailsForm: FormGroup;
  _documents: Document[];
  _documentTypes: any[];
  private _deletedDocs: any[] = [];
  errors: Error[] = [];
  _selectedIndex: number = 0;
  private documentUrl: string;
  public uploader: FileUploader;

  constructor(private errorService: ErrorService, private _fb: FormBuilder, private formService: FormService, private helperService: HelperService) {
    this.documentUrl = this.helperService.getBaseUrl() + "/deals/documents";
    this.uploader = new FileUploader({
      url: this.documentUrl,
      autoUpload: true,
      isHTML5: true
    });
    this.uploader.onAfterAddingFile = f => {
      this.addDocument(f);
    };
    this.uploader.onSuccessItem = function (fileItem: any, response, status, headers) {
      var data = JSON.parse(response);
      let docIdx = fileItem.docIdx;
      let documentsControl = this.getDocumentsControl();
      documentsControl.controls[docIdx].controls["fileId"].setValue(data.data[0].fileId);
    }.bind(this);
  }

  ngOnInit() {
    this._documents = this.getDocuments(this.data[0].data);
    this._documentTypes = this.data[1].data;
    this.detailsForm = this._fb.group({
      documents: this._fb.array([])
    });
    this.initDocumentForm();
    if (this.readOnly) {
      this.detailsForm.disable();
    }
    this.initErrors();
    this.formInitialized.emit(this.detailsForm);
  }

  initErrors() {
    let error: Error = new Error();
    error.field = "type";
    error.errorKey = "required";
    error.message = "Document Type - This field is required";
    this.errors.push(error);
  }

  getDocumentsControl(): FormArray {
    return this.detailsForm.get('documents') as FormArray;
  }

  initDocumentForm() {
    let documentsControl = this.getDocumentsControl();
    this._documents.forEach(doc => {
      documentsControl.push(
        this._fb.group({
          type: [doc.type, Validators.required],
          id: [doc.id],
          fileId: [doc.fileId],
          fileName: [doc.fileName],
          action: ["update"]
        }))
    })
  }

  getDocuments(documentList: any): Document[] {
    var documents: Document[] = [];
    for (var document of documentList) {
      documents.push(Document.fromJSON(document));
    }
    return documents;
  }

  addDocument(item: any) {
    let doc: Document = new Document();
    doc.fileName = item.file.name;
    doc.uploadedDate = new Date().toString();
    let documentsControl = this.getDocumentsControl();
    documentsControl.push(
      this._fb.group({
        type: ['', Validators.required],
        id: [''],
        fileId: [''],
        fileName: [doc.fileName],
        action: ["add"]
      }))
    item.docIdx = this._documents.length;
    doc.item = item;
    this._documents.push(doc);
  }

  removeDocument(index: number) {
    this.errorService.hide();
    let documentsControl = this.getDocumentsControl();
    let docControl = documentsControl.controls[index];
    let actionValue = docControl.get("action").value;
    if (actionValue == "update") { // push docs to deleted array if doc is already saved in backend
      this._deletedDocs.push(docControl);
    }
    documentsControl.removeAt(index);
    this._documents.splice(index, 1);
  }

  getSubmissionData() {
    let data: any = {};
    let formControls = this.detailsForm.controls;
    for (let propName in formControls) {
      data[propName] = formControls[propName].value;
    }
    for (let doc of this._deletedDocs) {
      doc.get("action").setValue("delete");
      data.documents.push(doc.value);
    }
    return data.documents;
  }

  selectDocument(index: number) {
    this._selectedIndex = index;
  }

}
