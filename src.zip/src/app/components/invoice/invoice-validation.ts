import { FormControl, ValidatorFn, FormGroupDirective, NgForm } from "@angular/forms";
import { ErrorStateMatcher } from "@angular/material";
import * as BigNumber from 'bignumber.js';

export class InvoiceValidators {

    static amountValidator: ValidatorFn = (formControl: FormControl) => {
        let amount = formControl.value;
        let amountValue = amount ? amount.toString().replace(/\,/g, '') : amount;
        let amountBigNum = new BigNumber.BigNumber(amountValue);
        if (amount && amountBigNum.isLessThan(0.01)) {
            return { amountError: true };
        } 
        return null;
    }
}

export class AmountValidMatcher implements ErrorStateMatcher {
    isErrorState(control: FormControl, form: FormGroupDirective | NgForm): boolean {
        return control.invalid && control.touched;
    }
}