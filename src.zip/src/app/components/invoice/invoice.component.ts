import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray } from '@angular/forms';
import { BillingAccount } from 'src/app/models/billing-account';
import { Column } from 'src/app/models/column';
import { forkJoin } from 'rxjs';
import { ReferencesService } from 'src/app/services/references.service';
import { InvoiceValidators, AmountValidMatcher } from './invoice-validation';
import { HelperService } from 'src/app/services/helper.service';

@Component({
  selector: 'billing-invoice',
  templateUrl: './invoice.component.html',
  styleUrls: ['./invoice.component.scss']
})
export class InvoiceComponent implements OnInit {

  @Input() readOnly: boolean;
  @Input()
  billingAccount: BillingAccount;
  private _onetimeBillingIndctr: boolean;
  private _upfrntFeesIndctr: boolean;
  @Input() set onetimeBillingIndctr(value: boolean) {
    this._onetimeBillingIndctr = value;
    if (this.invoiceForm) {
      this.onOnetimeBillingChange(this.readOnly);
    }
  }
  @Output() formReady = new EventEmitter<FormGroup>();
  amountValidMatcher: AmountValidMatcher = new AmountValidMatcher();
  invoiceForm: FormGroup;
  columns: Column[] = [];
  _invoiceDistTypes: any[];
  showReqInfoMsg: boolean;
  initInvcDstrbtnOptional: boolean = true;
  cyclicalInvcDstrbtnOptional: boolean = true;
  amountConfig = {"integerDigits":16,"decimalPlaces":2};
  constructor(private _fb: FormBuilder, private referencesService: ReferencesService, private helperService: HelperService) { }

  ngOnInit() {
    let suppressInvcIndctr = this.billingAccount.suppressInvcIndctr ? this.billingAccount.suppressInvcIndctr : false;
    this.invoiceForm = this._fb.group({
      cyclicalInvcDstrbtn: [this.billingAccount.cyclicalInvcDstrbtn],
      initInvcDstrbtn: [this.billingAccount.initInvcDstrbtn],
      initInvcRqrdIndctr: [this.billingAccount.initInvcRqrdIndctr, Validators.required],
      suppressInvcIndctr: [suppressInvcIndctr],
      upfrntFeesIndctr: [this.billingAccount.upfrntFeesIndctr],
      billingAccountServices: this._fb.array([]),
      legalName: [this.billingAccount.legalName]
    });
    this.initAccountServices();
    this.formReady.emit(this.invoiceForm);
    //CTTNXNDM-15938 Initial check on indicators added below
    if (this._onetimeBillingIndctr && !this.billingAccount.upfrntFeesIndctr) {
      this.invoiceForm.get('initInvcRqrdIndctr').setValue(this.billingAccount.initInvcRqrdIndctr);
      this.invoiceForm.get('initInvcRqrdIndctr').disable();
    }
    else if (this.billingAccount.upfrntFeesIndctr) {
      this.invoiceForm.get('initInvcRqrdIndctr').setValue(this.billingAccount.initInvcRqrdIndctr);
      this.invoiceForm.get('initInvcRqrdIndctr').disable();
    }
    this.onInitialInvRqrdIndicatorChange(this.readOnly);
    if (!this.readOnly) {
      this.invoiceForm.get('initInvcRqrdIndctr').valueChanges.subscribe(value => {
        this.onInitialInvRqrdIndicatorChange(this.readOnly);
      });
      this.invoiceForm.get('upfrntFeesIndctr').valueChanges.subscribe(value => {
        this.upfrntFeesIndctrChange(this.readOnly);
      });
    }
    this.getBilledServicesColumns();
    let invoiceDistTypes = this.referencesService.getInvoiceDistributionTypes();
    forkJoin(invoiceDistTypes).subscribe((results: any[]) => {
      this._invoiceDistTypes = results[0].data;
    });
  }

  getServicesControl(): FormArray {
    return this.invoiceForm.get('billingAccountServices') as FormArray;
  }

  initAccountServices() {
    let servicesControl = this.getServicesControl();
    if (this.billingAccount.billingAccountServices) {
      this.billingAccount.billingAccountServices.forEach(service => {
        servicesControl.push(
          this._fb.group({
            billingAccountId: [service.billingAccountId],
            billedServiceName: [service.billedServiceName, Validators.required],
            billedAmount: [service.billedAmount, [Validators.required, InvoiceValidators.amountValidator]]
          }))
      })
    }
    this.onBillingAcctServicesChange();
  }

  get onetimeBillingIndctr(): boolean {
    return this._onetimeBillingIndctr;
  }

  onOnetimeBillingChange(readOnly: boolean) {
    if (this.onetimeBillingIndctr) {
      if (!readOnly) {
        this.invoiceForm.get('initInvcRqrdIndctr').setValue(this.onetimeBillingIndctr);
        this.invoiceForm.get('initInvcRqrdIndctr').disable();
        this.helperService.removeValidation(this.invoiceForm, 'cyclicalInvcDstrbtn');
      }
      this.cyclicalInvcDstrbtnOptional = true;
    } else {
      if (!readOnly) {
        this.upfrntFeesIndctrChange(this.readOnly);
        this.helperService.addValidation(this.invoiceForm, 'cyclicalInvcDstrbtn', Validators.required);
      }
      this.cyclicalInvcDstrbtnOptional = false;
    }
  }

  onInitialInvRqrdIndicatorChange(readOnly: boolean) {
    let value = this.invoiceForm.get('initInvcRqrdIndctr').value;
    if (value) {
      if (!readOnly) {
        //CTTNXNDM-15938 check on indicators added below
        this.helperService.addValidation(this.invoiceForm, 'initInvcDstrbtn', Validators.required);
        this.helperService.showFormControl(this.invoiceForm, 'billingAccountServices');
        if(!this._onetimeBillingIndctr){
          this.helperService.addValidation(this.invoiceForm, 'cyclicalInvcDstrbtn', Validators.required);
          this.cyclicalInvcDstrbtnOptional = false;
        }
      }
     
      this.initInvcDstrbtnOptional = false;
    } else {
      if (!readOnly) {
         //CTTNXNDM-15938 check on indicators added below
        this.helperService.removeValidation(this.invoiceForm, 'initInvcDstrbtn');
        this.helperService.hideFormControl(this.invoiceForm, 'billingAccountServices');
        this.helperService.addValidation(this.invoiceForm, 'cyclicalInvcDstrbtn', Validators.required);
        this.cyclicalInvcDstrbtnOptional = false;
      }
      this.initInvcDstrbtnOptional = true;
    }
  }

  // The below change is added for CTTNXNDM-15938
  upfrntFeesIndctrChange(readOnly: boolean) {
    this._upfrntFeesIndctr = this.invoiceForm.get('upfrntFeesIndctr').value;
    if (!readOnly) {
      if (this._upfrntFeesIndctr == undefined) {
        this.invoiceForm.get('initInvcRqrdIndctr').setValue(null);
        this.invoiceForm.get('initInvcRqrdIndctr').enable();
      }
      else {
        if ((this._upfrntFeesIndctr && this._onetimeBillingIndctr) || (this._upfrntFeesIndctr && !this._onetimeBillingIndctr)
          || (!this._upfrntFeesIndctr && this._onetimeBillingIndctr)) {
          this.invoiceForm.get('initInvcRqrdIndctr').setValue(true);
          this.helperService.addValidation(this.invoiceForm, 'initInvcDstrbtn', Validators.required);
          this.helperService.showFormControl(this.invoiceForm, 'billingAccountServices');
          this.initInvcDstrbtnOptional = false;
          this.invoiceForm.get('initInvcRqrdIndctr').disable();
        }
        else if(!this._upfrntFeesIndctr && !this._onetimeBillingIndctr){
          this.invoiceForm.get('initInvcRqrdIndctr').setValue(null);
          this.invoiceForm.get('initInvcRqrdIndctr').enable();
          this.helperService.removeValidation(this.invoiceForm, 'initInvcDstrbtn');
          this.helperService.hideFormControl(this.invoiceForm, 'billingAccountServices');
          this.initInvcDstrbtnOptional = true;
        }
      }
    }
  }

  getBilledServicesColumns() {
    this.columns.push({ "displayName": "Services To Be Billed", "name": "svcName" });
    this.columns.push({ "displayName": "Amount", "name": "amount" });
  }

  getServiceGroup() {
    return this._fb.group({
      billingAccountId: [],
      billedServiceName: [, Validators.required],
      billedAmount: [, [Validators.required, InvoiceValidators.amountValidator]]
    })
  }

  onBillingAcctServicesChange() {
    let data = this.billingAccount.billingAccountServices ? this.billingAccount.billingAccountServices[0] : null;
    this.showReqInfo(data);
    this.invoiceForm.get('billingAccountServices').valueChanges.subscribe(value => {
      setTimeout(() => {
        let firstRowData = value[0];
        if (firstRowData) {
          this.showReqInfo(firstRowData);
        }
      });
    });
  }

  showReqInfo(data: any) {
    let initInvcRqrdIndctr = this.invoiceForm.get('initInvcRqrdIndctr').value;
    if (initInvcRqrdIndctr && data && (!data.billedServiceName || !parseFloat(data.billedAmount))) {
      this.showReqInfoMsg = true;
    } else {
      this.showReqInfoMsg = false;
    }
  }


}
