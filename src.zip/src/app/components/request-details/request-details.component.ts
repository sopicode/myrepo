import { Component, OnInit, Input, Output, EventEmitter, Inject, ViewEncapsulation } from '@angular/core';
import { HelperService } from './../../services/helper.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Deal } from 'src/app/models/deal';
import { Error } from 'src/app/models/error';
import { Task } from 'src/app/models/task';
import { DealService } from 'src/app/services/deal.service';
import { MatDialog, MatDialogConfig } from '@angular/material';
import { SearchExistingAccount } from '../search-existing-account/search-existing-account.component';
import { BillingExistingAccount } from 'src/app/models/billing-existing-account';
import { ErrorService } from 'src/app/services/error.service';

@Component({
  selector: 'billing-request-details',
  templateUrl: './request-details.component.html',
  styleUrls: ['./request-details.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class RequestDetailsComponent implements OnInit {

  @Input() deal: Deal;
  @Input() data: any;
  @Input() readOnly: boolean;
  @Output() formInitialized = new EventEmitter<FormGroup>();
  @Output() billingTypeEvent = new EventEmitter<FormGroup>();
  productGroupName: string;
  smName: string;
  smaName: string;
  areLegalEntitiesValidated: string;
  detailsForm: FormGroup;
  billingTypeCodeOptions: any[] = [];
  errors: Error[] = [];

  private _task: Task; // holds task information
  rejectComments: string;
  displayComments: boolean = false;
  rejectReason: string;
  displayRejectReason: boolean = false;
  displayDataMismatchReason: boolean = false;
  readOnlyForReject: boolean = false;
  dataMismatchReason: string;
  existingAccountData;
  isExistingKeySelected : boolean = false;
  showExistingKeyPanel : boolean = false;


  constructor(@Inject("task") private task,private errorService: ErrorService,private dealService: DealService, private helperService: HelperService, private _fb: FormBuilder,private dialog: MatDialog) {
    this._task = Task.fromJSON(task);
  }

  extractCSM(data, smUsers, smaUsers) {
    let sm, sma;
    data.roles.forEach((item) => {
      if (item.roleCode === 'ROLE_SM') {
        sm = item.assignee;
      }
      if (item.roleCode === 'ROLE_SMA') {
        sma = item.assignee;
      }
    });
    let smUser = this.helperService.find(smUsers.data, "comitId", sm);
    if (smUser) {
      this.smName = smUser.fullName;
    }
    let smaUser = this.helperService.find(smaUsers.data, "comitId", sma);
    if (smaUser) {
      this.smaName = smaUser.fullName;
    }
  }

  ngOnInit() {
    let data = this.data[0].data;
    this.areLegalEntitiesValidated = data.areLegalEntitiesValidated;
    let isUrgent = data.isUrgent ? data.isUrgent : false;
    this.detailsForm = this._fb.group({
      billingSequenceNumber: [data.billingSequenceNumber],
      id: [data.id],
      billingRequestNumber: [data.billingRequestNumber],
      isUrgent: [isUrgent, Validators.required],
      billingTypeCode: [data.billingTypeCode, Validators.required],
      existingBillingKey: [data.existingBillingKey,Validators.required]
    });
    this.initErrors();
    if (this.readOnly) {
      this.detailsForm.disable();
    }
    this.formInitialized.emit(this.detailsForm);
    let productGroup = this.helperService.find(this.data[4].data, "id", this.deal.productGroupId);
    if (productGroup) {
      this.productGroupName = productGroup.name;
    }
    this.extractCSM(this.data[1].data, this.data[2], this.data[3]);
    this.getBillingTypeCodeOptions();

    //Added as part of 8602, poulate data from firrecall if existing key is saved.
    if (data.existingBillingKey && data.billingTypeCode == 'E') {
      let endPoint = "search-billing-accounts";
      this.isExistingKeySelected = true;
      this.showExistingKeyPanel = true;
      let formData = {
        accountKey : data.existingBillingKey
      }
      this.dealService.postForm(null, endPoint,formData).subscribe(
        data => {
          this.existingAccountData = data.data.accountLookupData[0];
        }
      )
    }

    if (!this._task.variables.isApproveTask && null != this._task.variables.billingStatus) {
      //Review Rework
      if ("BILL_RQST_REJ" == this._task.variables.billingStatus) {
        this.rejectComments = this._task.variables.rejectionComments;
        this.displayComments = true;
      }
      //Data Mismatch
      if ("BILL_RQST_DATA_MISMATCH" == this._task.variables.billingStatus) {
        this.dataMismatchReason = this._task.variables.rejectionComments;
        this.displayDataMismatchReason = true;
      }
      //Tech Error
      if ("BILL_RQST_TECH_ERROR" == this._task.variables.billingStatus) {
        this.dataMismatchReason = this._task.variables.ebwConnectionErrorMessage;
        this.displayDataMismatchReason = true;
      }
      //Returned From Billing
      if ("BILL_RQST_RETURNED" == this._task.variables.billingStatus) {
        this.rejectComments = this._task.variables.rejectionComments;
        this.displayComments = true;
        this.rejectReason = this._task.variables.rejectReason;
        this.displayRejectReason = true;
      }
      //Show read only data, if it is any task after being retruned from Billing
      if (null != this._task.variables.rejectReason && this._task.variables.rejectReason != "Incorrect request type") {
        this.readOnlyForReject = true;
      }

    }
     if(data&&data.billingTypeCode == 'E'){
        this.showExistingKeyPanel = true;
      }
      else{
        this.showExistingKeyPanel = false;
      }
    this.billingTypeEvent.emit(this.detailsForm.get('billingTypeCode').value);
    this.detailsForm.get('billingTypeCode').valueChanges.subscribe(value => {
      this.billingTypeEvent.emit(value);
      if(value == 'E'){
        this.showExistingKeyPanel = true;
        this.detailsForm.get('existingBillingKey').setValidators(Validators.required);
      }
      else{
        this.showExistingKeyPanel = false;
        this.detailsForm.get('existingBillingKey').setValidators(null);
        this.detailsForm.get('existingBillingKey').updateValueAndValidity();
      }
    });
  }

  getSearchExistingKeyData()
  {
    if(this.detailsForm.get('billingTypeCode').value=='E')
    {
      let data={"accountKey":this.detailsForm.get('existingBillingKey').value,"exactmatch":"0"};
      return data;
    }
    return null;
  }

  initErrors() {
    this.errors.push(this.helperService.buildError("isUrgent", "Is this an urgent request? - This field is required", "required"));
    this.errors.push(this.helperService.buildError("billingTypeCode", "Type of Billing Key - This field is required", "required"));
    this.errors.push(this.helperService.buildError("existingBillingKey", "Billing Key - This field is required", "required"));
  }

  getBillingTypeCodeOptions() {
    this.billingTypeCodeOptions.push(this.buildOption('N', "New"));
    this.billingTypeCodeOptions.push(this.buildOption('E', "Existing"));
  }

  buildOption(key: string, value: string) {
    let option: any = {};
    option.key = key;
    option.value = value;
    return option;
  }

  openSearchForm(){
    const dialogConfig = new MatDialogConfig();
    dialogConfig.autoFocus = false;
    dialogConfig.hasBackdrop = true;
    dialogConfig.disableClose = true;
    dialogConfig.panelClass = ['billingAcctDetPopup', 'billing'];
    dialogConfig.maxWidth = '99vw';
    dialogConfig.width = '96vw';
    dialogConfig.data = { "deal": this.deal, "accountKey": this.detailsForm.get('existingBillingKey').value,"title":"Search Billing Key" ,"isFromRequestDetails": true, "buttonText": "Select Billing Key"};
    let dialogRef = this.dialog.open(SearchExistingAccount, dialogConfig);
    dialogRef.afterClosed().subscribe(data => {
      if (data) {
        let dataKeys = data.existingAccountKey;
        let existingKeyObj = {};
        for (let key of Object.keys(dataKeys)) {
          existingKeyObj[key.slice(1)] = dataKeys[key];
          this.existingAccountData = existingKeyObj;
        }
        this.isExistingKeySelected = data.isExistingKeySelected;
        this.showExistingKeyPanel =true;
        this.detailsForm.get('existingBillingKey').setValue(data.selectedBillingKey);
      }
    });
  }

  deletePanel(){
    this.isExistingKeySelected = false;
    this.showExistingKeyPanel =false;
    this.existingAccountData =null;
    this.detailsForm.get('existingBillingKey').setValue(null);
  }

}