import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'billing-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  @Input() deal: any;
  @Input() riskRatingCode: string;
  @Input() dealTypeName: string;
  @Input() dealRegionName: string;
  @Input() majorProductTypeSource: string;

  constructor() { }

  ngOnInit() {
  }

}
