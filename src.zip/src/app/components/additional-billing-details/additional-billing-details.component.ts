import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Deal } from 'src/app/models/deal';
import { Wizard } from 'src/app/models/wizard';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ReferencesService } from '../../services/references.service';
import { HelperService } from '../../services/helper.service';
import { Error } from 'src/app/models/error';
import { CustomerDetail } from 'src/app/models/customer-details';

@Component({
  selector: 'billing-additional-billing-details',
  templateUrl: './additional-billing-details.component.html',
  styleUrls: ['./additional-billing-details.component.scss']
})
export class AdditionalBillingDetailsComponent implements OnInit {

  @Input() deal: Deal;
  @Input() data: any;
  @Input() wizard: Wizard;
  @Input() readOnly: boolean;
  @Output() formInitialized = new EventEmitter<FormGroup>();
  detailsForm: FormGroup;
  requestDetailsData: any;
  accountDetailsData: any;
  customer: any;
  feeTemplateOptions: any[];
  withHoldingTaxBearerOptions: any[];
  withHoldingTypeOptions: any[];
  countries: any[];
  states: any[];
  errors: Error[] = [];
  isUSOrCanada: boolean;
  legalEntities: any[];

  hideBillingDetailsDoNotApply: boolean = false;
  showSpvIndicator: boolean = false;
  showIrishQualifyingFund: boolean = false;
  withholdingTaxBearerCodeErrMsg: string;
  stateLabel:string = "Parent Country's State/Province";

  constructor(private _fb: FormBuilder, private referencesService: ReferencesService, private helperService: HelperService) { }

  ngOnInit() {
    let data = this.data[0].data;
    this.requestDetailsData = this.data[1].data;
    this.accountDetailsData = this.data[2].data;
    let customerData = this.buildCustomer(this.data[3].data);
    this.extractCustomer(customerData);
    this.feeTemplateOptions = this.data[4].data;
    this.withHoldingTaxBearerOptions = this.data[5].data;
    this.withHoldingTypeOptions = this.data[6].data;
    this.countries = this.data[7].data;
    this.legalEntities = this.data[8].data;
    this.isUSOrCanada = data.countryCode == "CAN" || data.countryCode == "USA";
    if (this.isUSOrCanada) {
      this.referencesService.getCountrySubDivisions(data.countryCode).subscribe((value: any) => {
        this.states = value.data;
      });
    }
    this.detailsForm = this._fb.group({
      id: [data.id],
      achIndicator: [data.achIndicator,Validators.required],
      feeTemplateCode: [data.feeTemplateCode,Validators.required],
      withholdingTaxBearerCode: [data.withholdingTaxBearerCode,Validators.required],
      withholdingTypeCode: [data.withholdingTypeCode,Validators.required],
      spvIndicator: [data.spvIndicator,Validators.required],
      countryCode: [data.countryCode,Validators.required],
      statusCode: [data.statusCode,Validators.required],
      irishQualifyingFund: [data.irishQualifyingFund,Validators.required]
    });
    // if major product is document custody, show "ACH" and "Fee Template"
    if (this.deal.majorProductId === 56) {
      this.helperService.showFormControl(this.detailsForm,"achIndicator");
      this.helperService.showFormControl(this.detailsForm,"feeTemplateCode");
    } else {
      this.helperService.hideFormControl(this.detailsForm,"achIndicator");
      this.helperService.hideFormControl(this.detailsForm,"feeTemplateCode");
    }
    // If Customer Country of Domicile belongs to Withholding Tax Applicable List of Countries display new field "Client or BNYM Bear Withholding Tax?" 
    if (this.customer.isCountryWithholdingTaxApplicable) {
      this.helperService.showFormControl(this.detailsForm,"withholdingTaxBearerCode");
    } else {
      this.helperService.hideFormControl(this.detailsForm,"withholdingTaxBearerCode");
    }
    this.initErrors();
    this.formInitialized.emit(this.detailsForm);
    // if Legal Entity = "BNY Mellon Singapore (00272)" in any of the Billing Accounts AND If Customer Country of Domicile is NOT "Singapore"
    this.showSpvIndicator = this.isSingaporeLegalEntity() && this.customer && this.customer.country !== 'SGP';
    // If Legal Entity = "00539 BNY Mellon SA/NV, Dublin Branch" in any of the Billing Accounts AND If Customer Country of Domicile belongs to European Union 
    this.showIrishQualifyingFund = this.isDublinLegalEntity() && this.customer && this.customer.isEU;
    this.hideBillingDetailsDoNotApplyMessage();
    if (this.readOnly || !this.hideBillingDetailsDoNotApply) {
      this.detailsForm.disable();
    }
    if (this.showSpvIndicator) {
      this.helperService.showFormControl(this.detailsForm,"spvIndicator");
    } else {
      this.helperService.hideFormControl(this.detailsForm,"spvIndicator");
    }
    if (this.showIrishQualifyingFund) {
      this.helperService.showFormControl(this.detailsForm,"irishQualifyingFund");
    } else {
      this.helperService.hideFormControl(this.detailsForm,"irishQualifyingFund");
    }
    if (!this.readOnly) {
      this.onWithholdingTaxBearerCodeChange(data.withholdingTaxBearerCode);
      this.detailsForm.get('withholdingTaxBearerCode').valueChanges.subscribe(value => {
        this.onWithholdingTaxBearerCodeChange(value);
      });
      this.onSpvIndicatorChange(data.spvIndicator);
      this.detailsForm.get('spvIndicator').valueChanges.subscribe(value => {
        this.onSpvIndicatorChange(value);
      });
      this.onCountryCodeChange(data.countryCode);
      this.detailsForm.get('countryCode').valueChanges.subscribe(value => {
        this.onCountryCodeChange(value);
      });
    }
    this.withholdingTaxBearerCodeErrMsg = "Client or BNYM Bear Withholding Tax? is mandatory when the Customer's Country of Domicile is " + this.customer.country;
  }

  buildCustomer(customerList: any): CustomerDetail[] {
    let customer: CustomerDetail[] = [];
    if (Array.isArray(customerList)) {
      customerList.forEach((customers, index) => {
        let customerDetail: CustomerDetail = CustomerDetail.fromJSON(customers)
        customer.push(customerDetail);
      });
      return customer;
    }
  }

  // extract selected customer from list of customers
  extractCustomer(d) {
    if (d.length > 1) {
      let selectedCust = this.helperService.filterByKey(d, "isSelected", true);
      if (selectedCust && selectedCust.length > 0) {
        this.customer = selectedCust[0];
      }
    } else {
      this.customer = d[0];
    }
    if (!this.customer) {
      this.customer = new CustomerDetail();
    }
  }

  initErrors() {
    this.errors.push(this.helperService.buildError("achIndicator", "ACH is mandatory when Major Product is Document Custody", "required"));
    this.errors.push(this.helperService.buildError("feeTemplateCode", "Fee Template is mandatory when Major Product is Document Custody", "required"));
    this.errors.push(this.helperService.buildError("withholdingTaxBearerCode", "Client or BNYM Bear Withholding Tax? is mandatory when the Customer's Country of Domicile is " + this.customer.country, "required"));
    this.errors.push(this.helperService.buildError("withholdingTypeCode", "Type of Withholding is mandatory when BNYM bears the Withholding Tax", "required"));
    this.errors.push(this.helperService.buildError("spvIndicator", "SPV is mandatory when Legal Entity is BNY Mellon Singapore (00272) and Customer Country of Domicile does not belong to Singapore", "required"));
    this.errors.push(this.helperService.buildError("countryCode", "Parent Country of SPV is mandatory when SPV is Yes", "required"));
    this.errors.push(this.helperService.buildError("statusCode", "Parent Country's State/Province - This field is required", "required"));
    this.errors.push(this.helperService.buildError("irishQualifyingFund", "Irish Qualifying Fund? is mandatory when the legal entity is 00539 BNY Mellon SA/NV Dublin Branch and the Customer Country of Domicile belongs to EU", "required"));
  }

  hideBillingDetailsDoNotApplyMessage() {
    this.hideBillingDetailsDoNotApply = ((this.requestDetailsData.billingTypeCode == 'N') &&
      (this.deal.majorProductId == 56 || (this.customer && this.customer.isCountryWithholdingTaxApplicable) ||
        this.showSpvIndicator || this.showIrishQualifyingFund));
  }

  //  Check if legal entity is BNY Mellon Singapore (00272) in any of the Billing Accounts 
  isSingaporeLegalEntity() {
    return this.helperService.some(this.accountDetailsData, function (accountDetail) {
      let selectedLegalEntity = this.helperService.find(this.legalEntities, "id", accountDetail.partyId);
      return selectedLegalEntity ? selectedLegalEntity.externalLegalEntityId == "00272": false;
    }.bind(this));
  }

  //  Check if legal entity is 00539 BNY Mellon SA/NV Dublin Branch in any of the Billing Accounts 
  isDublinLegalEntity() {
    return this.helperService.some(this.accountDetailsData, function (accountDetail) {
      let selectedLegalEntity = this.helperService.find(this.legalEntities, "id", accountDetail.partyId);
      return selectedLegalEntity ? selectedLegalEntity.externalLegalEntityId == "00539": false;
    }.bind(this));
  }

  // When "Client or BNYM Bear Withholding Tax?" = "BNYM" then display a new field "Type of Withholding" 
  onWithholdingTaxBearerCodeChange(value: any) {
    if (value === 'BNYM') {
      this.helperService.showFormControl(this.detailsForm,"withholdingTypeCode");
    } else {
      this.helperService.hideFormControl(this.detailsForm,"withholdingTypeCode");
    }
  }

  // If SPV = "YES" then display a new field "Parent Country of SPV" 
  onSpvIndicatorChange(value: boolean) {
    if (value) {
      this.helperService.showFormControl(this.detailsForm,"countryCode");
    } else {
      this.helperService.hideFormControl(this.detailsForm,"countryCode");
      this.helperService.hideFormControl(this.detailsForm,"statusCode");
    }
  }

  // If Parent Country of SPV is not " United States of America" or "Canada" then do not display the "Parent Country's State/Province" field. 
  onCountryCodeChange(value: string) {
    if (value === 'CAN' || value === 'USA') {
      this.helperService.showFormControl(this.detailsForm,"statusCode");
      this.referencesService.getCountrySubDivisions(value).subscribe((value: any) => {
        this.states = value.data;
      });
    } else {
      this.helperService.hideFormControl(this.detailsForm,"statusCode");
    }
  }

}
