import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdditionalBillingDetailsComponent } from './additional-billing-details.component';

describe('AdditionalBillingDetailsComponent', () => {
  let component: AdditionalBillingDetailsComponent;
  let fixture: ComponentFixture<AdditionalBillingDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdditionalBillingDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdditionalBillingDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
