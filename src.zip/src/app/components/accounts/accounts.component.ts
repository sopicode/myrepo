import { Component, OnInit, Input, Output, EventEmitter, Inject } from '@angular/core';
import { Deal } from 'src/app/models/deal';
import { Wizard } from 'src/app/models/wizard';
import { BillingAccounts } from 'src/app/models/billing-accounts';
import { BillingAccount } from 'src/app/models/billing-account';
import { FormGroup, FormBuilder, FormArray, Validators, FormControl } from '@angular/forms';
import { Error } from 'src/app/models/error';
import { FormService } from 'src/app/services/form.service';
import { HelperService } from 'src/app/services/helper.service';
import { DealService } from 'src/app/services/deal.service';
import { ErrorService } from 'src/app/services/error.service';
import { Task } from 'src/app/models/task';
import { MatDialogConfig, MatDialog } from '@angular/material';
import { SearchExistingAccount } from '../search-existing-account/search-existing-account.component';
import { ReferencesService } from 'src/app/services/references.service';
import { forkJoin } from 'rxjs';

@Component({
  selector: 'billing-accounts',
  templateUrl: './accounts.component.html',
  styleUrls: ['./accounts.component.scss']
})
export class AccountsComponent implements OnInit {

  @Input() deal: Deal;
  @Input() data: any;
  @Input() wizard: Wizard;
  @Input() readOnly: boolean;
  @Output() formInitialized = new EventEmitter<FormGroup>();
  detailsForm: FormGroup;
  _legalEntities: any[];
  errors: Error[] = [];
  private _billingAccounts: BillingAccount[];
  _selectedIndex: number = 0;
  isNewBilling: boolean = false;
  readOnlyForReject: boolean = false;
  _showDuplicateBtn: boolean = false;
  _task: Task;
  totalAccountCount: number = 0;
  copybillingAccounts: BillingAccount[] = [];
  prorationRules: any[];
  feeAccrlMethods: any[];
  feeBillingFrequencies: any[];
  prepaidFees: any[];
  billingCurrencies: any[];
  costCenters: any[];
  accountBillingFrequencies: any[] = [];
  splBillinglegalEntities: any[] = [];


  constructor(@Inject("task") private task, private referencesService: ReferencesService, private dialog: MatDialog, private _fb: FormBuilder, private formService: FormService, private helperService: HelperService, private dealService: DealService, private errorService: ErrorService) {
    this._task = Task.fromJSON(task);
  }

  ngOnInit() {
    let billingAccts: BillingAccounts = BillingAccounts.fromJSON(this.data[0].data);
    this._legalEntities = this.data[1].data;
    this._billingAccounts = billingAccts.billingAccounts;
    this.detailsForm = this._fb.group({
      accounts: this._fb.array([])
    });
    let prorationRules = this.referencesService.getProrationRules();
    let feeAccrlMethods = this.referencesService.getFeeAccrlMethods();
    let billingFrequency = this.referencesService.getBillingFrequencySource();
    let costCentersPromise = this.referencesService.getCostCenters();
    let billingCurrenciesPromise = this.referencesService.getBillingCurrencies();
    let billingFrequenciesPromise = this.referencesService.getBillingFrequencies();
    let splBillinglegalEntities = this.dealService.getBillingLegalEntities(this.deal.id, this._task.variables.specialBillingLegalEntity);
    forkJoin(prorationRules, feeAccrlMethods, billingFrequency, costCentersPromise, billingCurrenciesPromise, billingFrequenciesPromise, splBillinglegalEntities).subscribe((results: any[]) => {
      this.prorationRules = results[0].data;
      this.feeAccrlMethods = results[1].data;
      this.feeBillingFrequencies = results[2].data;
      this.costCenters = results[3].data;
      this.billingCurrencies = results[4].data;
      this.accountBillingFrequencies = results[5].data;
      this.splBillinglegalEntities = results[6].data;
    });
    this.prepaidFees = this.getPrepaidOptions();
    this.initAccountForm();
    this.initErrors();
    if (this.readOnly) {
      this.detailsForm.disable();
    }
    if (this.data[2]) {
      let billingTypeCode = this.data[2].data.billingTypeCode;
      if (billingTypeCode == "N") {
        this.isNewBilling = true;
      }
    }
    this.formInitialized.emit(this.detailsForm);
    if (null != this._task.variables.rejectReason && this._task.variables.rejectReason != "Incorrect request type" && !this._task.variables.isApproveTask) {
      this.readOnlyForReject = true;
    }
    this.duplicateAccountUpdate();
  }

  getPrepaidOptions() {
    let options: any[] = [];
    options.push(this.helperService.buildOption("Y", "Yes"));
    options.push(this.helperService.buildOption("N", "No"));
    return options;
  }

  initErrors() {
    this.errors.push(this.helperService.buildError("billingKey", "Proposed Billing Key - This field is required", "required"));
    this.errors.push(this.helperService.buildError("acctShortName", "Billing Account Short Name - This field is required", "required"));
    this.errors.push(this.helperService.buildError("acctLongName", "Billing Account Long Name - This field is required", "required"));
  }

  getAccountsArray(): FormArray {
    return this.detailsForm.get('accounts') as FormArray;
  }

  initAccountForm() {
    let accountsFormArray = this.getAccountsArray();
    if (this._billingAccounts && this._billingAccounts.length > 0) {
      this._billingAccounts.forEach(account => {
        let accountGroup = this.getAccountForm(account);
        accountsFormArray.push(accountGroup)
        this.initRoles(account, accountGroup);
        this.initAccountServices(account, accountGroup);
        this.initLinks(account, accountGroup);
        this.initFees(account, accountGroup);
      })
      let acctDiff = this.totalAccountCount - this._billingAccounts.length;
      if (acctDiff > 0 && this.totalAccountCount > 0) {
        let ignoreCountUpdate = true;
        for (var i = 0; i < acctDiff; i++) {
          if (this.copybillingAccounts[i]) {
            this.addBillingAccount(this.copybillingAccounts[i], ignoreCountUpdate);
          }
        }
      }
    } else {
      // add a empty card if there are no existing cards
      let account: BillingAccount = new BillingAccount();
      let accountGroup = this.getAccountForm(account);
      accountsFormArray.push(accountGroup);
      this._billingAccounts.push(account);
    }
  }

  getAccountForm(account: BillingAccount): FormGroup {
    let acctShortName = account.acctShortName ? account.acctShortName : this.deal.shortName;
    let acctLongName = account.acctLongName ? account.acctLongName : this.deal.longName
    return this._fb.group({
      id: [account.id],
      billingRequestId: [account.billingRequestId],
      billingKey: [account.billingKey, Validators.required],
      acctShortName: [acctShortName, Validators.required],
      acctLongName: [acctLongName, Validators.required],
      currencyCd: [account.currencyCd],
      invcLanguageCode: [account.invcLanguageCode],
      costCenterCode: [account.costCenterCode],
      billDay: [account.billDay],
      billingFrequency: [account.billingFrequency],
      gvrnmntClntIndctr: [account.gvrnmntClntIndctr],
      onetimeBillingIndctr: [account.onetimeBillingIndctr],
      billingStartDate: [account.billingStartDate],
      maturityDate: [account.maturityDate],
      nextBillDate: [account.nextBillDate],
      partyId: [account.partyId],
      clientCategoryIndctr: [account.clientCategoryIndctr],
      roles: this._fb.array([]),
      cyclicalInvcDstrbtn: [account.cyclicalInvcDstrbtn],
      initInvcDstrbtn: [account.initInvcDstrbtn],
      initInvcRqrdIndctr: [account.initInvcRqrdIndctr],
      suppressInvcIndctr: [account.suppressInvcIndctr],
      upfrntFeesIndctr: [account.upfrntFeesIndctr],
      billingAccountServices: this._fb.array([]),
      legalName: [account.legalName],
      links: this._fb.array([]),
      separateBillingDisplayIndctr: [account.separateBillingDisplayIndctr],
      isEU: [account.isEU],
      feeScheduleMatchIndctr: [account.feeScheduleMatchIndctr],
      feeAndServiceDetails: this._fb.array([]),
    })
  }

  initFees(account: BillingAccount, formGroup: FormGroup) {
    let feesControl = formGroup.get('feeAndServiceDetails') as FormArray;
    account.feeAndServiceDetails.forEach(feeAndServiceDetail => {
      feesControl.push(
        this._fb.group({
          billingAccountId: [feeAndServiceDetail.billingAccountId],
          componentName: [feeAndServiceDetail.componentName, Validators.required],
          prorationRuleCode: [feeAndServiceDetail.prorationRuleCode, Validators.required],
          advanceOrArrearsCode: [feeAndServiceDetail.advanceOrArrearsCode, Validators.required],
          flatFee: [feeAndServiceDetail.flatFee],
          ratePerItem: [feeAndServiceDetail.ratePerItem],
          tier: [feeAndServiceDetail.tier],
          minimumAmount: [feeAndServiceDetail.minimumAmount],
          maximumAmount: [feeAndServiceDetail.maximumAmount],
          billingFrequencyCode: [feeAndServiceDetail.billingFrequencyCode, Validators.required],
          upfrontOrPrepaidFees: [feeAndServiceDetail.upfrontOrPrepaidFees, Validators.required]
        }))
    })
  }

  initRoles(account: BillingAccount, formGroup: FormGroup) {
    let rolesControl = formGroup.get('roles') as FormArray;
    account.roles.forEach(role => {
      rolesControl.push(
        this._fb.group({
          partyRoleId: [role.partyRoleId]
        }))
    })
  }

  initAccountServices(account: BillingAccount, formGroup: FormGroup) {
    let servicesControl = formGroup.get('billingAccountServices') as FormArray;
    account.billingAccountServices.forEach(service => {
      servicesControl.push(
        this._fb.group({
          billingAccountId: [service.billingAccountId],
          billedServiceName: [service.billedServiceName],
          billedAmount: [service.billedAmount]
        }))
    })
  }

  initLinks(account: BillingAccount, formGroup: FormGroup) {
    let linksControl = formGroup.get('links') as FormArray;
    account.links.forEach(link => {
      linksControl.push(
        this._fb.group({
          id: [link.id],
          billingAccountId: [link.billingAccountId],
          systemId: [link.systemId],
          subSystem: [link.subSystem],
          accountNumber: [link.accountNumber],
          systemPurpose: [link.systemPurpose],
          isSelected: [link.isSelected],
          action: [link.action]
        }))
    })
  }

  addBillingAccount(sourceAccount?: BillingAccount, ignoreCountUpdate?: boolean) {
    let billingAccount: BillingAccount = new BillingAccount();
    // set default values from deal data
    billingAccount.acctShortName = this.deal.shortName;
    billingAccount.acctLongName = this.deal.longName;
    this.setAccountDetails(billingAccount, sourceAccount, ignoreCountUpdate);
    let accountGroup = this.getAccountForm(billingAccount);
    let accountsFormArray = this.getAccountsArray();
    accountsFormArray.push(accountGroup);
    this._selectedIndex = this._billingAccounts.length - 1;
    if (!(this._billingAccounts.length < 10)) {
      this._showDuplicateBtn = false;
    }
    this.totalAccountCount = this._billingAccounts.length;
  }

  setAccountDetails(billingAccount: BillingAccount, sourceAccount?: BillingAccount, ignoreCountUpdate?: boolean) {
    if (sourceAccount) {
      if (sourceAccount.isCopyAccount) {
        sourceAccount.id = null;
        sourceAccount.billingKey = null;
        sourceAccount.acctShortName = this.deal.shortName;
        sourceAccount.acctLongName = this.deal.longName;
        this._billingAccounts.push(sourceAccount);
        if (!ignoreCountUpdate) {
          this.copybillingAccounts.push(sourceAccount);
        }
      }
      else {
        billingAccount.duplicateAccountKey = sourceAccount.billingKey;
        this._billingAccounts.push(billingAccount);
      }
    }
    else {
      this._billingAccounts.push(billingAccount);
    }
  }

  copyFromExistingBillingAccount() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.autoFocus = false;
    dialogConfig.hasBackdrop = true;
    dialogConfig.disableClose = true;
    dialogConfig.panelClass = ['billingAcctDetPopup', 'billing'];
    dialogConfig.maxWidth = '99vw';
    dialogConfig.width = '96vw';
    dialogConfig.data = { "title": "Copy From Existing Billing Account", "buttonText": "Copy Billing Account", "deal": this.deal, "accountCount": this.getAccountsArray().length };
    let dialogRef = this.dialog.open(SearchExistingAccount, dialogConfig);
    dialogRef.afterClosed().subscribe(data => {
      if (data && data.count && data.selectedBillingKey) {
        this.copyAccounts(data.count, data.selectedBillingKey);
      }
    });
  }

  copyAccounts(count: number, selectedBillingKey: string) {
    let dealId = this.deal.id;
    this.dealService.getFormData(dealId + "/billing-accounts/" + selectedBillingKey + "/existing-billing-account-data").subscribe(
      data => {
        for (let i = 0; i < count; i++) {
          let billingAccount: BillingAccount;
          if (data.data[0]) {
            billingAccount = BillingAccount.fromJSON(data.data[0]);
          }
          else {
            billingAccount = new BillingAccount();
          }
          billingAccount.isCopyAccount = true;
          this.addBillingAccount(billingAccount);
        }
      });
  }

  deleteBillingAcct(index: number) {
    let accountsFormArray = this.getAccountsArray();
    let dealId = this.deal.id;
    let task = Task.fromJSON(this.task);
    let endPoint = "billing-requests/" + task.variables.billingRequestId + "/billing-account-details"
    let reqBody = {};
    let data = [];
    let accDetails: any = {};
    accDetails.action = "delete";
    this.formService.collectData(accountsFormArray.controls[index], accDetails);
    if (accDetails.id) {
      data.push(accDetails);
      this.wizard.action = "save";
      reqBody["wizard"] = Wizard.toJSON(this.wizard);
      reqBody["data"] = data;
      this.dealService.postForm(dealId, endPoint, reqBody).subscribe(
        data => {
          accountsFormArray.removeAt(index);
          this._billingAccounts.splice(index, 1);
          this.duplicateAccountUpdate();
          if (this.totalAccountCount) {
            this.totalAccountCount--;
          }
        });
    } else {
      if (this.totalAccountCount) {
        this.totalAccountCount--;
        let copyIndex = this.copybillingAccounts.indexOf(this._billingAccounts[index]);
        if (copyIndex >= 0) {
          this.copybillingAccounts.splice(copyIndex, 1);
        }
      }
      accountsFormArray.removeAt(index);
      this._billingAccounts.splice(index, 1);
    }
    this.duplicateAccountUpdate();
  }

  duplicateAccountUpdate() {
    if (this._billingAccounts.length < 10) {
      this._showDuplicateBtn = true;
    }
  }

  selectAccount(index: number) {
    this._selectedIndex = index;
  }

  accountUpdate() {
    let dealId = this.deal.id;
    let task = Task.fromJSON(this.task);
    if (!this.readOnly) {
      this.dealService.getFormData(dealId + "/billing-requests/" + task.variables.billingRequestId + "/billing-account-details").subscribe(
        data => {
          let billingAccts: BillingAccounts = BillingAccounts.fromJSON(data.data);
          this._billingAccounts = billingAccts.billingAccounts;
          let accountsArray = this.getAccountsArray();
          this.helperService.clearFormArray(accountsArray);
          this.initAccountForm();
        });
    }
  }

  showServerError($event) {
    this.errorService.show($event);
  }

  getSubmissionData() {
    let data: any = {};
    this.formService.collectData(this.detailsForm, data);
    return data.accounts;
  }

}
