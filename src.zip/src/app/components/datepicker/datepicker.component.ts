import { Component, OnInit, Input, TemplateRef } from '@angular/core';
import { FormControl } from '@angular/forms';
import { ErrorStateMatcher } from '@angular/material';

@Component({
  selector: 'billing-datepicker',
  templateUrl: './datepicker.component.html',
  styleUrls: ['./datepicker.component.scss']
})
export class DatepickerComponent implements OnInit {

  @Input()
  placeholder: string;
  @Input()
  datePickerCtrl: FormControl;
  @Input()
  readOnly: boolean = false;
  @Input()
  errorMsg: string;
  @Input()
  optional: boolean = false;
  @Input()
  errorStateMatcher: ErrorStateMatcher;
  @Input()
  errorTemplate: TemplateRef<any>;

  constructor() { }

  ngOnInit() {
  }
  
}
