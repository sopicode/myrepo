import { Component, OnInit, Input, Output, EventEmitter, ChangeDetectionStrategy, NgZone, ViewChild, ViewEncapsulation, ChangeDetectorRef } from '@angular/core';
import { BillingAccount } from 'src/app/models/billing-account';
import { FormGroup, FormBuilder, Validators, FormArray, AbstractControl } from '@angular/forms';
import { Column } from 'src/app/models/column';
import { BehaviorSubject } from 'rxjs';
import { HelperService } from 'src/app/services/helper.service';
import { ServiceFeeValidators, AmountValidMatcher, FlatFeeRateTierValidMatcher } from './service-fee-validation';


@Component({
  selector: 'billing-services-fees',
  templateUrl: './services-fees.component.html',
  styleUrls: ['./services-fees.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None
})
export class ServicesFeesComponent implements OnInit {

  @Input() readOnly: boolean;
  @Input()
  billingAccount: BillingAccount;
  @Input() prorationRules: any[];
  @Input() feeAccrlMethods: any[];
  @Input() billingFrequency: any[];

  @Output() formReady = new EventEmitter<FormGroup>();
  feesForm: FormGroup;
  amountValidMatcher: AmountValidMatcher = new AmountValidMatcher();
  flatFeeRateTierMatcher: FlatFeeRateTierValidMatcher = new FlatFeeRateTierValidMatcher();
  columns: Column[] = [];
  _prepaidFees: any[];
  dataSource = new BehaviorSubject<AbstractControl[]>([]);
  amountConfig = {"integerDigits":16,"decimalPlaces":2};

  columnsToDisplay = ["componentName", "prorationRuleCode", "advanceOrArrearsCode", "flatFee", "ratePerItem",
    "tier", "minimumAmount", "maximumAmount", "billingFrequencyCode", "upfrontOrPrepaidFees", "delete"];

  constructor(private _fb: FormBuilder, private helperService: HelperService,private ref:ChangeDetectorRef) { }

  ngOnInit() {
    this._prepaidFees = this.getPrepaidOptions();
    this.feesForm = this._fb.group({
      feeScheduleMatchIndctr: [this.billingAccount.feeScheduleMatchIndctr, Validators.required],
      feeAndServiceDetails: this._fb.array([]),
    });
    this.initFees();
    this.formReady.emit(this.feesForm);
    if (!this.readOnly) {
      this.onFeesIndicatorChange();
    } else {
      this.getFeesColumns();
    }
    this.feesForm.get('feeScheduleMatchIndctr').valueChanges.subscribe(selectedValue => {
      this.onFeesIndicatorChange();
    })
  }

  getFeesControl(): FormArray {
    return this.feesForm.get('feeAndServiceDetails') as FormArray;
  }

  initFees() {
    let feesControl = this.getFeesControl();
    if (this.billingAccount.feeAndServiceDetails) {
      this.billingAccount.feeAndServiceDetails.forEach(feeAndServiceDetail => {
        // let prorationRule=this.helperService.filterByKey(this.prorationRules, "name", feeAndServiceDetail.prorationRuleCode)[0];
        // let advanceOrArrears=this.helperService.filterByKey(this.feeAccrlMethods, "name", feeAndServiceDetail.advanceOrArrearsCode)[0];
        // let freq=this.helperService.filterByKey(this.billingFrequency, "name", feeAndServiceDetail.billingFrequencyCode)[0];
        // let prepaidFees=this.helperService.filterByKey(this._prepaidFees, "value", feeAndServiceDetail.upfrontOrPrepaidFees)[0];
        let feeServiceGroup: FormGroup = this._fb.group({
          billingAccountId: [feeAndServiceDetail.billingAccountId],
          componentName: [{ value: feeAndServiceDetail.componentName, disabled: this.billingAccount.feeScheduleMatchIndctr }, Validators.required],
          prorationRuleCode: [{ value: feeAndServiceDetail.prorationRuleCode, disabled: this.billingAccount.feeScheduleMatchIndctr }, Validators.required],
          advanceOrArrearsCode: [{ value: feeAndServiceDetail.advanceOrArrearsCode, disabled: this.billingAccount.feeScheduleMatchIndctr }, Validators.required],
          flatFee: [feeAndServiceDetail.flatFee],
          ratePerItem: [feeAndServiceDetail.ratePerItem],
          tier: [feeAndServiceDetail.tier],
          minimumAmount: [feeAndServiceDetail.minimumAmount],
          maximumAmount: [feeAndServiceDetail.maximumAmount],
          billingFrequencyCode: [{ value: feeAndServiceDetail.billingFrequencyCode, disabled: this.billingAccount.feeScheduleMatchIndctr }, Validators.required],
          upfrontOrPrepaidFees: [{ value: feeAndServiceDetail.upfrontOrPrepaidFees, disabled: this.billingAccount.feeScheduleMatchIndctr }, Validators.required]
        }, {
            validator: [ServiceFeeValidators.amountValidator, ServiceFeeValidators.flatFeeRateTierValidator]
          });
        feesControl.push(feeServiceGroup);
      })
      this.dataSource.next(feesControl.controls);
    }
  }

  getFeeGroup() {
    return this._fb.group({
      billingAccountId: [],
      componentName: [, Validators.required],
      prorationRuleCode: [, Validators.required],
      advanceOrArrearsCode: [, Validators.required],
      flatFee: [],
      ratePerItem: [],
      tier: [],
      minimumAmount: [],
      maximumAmount: [],
      billingFrequencyCode: [, Validators.required],
      upfrontOrPrepaidFees: [, Validators.required]
    }, {
        validator: [ServiceFeeValidators.amountValidator, ServiceFeeValidators.flatFeeRateTierValidator]
      })
  }

  onFeesIndicatorChange() {
    let value = this.feesForm.get('feeScheduleMatchIndctr').value;
    if (value) {
      this.helperService.hideFormControl(this.feesForm, 'feeAndServiceDetails');
    }
    else if (value == false) { // reason to check false is null case case shouldn't go inside
      let feesControl = this.getFeesControl();
      if (feesControl.length == 0) {
        this.addRow();
      }
      this.helperService.showFormControl(this.feesForm, 'feeAndServiceDetails');
    }
  }

  getPrepaidOptions() {
    let options: any[] = [];
    options.push(this.helperService.buildOption("Y", "Yes"));
    options.push(this.helperService.buildOption("N", "No"));
    return options;
  }

  addRow() {
    let feesControl = this.getFeesControl();
    let feeGroup = this.getFeeGroup();
    feesControl.push(feeGroup);
    this.onRowClick(feeGroup);
    this.dataSource.next(feesControl.controls);
  }

  removeRow(index: number) {
    let feesControl = this.getFeesControl();
    feesControl.removeAt(index);
    if (feesControl.length == 0) {
      this.addRow();
    }
    this.dataSource.next(feesControl.controls);
  }

  onRowClick(activeRowElem: any) {
    let feesControl = this.getFeesControl();
    Object.keys(feesControl.controls).forEach(field => {
      const control = feesControl.get(field);
      control["active"] = false;
    });
    activeRowElem["active"] = true;
  }

  hasError(rowIndex: number, fieldName: string) {
    let field = this.getField(rowIndex, fieldName);
    return field.touched && field.invalid;
  }

  getField(rowIndex: number, fieldName: string) {
    return this.getFeesControl().controls[rowIndex].get(fieldName);
  }

  getRowControl(rowIndex: number) {
    return this.getFeesControl().controls[rowIndex];
  }

  updateDataSource() {
    this.ref.detectChanges();
  }

  getFeesColumns() {
    this.columns.push({ "displayName": "Component Name", "name": "cmpName" });
    this.columns.push({ "displayName": "Proration Rule", "name": "ruleCode" });
    this.columns.push({ "displayName": "Advance/Arrears", "name": "arrearCode" });
    this.columns.push({ "displayName": "Flat Fee", "name": "flatFee" });
    this.columns.push({ "displayName": "Rate Per Item", "name": "rateItm" });
    this.columns.push({ "displayName": "Tier", "name": "tier" });
    this.columns.push({ "displayName": "Minimum Amount", "name": "mnmAmt" });
    this.columns.push({ "displayName": "Maximum Amount", "name": "maxAmt" });
    this.columns.push({ "displayName": "Billing Frequency", "name": "frq" });
    this.columns.push({ "displayName": "Upfront/Prepaid Fees", "name": "pdFee" });
  }

  getName(data: any[], code: string) {
    return this.helperService.find(data, "code", code).name;
  }

  getUpfrontOrPrepaidFeesLabel(value: string) {
    if (value) {
      return value == 'Y' ? "Yes" : "No";
    }
    return '';
  }

}
