import { ValidatorFn, FormGroup, FormControl, FormGroupDirective, NgForm } from "@angular/forms";
import { ErrorStateMatcher } from "@angular/material";
import * as BigNumber from 'bignumber.js';

export class ServiceFeeValidators {

    static amountValidator: ValidatorFn = (formGroup: FormGroup) => {
        let maxAmount = formGroup.controls.maximumAmount.value;
        let minAmount = formGroup.controls.minimumAmount.value;
        let maxAmountValue = maxAmount ? maxAmount.toString().replace(/\,/g, '') : maxAmount;
        let minAmountValue = minAmount ? minAmount.toString().replace(/\,/g, '') : minAmount;
        let maxAmountBigNum = new BigNumber.BigNumber(maxAmountValue);
        let minAmountBigNum = new BigNumber.BigNumber(minAmountValue);
        if (minAmountBigNum.isGreaterThan(maxAmountBigNum)) {
            return { maxAmountError: true };
        }
        return null;
    }

    static flatFeeRateTierValidator: ValidatorFn = (formGroup: FormGroup) => {
        let flatFee = formGroup.controls.flatFee.value;
        let ratePerItem = formGroup.controls.ratePerItem.value;
        let tier = formGroup.controls.tier.value;
        if (!flatFee && !ratePerItem && !tier) {
            return { flatFeeRateTierError: true };
        }
        return null;
    }
}

export class AmountValidMatcher implements ErrorStateMatcher {
    isErrorState(control: FormControl, form: FormGroupDirective | NgForm): boolean {
        return control.parent.invalid && control.touched && control.parent.hasError('maxAmountError');
    }
}

export class FlatFeeRateTierValidMatcher implements ErrorStateMatcher {
    isErrorState(control: FormControl, form: FormGroupDirective | NgForm): boolean {
        return control.parent.invalid && control.touched && control.parent.hasError('flatFeeRateTierError');
    }
}