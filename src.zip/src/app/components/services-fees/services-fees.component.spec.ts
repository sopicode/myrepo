import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ServicesFeesComponent } from './services-fees.component';

describe('ServicesFeesComponent', () => {
  let component: ServicesFeesComponent;
  let fixture: ComponentFixture<ServicesFeesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ServicesFeesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ServicesFeesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
