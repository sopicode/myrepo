import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Deal } from 'src/app/models/deal';
import { Error } from 'src/app/models/error';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { HelperService } from 'src/app/services/helper.service';

@Component({
  selector: 'billing-manual-billing',
  templateUrl: './manual-billing.component.html',
  styleUrls: ['./manual-billing.component.scss']
})
export class ManualBillingComponent implements OnInit {

  @Input() deal: Deal;
  @Output() formInitialized = new EventEmitter<FormGroup>();
  detailsForm: FormGroup;
  errors: Error[] = [];

  constructor(private helperService: HelperService,private _fb: FormBuilder) { }

  ngOnInit() {
    this.detailsForm = this._fb.group({
      isManualBillingCompleted: [,Validators.required],
      manualBillingComment: [,Validators.required]
    });
    this.formInitialized.emit(this.detailsForm);
    this.initErrors();
  }

  initErrors() {
    this.errors.push(this.helperService.buildError("isManualBillingCompleted", "Is Manual Billing Completed? - This field is required", "required"));
    this.errors.push(this.helperService.buildError("manualBillingComment", "Comments - Enter EBW CASE ID and FiRRe Key(s) - This field is required", "required"));
  }

}
