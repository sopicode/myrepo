import { Component, OnInit, Input, TemplateRef } from '@angular/core';

@Component({
  selector: 'billing-accordion',
  templateUrl: './accordion.component.html',
  styleUrls: ['./accordion.component.scss']
})
export class AccordionComponent implements OnInit {
  @Input()
  panelTitle:string;
  @Input()
  contentTemplate: TemplateRef<any>;
  @Input()
  actionTemplate: TemplateRef<any>;
  
  constructor() { }

  ngOnInit() {
  }

}
