import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BillingKeyDetailsComponent } from './billing-key-details.component';

describe('BillingKeyDetailsComponent', () => {
  let component: BillingKeyDetailsComponent;
  let fixture: ComponentFixture<BillingKeyDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BillingKeyDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BillingKeyDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
