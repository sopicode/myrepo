import { Component, OnInit, Input, Inject, ViewEncapsulation } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { DealService } from '../../services/deal.service';
import { Task } from 'src/app/models/task';
import { BillingComponentDetails } from '../../models/billing-component';
import { forkJoin } from 'rxjs';
import { BillingInvoiceDetails } from '../../models/billing-invoice';

@Component({
  selector: 'billing-billing-key-details',
  templateUrl: './billing-key-details.component.html',
  styleUrls: ['./billing-key-details.component.scss']
})
export class BillingKeyDetailsComponent implements OnInit {

  @Input() data: any
  detailsForm: FormGroup;
  billingKeyDetailsData: string;
  _billingKeys: any;
  _data: any;
  dealId: string;
  dataScope: string;
  billingAccountSource;
  billingInvoiceSource;
  columnsToDisplayForComponent = ["invoiceApprover", "componentName", "componentType", "rate", "advanceArrears", "billingFrequency"];
  columnsDisplayNamesForComponent =
    {
      "invoiceApprover": "Invoice Approver Name",
      "componentName": "Component Name",
      "componentType": "Component Type",
      "rate": "Rate",
      "advanceArrears": "Advance/Arrears",
      "billingFrequency": "Billing Frequency"
    };
  columnsToDisplayForInvoice = ["invoiceNumber", "invoiceAmount", "invoiceType"];
  columnsDisplayNamesForInvoice =
    {
      "invoiceNumber": "Invoice Number",
      "invoiceAmount": "Invoice Amount",
      "invoiceType": "Invoice Type"
    };
  constructor(private _fb: FormBuilder, private dealService: DealService, @Inject("task") private taskDetails) { }

  ngOnInit() {
    let task = Task.fromJSON(this.taskDetails);
    this._billingKeys = task.variables.billingKeyList;
    this.dealId = task.id;
    //this.dealId = "CT1913475";
    //let billingKey = "ABC2013A";
    let billingKey = task.variables.billingKey;
    this.loadData(billingKey, this.data);
    this.detailsForm = this._fb.group({
      billingKey: [this.billingKeyDetailsData, Validators.required],
      accntShortName: [this._data ? this._data.shortName : null, null],
      accntLongName: [this._data ? this._data.longName : null, null],
      mailingAddress: [this._data ? this._data.mailingAddress : null, null]
    })
  }

  loadData(billingKey: string, data: any) {
    this.billingKeyDetailsData = billingKey;
    let compData = data[0].data.cts;
    let invoiceData = data[1].data.ctti;
    if (compData) {
      this._data = data[0].data.cts[0];
      this.billingAccountSource = this.buildComponentDetails(data[0].data.cts);
      if (invoiceData.length > 0) {
        this.billingInvoiceSource = this.buildInvoiceDetails(data[1].data.ctti);
      }
    }
    else {
      this._data = null;
      this.billingAccountSource = null;
      this.billingInvoiceSource = null;
    }
  }

  buildComponentDetails(componentsList: any): BillingComponentDetails[] {
    let componentDetails: BillingComponentDetails[] = [];
    if (Array.isArray(componentsList)) {
      componentsList.forEach((components, index) => {
        let componentList: BillingComponentDetails = BillingComponentDetails.fromJSON(components);
        componentList.position = index % 2 == 0 ? 'even' : 'odd';
        componentDetails.push(componentList);
      });
      return componentDetails;
    }
  }

  buildInvoiceDetails(invoiceList: any): BillingInvoiceDetails[] {
    let invoiceDetails: BillingInvoiceDetails[] = [];
    if (Array.isArray(invoiceList)) {
      invoiceList.forEach((invoices, index) => {
        let invoiceList: BillingInvoiceDetails = BillingInvoiceDetails.fromJSON(invoices);
        invoiceList.position = index % 2 == 0 ? 'even' : 'odd';
        invoiceDetails.push(invoiceList);
      });
      return invoiceDetails;
    }
  }

  onSelectChange(billingKey: string) {
    let componentService = this.dealService.getBillingKeyComponentDetails(this.dealId, billingKey);
    let invoiceService = this.dealService.getBillingKeyInvoiceDetails(this.dealId, billingKey);
    forkJoin(componentService, invoiceService).subscribe((results: any[]) => {
      this.loadData(billingKey, results);
    });
  }
}
