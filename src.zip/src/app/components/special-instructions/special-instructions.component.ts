import { Component, OnInit, Input, Inject, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Deal } from 'src/app/models/deal';
import { Error } from 'src/app/models/error';
import { FormService } from 'src/app/services/form.service';

@Component({
  selector: 'billing-special-instructions',
  templateUrl: './special-instructions.component.html',
  styleUrls: ['./special-instructions.component.scss']
})
export class SpecialInstructionsComponent implements OnInit {

  @Input() deal: Deal;
  @Input() data: any[];
  @Input() readOnly: boolean;
  @Output() formInitialized = new EventEmitter<FormGroup>();
  detailsForm: FormGroup;
  optional: boolean = true;
  errors: Error[] = [];

  constructor(private _fb: FormBuilder,  private formService: FormService) { }

  ngOnInit() {
    let specialInstData = this.data[0].data;
    let reqDetailsData = this.data[1].data;
    this.detailsForm = this._fb.group({
      id: [specialInstData.id],
      specialInstruction: [specialInstData.specialInstruction]
    });
    this.initErrors();
    if (this.readOnly) {
      this.detailsForm.disable();
    }
    let billingTypeCode = reqDetailsData.billingTypeCode;
    if (billingTypeCode != "N") {
      this.detailsForm.controls["specialInstruction"].setValidators(Validators.required);
      this.optional = false;
    }
    this.formInitialized.emit(this.detailsForm);
  }

  initErrors() {
    let error: Error = new Error();
    error.field = "specialInstruction";
    error.errorKey = "required";
    error.message = "Special Billing Instructions - This field is required";
    this.errors.push(error);
  }

}
