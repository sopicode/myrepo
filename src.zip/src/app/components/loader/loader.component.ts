import { Component, OnInit, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { Subscription } from 'rxjs';
import { LoaderService } from 'src/app/services/loader.service';
import { LoaderState } from 'src/app/models/loader';

@Component({
  selector: 'billing-loader',
  templateUrl: './loader.component.html',
  styleUrls: ['./loader.component.scss']
})
export class LoaderComponent implements OnInit, OnDestroy {

  show = false;
  private subscription: Subscription;
  constructor(private loaderService: LoaderService, private ref: ChangeDetectorRef) { }
  ngOnInit() {
    this.subscription = this.loaderService.loaderState
      .subscribe((state: LoaderState) => {
        if (this.show != state.show) {
          this.show = state.show;
          this.ref.detectChanges();
        }
      });
  }
  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

}
