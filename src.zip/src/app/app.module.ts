import { NgModule } from '@angular/core';

import { HTTP_INTERCEPTORS } from '@angular/common/http';

import { SharedModule } from './shared.module';
import { LoaderInterceptorService } from './services/loader-interceptor.service';
import { AppComponent } from './app.component';


@NgModule({
  declarations: [
    
  ],
  imports: [
    SharedModule
  ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: LoaderInterceptorService,
      multi: true
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }