import { TableModel } from "./table-model";

export class DealPartyInfo extends TableModel {
    private _dealPartyName: string;
    public get dealPartyName_1(): string {
        return this._dealPartyName;
    }
    public set dealPartyName_1(value: string) {
        this._dealPartyName = value;
    }
    private _rolesCSV: string;
    public get rolesCSV_1(): string {
        return this._rolesCSV;
    }
    public set rolesCSV_1(value: string) {
        this._rolesCSV = value;
    }
    private _countExistingContacts: number;
    public get countExistingContacts_1(): number {
        return this._countExistingContacts;
    }
    public set countExistingContacts_1(value: number) {
        this._countExistingContacts = value;
    }
    static fromJSON(json: string): DealPartyInfo {
        let dealParty = Object.create(DealPartyInfo.prototype);
        return Object.assign(dealParty, json);
    }

}