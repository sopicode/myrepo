export interface FormDetail {
    key: string;  // form key
    component: any; // component;
    menuLabel?: string; // label of the menu shown in footer
    navigationEndPoint: string; //end point to navigate from page to page
    dataSource?: any[]; // array of observables
    renderNext?: boolean;
    renderBack?: boolean;
    renderSubmit?: boolean;
    renderCancel?: boolean;
    hideMenu?: boolean;
    renderApprove?: boolean;
    renderReject?: boolean;
}