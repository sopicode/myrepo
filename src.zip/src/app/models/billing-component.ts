import { TableModel } from "./table-model";

export class BillingComponentDetails extends TableModel {
    private _invoiceApprover: string;
    public get invoiceApprover(): string {
        return this._invoiceApprover;
    }
    public set invoiceApprover(value: string) {
        this._invoiceApprover = value;
    }
    private _componentName: string;
    public get componentName(): string {
        return this._componentName;
    }
    public set componentName(value: string) {
        this._componentName = value;
    }
    private _componentType: string;
    public get componentType(): string {
        return this._componentType;
    }
    public set componentType(value: string) {
        this._componentType = value;
    }
    private _rate: string;
    public get rate(): string {
        return this._rate;
    }
    public set rate(value: string) {
        this._rate = value;
    }

    private _advanceArrears: string;
    public get advanceArrears(): string {
        return this._advanceArrears;
    }
    public set advanceArrears(value: string) {
        this._advanceArrears = value;
    }
    private _billingFrequency: string;
    public get billingFrequency(): string {
        return this._billingFrequency;
    }
    public set billingFrequency(value: string) {
        this._billingFrequency = value;
    }


    static fromJSON(json: string): BillingComponentDetails {
        let componentDetails = Object.create(BillingComponentDetails.prototype);
        return Object.assign(componentDetails, json);
    }

}