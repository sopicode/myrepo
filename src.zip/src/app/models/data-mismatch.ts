import { TableModel } from "./table-model";

export class DataMismatchDetails extends TableModel
{
    private _billingDataMismatchId: number;
    private _partyRoleId: number;
    private _legalEntityCode: string;
    private _legalEntityName: string;
    private _ctRoleName: string;
    private _dataMismatchReasonCode: string;
    private _dataMismatchComment: string;
    private _partyId: string;
    private _partyRoleTypeCode: string;  

    //private _partOfReqNo: string;
    private _requestNosList: string[];
 
    public get partyId(): string {
        return this._partyId;
    }
    public set partyId(value: string) {
        this._partyId = value;
    }

    public get partyRoleTypeCode(): string {
        return this._partyRoleTypeCode;
    }
    public set partyRoleTypeCode(value: string) {
        this._partyRoleTypeCode = value;
    }

    public get legalEntityCode(): string {
        return this._legalEntityCode;
    }
    public set legalEntityCode(value: string) {
        this._legalEntityCode = value;
    }

    public get billingDataMismatchId(): number {
        return this._billingDataMismatchId;
    }
    public set billingDataMismatchId(value: number) {
        this._billingDataMismatchId = value;
    }

    public get partyRoleId(): number {
        return this._partyRoleId;
    }
    public set partyRoleId(value: number) {
        this._partyRoleId = value;
    }

    public get legalEntityName(): string {
        return this._legalEntityName;
    }
    public set legalEntityName(value: string) {
        this._legalEntityName = value;
    }

    public get ctRoleName(): string {
        return this._ctRoleName;
    }
    public set ctRoleName(value: string) {
        this._ctRoleName = value;
    }

    public get dataMismatchReasonCode(): string {
        return this._dataMismatchReasonCode;
    }
    public set dataMismatchReasonCode(value: string) {
        this._dataMismatchReasonCode = value;
    }

    public get dataMismatchComment(): string {
        return this._dataMismatchComment;
    }
    public set dataMismatchComment(value: string) {
        this._dataMismatchComment = value;
    }

    public get requestNosList(): string[] {
        return this._requestNosList;
    }
    public set requestNosList(value: string[]) {
        this._requestNosList = value;
    }
   
    static fromJSON(json: string): DataMismatchDetails {
        let dataMismatchList = Object.create(DataMismatchDetails.prototype);
        return Object.assign(dataMismatchList, json);
    }

}