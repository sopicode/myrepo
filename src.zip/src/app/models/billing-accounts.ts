import { BillingAccount } from "./billing-account";

export class BillingAccounts {

    private _billingAccounts: BillingAccount[];

    public get billingAccounts(): BillingAccount[] {
        return this._billingAccounts;
    }
    public set billingAccounts(value: BillingAccount[]) {
        this._billingAccounts = value;
    }

    static reviver(key: string, value: any): any {
        return key === "" ? BillingAccounts.fromJSON(value) : value;
    }

    static fromJSON(json: any | string): BillingAccounts {
        if (typeof json === 'string') {
            return JSON.parse(json, BillingAccounts.reviver);
        } else {
            var billingAccts = Object.create(BillingAccounts.prototype);
            billingAccts = (<any>Object).assign(billingAccts, json, {
                _billingAccounts: BillingAccounts.buildBillingAccounts(json)
            });
            return billingAccts;
        }
    }

    static buildBillingAccounts(billingAccountList: any): BillingAccount[] {
        var billingAccounts: BillingAccount[] = [];
        if (Array.isArray(billingAccountList)) {
            for (var billingAcc of billingAccountList) {
                billingAccounts.push(BillingAccount.fromJSON(billingAcc));
            }
        } else if (billingAccountList) {
            billingAccounts.push(BillingAccount.fromJSON(billingAccountList));
        }
        return billingAccounts;
    }

}
