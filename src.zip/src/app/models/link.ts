export class Link {

    private _id: number;
    private _billingAccountId: number;
    private _systemId: number;
    private _subSystem: string;
    private _accountNumber: string;
    private _systemPurpose: string;
    private _isSelected: boolean;
    private _action: string;

    /**
     * Getter id
     * @return {number}
     */
	public get id(): number {
		return this._id;
	}

    /**
     * Getter billingAccountId
     * @return {number}
     */
	public get billingAccountId(): number {
		return this._billingAccountId;
	}

    /**
     * Getter systemId
     * @return {number}
     */
	public get systemId(): number {
		return this._systemId;
	}

    /**
     * Getter subSystem
     * @return {string}
     */
	public get subSystem(): string {
		return this._subSystem;
	}

    /**
     * Getter accountNumber
     * @return {string}
     */
	public get accountNumber(): string {
		return this._accountNumber;
	}

    /**
     * Getter systemPurpose
     * @return {string}
     */
	public get systemPurpose(): string {
		return this._systemPurpose;
	}

    /**
     * Getter isSelected
     * @return {boolean}
     */
	public get isSelected(): boolean {
		return this._isSelected;
	}

    /**
     * Getter action
     * @return {string}
     */
	public get action(): string {
		return this._action;
	}

    /**
     * Setter id
     * @param {number} value
     */
	public set id(value: number) {
		this._id = value;
	}

    /**
     * Setter billingAccountId
     * @param {number} value
     */
	public set billingAccountId(value: number) {
		this._billingAccountId = value;
	}

    /**
     * Setter systemId
     * @param {number} value
     */
	public set systemId(value: number) {
		this._systemId = value;
	}

    /**
     * Setter subSystem
     * @param {string} value
     */
	public set subSystem(value: string) {
		this._subSystem = value;
	}

    /**
     * Setter accountNumber
     * @param {string} value
     */
	public set accountNumber(value: string) {
		this._accountNumber = value;
	}

    /**
     * Setter systemPurpose
     * @param {string} value
     */
	public set systemPurpose(value: string) {
		this._systemPurpose = value;
	}

    /**
     * Setter isSelected
     * @param {boolean} value
     */
	public set isSelected(value: boolean) {
		this._isSelected = value;
	}

    /**
     * Setter action
     * @param {string} value
     */
	public set action(value: string) {
		this._action = value;
	}

}
