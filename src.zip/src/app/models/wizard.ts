export class Wizard {

    private _dealId: string;
    private _formKey: string;
    private _processId: string;
    private _taskId: string;
    private _action: string;

    public get action(): string {
        return this._action;
    }
    public set action(value: string) {
        this._action = value;
    }

    public get processId(): string {
        return this._processId;
    }
    public set processId(value: string) {
        this._processId = value;
    }

    public get formKey(): string {
        return this._formKey;
    }
    public set formKey(value: string) {
        this._formKey = value;
    }

    public get dealId(): string {
        return this._dealId;
    }
    public set dealId(value: string) {
        this._dealId = value;
    }

    public get taskId(): string {
        return this._taskId;
    }
    public set taskId(value: string) {
        this._taskId = value;
    }

    static toJSON(wizard:Wizard): any {
        let wizardObj = {};
        for (let key of Object.keys(wizard)){
            wizardObj[key.slice(1)] = wizard[key]
        }
        return wizardObj;
    }

    static fromJSON(json: any): Wizard {
        if (typeof json === 'string') {
            return JSON.parse(json, Wizard.reviver);
        } else {
            let wizard = Object.create(Wizard.prototype);
            return Object.assign(wizard, json);
        }
    }
    static reviver(key: string, value: any): any {
        return key === "" ? Wizard.fromJSON(value) : value;
    }
}
