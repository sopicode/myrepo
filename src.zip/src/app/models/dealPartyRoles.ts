export class dealPartyRoles{
    constructor(public code: string, public name: string) { }
}