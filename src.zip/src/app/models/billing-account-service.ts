export class BillingAccountService {

    private _billingAccountId:number;
    private _billedServiceName:string;
    private _billedAmount:string;

    /**
     * Getter billingAccountId
     * @return {number}
     */
	public get billingAccountId(): number {
		return this._billingAccountId;
	}

    /**
     * Getter billedServiceName
     * @return {string}
     */
	public get billedServiceName(): string {
		return this._billedServiceName;
	}

    /**
     * Getter billedAmount
     * @return {string}
     */
	public get billedAmount(): string {
		return this._billedAmount;
	}

    /**
     * Setter billingAccountId
     * @param {number} value
     */
	public set billingAccountId(value: number) {
		this._billingAccountId = value;
	}

    /**
     * Setter billedServiceName
     * @param {string} value
     */
	public set billedServiceName(value: string) {
		this._billedServiceName = value;
	}

    /**
     * Setter billedAmount
     * @param {string} value
     */
	public set billedAmount(value: string) {
		this._billedAmount = value;
    }
    
    static reviver(key: string, value: any): any {
        return key === "" ? BillingAccountService.fromJSON(value) : value;
    }

    static fromJSON(json: any | string): BillingAccountService {
        if (typeof json === 'string') {
	    	return JSON.parse(json, BillingAccountService.reviver);
	    } else {
            let billingAcct = Object.create(BillingAccountService.prototype);
            return Object.assign(billingAcct, json);
        }
    }

}
