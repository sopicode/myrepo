import { TableModel } from "./table-model";

export class BillingExistingAccount extends TableModel {

    private _accountStatus: string;
    private _admin: string;
    private _cid: string;
    private _dataScope: string;
    private _longName: string;
    private _manager: string;
    private _outputFlag: string;
    private _outputKey: string;
    private _shortName: string;
    private _isSelected: boolean;
    
    public get isSelected(): boolean {
        return this._isSelected;
    }
    public set isSelected(value: boolean) {
        this._isSelected = value;
    }

    public get accountStatus(): string {
        return this._accountStatus;
    }
    public set accountStatus(value: string) {
        this._accountStatus = value;
    }

    public get admin(): string {
        return this._admin;
    }
    public set admin(value: string) {
        this._admin = value;
    }

    public get cid(): string {
        return this._cid;
    }
    public set cid(value: string) {
        this._cid = value;
    }

    public get dataScope(): string {
        return this._dataScope;
    }
    public set dataScope(value: string) {
        this._dataScope = value;
    }

    public get longName(): string {
        return this._longName;
    }
    public set longName(value: string) {
        this._longName = value;
    }

    public get manager(): string {
        return this._manager;
    }
    public set manager(value: string) {
        this._manager = value;
    }

    public get outputFlag(): string {
        return this._outputFlag;
    }
    public set outputFlag(value: string) {
        this._outputFlag = value;
    }

    public get outputKey(): string {
        return this._outputKey;
    }
    public set outputKey(value: string) {
        this._outputKey = value;
    }

    public get shortName(): string {
        return this._shortName;
    }
    public set shortName(value: string) {
        this._shortName = value;
    }


    static fromJSON(json: string): BillingExistingAccount {
        let existingAccountsList = Object.create(BillingExistingAccount.prototype);
        return Object.assign(existingAccountsList, json);
    }

    static buildExistingAccountDetails(existingAccountsList: any): BillingExistingAccount[] {
        let existingAccountsArray: BillingExistingAccount[] = [];
        if (Array.isArray(existingAccountsList)) {
            existingAccountsList.forEach((account, index) => {
                let existingAccount: BillingExistingAccount = BillingExistingAccount.fromJSON(account);
                existingAccount.position = index % 2 == 0 ? 'even' : 'odd';
                existingAccountsArray.push(existingAccount);
            });
            return existingAccountsArray;
        }
    }

}