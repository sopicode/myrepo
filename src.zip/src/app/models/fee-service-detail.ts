export class FeeServiceDetail {

    private _billingAccountId:number;
    private _componentName:string;
    private _prorationRuleCode:string;
    private _advanceOrArrearsCode:string;
    private _flatFee: any;
    private _ratePerItem: any;
    private _tier:string;
    private _minimumAmount: any;
    private _maximumAmount: any;
    private _billingFrequencyCode:string;
    private _upfrontOrPrepaidFees:string;

    public get flatFee(): any {
        return this._flatFee;
    }
    public set flatFee(value: any) {
        this._flatFee = value;
    }

    public get minimumAmount(): any {
        return this._minimumAmount;
    }
    public set minimumAmount(value: any) {
        this._minimumAmount = value;
    }

    public get ratePerItem(): any {
        return this._ratePerItem;
    }
    public set ratePerItem(value: any) {
        this._ratePerItem = value;
    }

    public get maximumAmount(): any {
        return this._maximumAmount;
    }
    public set maximumAmount(value: any) {
        this._maximumAmount = value;
    }

    /**
     * Getter billingAccountId
     * @return {number}
     */
	public get billingAccountId(): number {
		return this._billingAccountId;
	}

    /**
     * Getter componentName
     * @return {string}
     */
	public get componentName(): string {
		return this._componentName;
	}

    /**
     * Getter prorationRuleCode
     * @return {string}
     */
	public get prorationRuleCode(): string {
		return this._prorationRuleCode;
	}

    /**
     * Getter advanceOrArrearsCode
     * @return {string}
     */
	public get advanceOrArrearsCode(): string {
		return this._advanceOrArrearsCode;
	}

    /**
     * Getter tier
     * @return {string}
     */
	public get tier(): string {
		return this._tier;
	}

    /**
     * Getter billingFrequencyCode
     * @return {string}
     */
	public get billingFrequencyCode(): string {
		return this._billingFrequencyCode;
	}

    /**
     * Getter upfrontOrPrepaidFees
     * @return {string}
     */
	public get upfrontOrPrepaidFees(): string {
		return this._upfrontOrPrepaidFees;
	}

    /**
     * Setter billingAccountId
     * @param {number} value
     */
	public set billingAccountId(value: number) {
		this._billingAccountId = value;
	}

    /**
     * Setter componentName
     * @param {string} value
     */
	public set componentName(value: string) {
		this._componentName = value;
	}

    /**
     * Setter prorationRuleCode
     * @param {string} value
     */
	public set prorationRuleCode(value: string) {
		this._prorationRuleCode = value;
	}

    /**
     * Setter advanceOrArrearsCode
     * @param {string} value
     */
	public set advanceOrArrearsCode(value: string) {
		this._advanceOrArrearsCode = value;
	}

    /**
     * Setter tier
     * @param {string} value
     */
	public set tier(value: string) {
		this._tier = value;
	}

    /**
     * Setter billingFrequencyCode
     * @param {string} value
     */
	public set billingFrequencyCode(value: string) {
		this._billingFrequencyCode = value;
	}

    /**
     * Setter upfrontOrPrepaidFees
     * @param {string} value
     */
	public set upfrontOrPrepaidFees(value: string) {
		this._upfrontOrPrepaidFees = value;
    }
    
    static reviver(key: string, value: any): any {
        return key === "" ? FeeServiceDetail.fromJSON(value) : value;
    }

    static fromJSON(json: any | string): FeeServiceDetail {
        if (typeof json === 'string') {
	    	return JSON.parse(json, FeeServiceDetail.reviver);
	    } else {
            let billingAcct = Object.create(FeeServiceDetail.prototype);
            return Object.assign(billingAcct, json);
        }
    }
}
