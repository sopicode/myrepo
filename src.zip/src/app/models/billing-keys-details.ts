export class BillingKeyDetails {
    private _billingKeys: string;
    private _accountShortName: string;
    private _accountLongName: string;
    private _company: string;
    private _countryOfDomicile: string;
    private _firstName: string;
    private _lastName: string;
    private _title: string;
    private _address1: string;
    private _address2: string;
    private _address3: string;
    private _address4: string;
    private _city: string;
    private _zipCode: string;
    
    public get billingKeys(): string {
        return this._billingKeys;
    }
    public set billingKeys(value: string) {
        this._billingKeys = value;
    }

    public get accountShortName(): string {
        return this._accountShortName;
    }
    public set accountShortName(value: string) {
        this._accountShortName = value;
    }
    public get accountLongName(): string {
        return this._accountLongName;
    }
    public set accountLongName(value: string) {
        this._accountLongName = value;
    }
    public get company(): string {
        return this._company;
    }
    public set company(value: string) {
        this._company = value;
    }

    public get countryOfDomicile(): string {
        return this._countryOfDomicile;
    }
    public set countryOfDomicile(value: string) {
        this._countryOfDomicile = value;
    }
    public get firstName(): string {
        return this._firstName;
    }
    public set firstName(value: string) {
        this._firstName = value;
    }
    public get lastName(): string {
        return this._lastName;
    }
    public set lastName(value: string) {
        this._lastName = value;
    }
    public get title(): string {
        return this._title;
    }
    public set title(value: string) {
        this._title = value;
    }
    public get address1(): string {
        return this._address1;
    }
    public set address1(value: string) {
        this._address1 = value;
    }
    public get address2(): string {
        return this._address2;
    }
    public set address2(value: string) {
        this._address2 = value;
    }
    public get address3(): string {
        return this._address3;
    }
    public set address3(value: string) {
        this._address3 = value;
    }
    public get address4(): string {
        return this._address4;
    }
    public set address4(value: string) {
        this._address4 = value;
    }
    public get city(): string {
        return this._city;
    }
    public set city(value: string) {
        this._city = value;
    }
    public get zipCode(): string {
        return this._zipCode;
    }
    public set zipCode(value: string) {
        this._zipCode = value;
    }

}