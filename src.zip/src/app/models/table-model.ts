export class TableModel {

    private _expanded: boolean;
    private _position: string;
    private _readOnly: boolean = true;
    private _active: boolean;
    
    public get active(): boolean {
        return this._active;
    }
    public set active(value: boolean) {
        this._active = value;
    }

    public get readOnly(): boolean {
        return this._readOnly;
    }
    public set readOnly(value: boolean) {
        this._readOnly = value;
    }

    public get position(): string {
        return this._position;
    }
    public set position(value: string) {
        this._position = value;
    }
    
    public get expanded(): boolean {
        return this._expanded;
    }
    public set expanded(value: boolean) {
        this._expanded = value;
    }
}
