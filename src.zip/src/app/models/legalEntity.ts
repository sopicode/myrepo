export class LegalEntity
{
    private _id: number;
    private _legalName: string;
    private _externalLegalEntityId: string;

    public get id(): number {
        return this._id;
    }
    public set id(value: number) {
        this._id = value;
    }

    public get legalName(): string {
        return this._legalName;
    }
    public set legalName(value: string) {
        this._legalName = value;
    }

    public get externalLegalEntityId(): string {
        return this._externalLegalEntityId;
    }
    public set externalLegalEntityId(value: string) {
        this._externalLegalEntityId = value;
    }


    static reviver(key: string, value: any): any {
        return key === "" ? LegalEntity.fromJSON(value) : value;
    }

    static fromJSON(json: any | string): LegalEntity {
        if (typeof json === 'string') {
	    	return JSON.parse(json, LegalEntity.reviver);
	    } else {
            let billingAcct = Object.create(LegalEntity.prototype);
            return Object.assign(billingAcct, json);
        }
    }


}