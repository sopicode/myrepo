export class Document {

    private _id: number;
    private _type: number;
    private _fileId: string;
    private _fileName: string;
    private _uploadedBy: string;
    private _uploadedById: string;
    private _uploadedDate: string;
    private _documentTypeName: string;
    private _item?: any; // this obj will capture details of docs while uploading

    public get item(): any {
        return this._item;
    }
    public set item(value: any) {
        this._item = value;
    }

    /**
     * Getter id
     * @return {number}
     */
    public get id(): number {
        return this._id;
    }

    /**
     * Getter type
     * @return {number}
     */
    public get type(): number {
        return this._type;
    }

    /**
     * Getter fileId
     * @return {string}
     */
    public get fileId(): string {
        return this._fileId;
    }

    /**
     * Getter fileName
     * @return {string}
     */
    public get fileName(): string {
        return this._fileName;
    }

    /**
     * Getter uploadedBy
     * @return {string}
     */
    public get uploadedBy(): string {
        return this._uploadedBy;
    }

    /**
     * Getter uploadedById
     * @return {string}
     */
    public get uploadedById(): string {
        return this._uploadedById;
    }

    /**
     * Getter uploadedDate
     * @return {string}
     */
    public get uploadedDate(): string {
        return this._uploadedDate;
    }

    /**
     * Getter documentTypeName
     * @return {string}
     */
    public get documentTypeName(): string {
        return this._documentTypeName;
    }

    /**
     * Setter id
     * @param {number} value
     */
    public set id(value: number) {
        this._id = value;
    }

    /**
     * Setter type
     * @param {number} value
     */
    public set type(value: number) {
        this._type = value;
    }

    /**
     * Setter fileId
     * @param {string} value
     */
    public set fileId(value: string) {
        this._fileId = value;
    }

    /**
     * Setter fileName
     * @param {string} value
     */
    public set fileName(value: string) {
        this._fileName = value;
    }

    /**
     * Setter uploadedBy
     * @param {string} value
     */
    public set uploadedBy(value: string) {
        this._uploadedBy = value;
    }

    /**
     * Setter uploadedById
     * @param {string} value
     */
    public set uploadedById(value: string) {
        this._uploadedById = value;
    }

    /**
     * Setter uploadedDate
     * @param {string} value
     */
    public set uploadedDate(value: string) {
        this._uploadedDate = value;
    }

    /**
     * Setter documentTypeName
     * @param {string} value
     */
    public set documentTypeName(value: string) {
        this._documentTypeName = value;
    }

    static reviver(key: string, value: any): any {
        return key === "" ? Document.fromJSON(value) : value;
    }

    static fromJSON(json: any | string): Document {
        if (typeof json === 'string') {
            return JSON.parse(json, Document.reviver);
        } else {
            let document = Object.create(Document.prototype);
            return Object.assign(document, json);
        }
    }

}
