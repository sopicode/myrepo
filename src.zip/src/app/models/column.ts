export interface Column {

    displayName:string;
    name:string;
}
