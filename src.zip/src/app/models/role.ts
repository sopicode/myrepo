export class Role {

    private _partyRoleId:number;
    private _roleCode:string;
    private _roleDesc:string;

    
    /**
     * Getter partyRoleId
     * @return {number}
     */
	public get partyRoleId(): number {
		return this._partyRoleId;
	}

    /**
     * Getter roleCode
     * @return {string}
     */
	public get roleCode(): string {
		return this._roleCode;
	}

    /**
     * Getter roleDesc
     * @return {string}
     */
	public get roleDesc(): string {
		return this._roleDesc;
	}

    /**
     * Setter partyRoleId
     * @param {number} value
     */
	public set partyRoleId(value: number) {
		this._partyRoleId = value;
	}

    /**
     * Setter roleCode
     * @param {string} value
     */
	public set roleCode(value: string) {
		this._roleCode = value;
	}

    /**
     * Setter roleDesc
     * @param {string} value
     */
	public set roleDesc(value: string) {
		this._roleDesc = value;
    }
    
    static reviver(key: string, value: any): any {
        return key === "" ? Role.fromJSON(value) : value;
    }

    static fromJSON(json: any | string): Role {
        if (typeof json === 'string') {
	    	return JSON.parse(json, Role.reviver);
	    } else {
            let billingAcct = Object.create(Role.prototype);
            return Object.assign(billingAcct, json);
        }
    }
}
