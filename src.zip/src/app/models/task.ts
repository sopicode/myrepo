import { Variables } from "./variables";

export class Task {

    private _id: string; //deal id
    private _taskId: string;
    private _taskName: string;
    private _formKey: string;
    private _processInstanceId: string;
    private _variables: Variables;
    private _mode: string;
    
    public get mode(): string {
        return this._mode;
    }
    public set mode(value: string) {
        this._mode = value;
    }
    
    public get variables(): Variables {
        return this._variables;
    }
    public set variables(value: Variables) {
        this._variables = value;
    }

    public get taskName(): string {
        return this._taskName;
    }
    public set taskName(value: string) {
        this._taskName = value;
    }

    public get processInstanceId(): string {
        return this._processInstanceId;
    }
    public set processInstanceId(value: string) {
        this._processInstanceId = value;
    }

    public get formKey(): string {
        return this._formKey;
    }
    public set formKey(value: string) {
        this._formKey = value;
    }

    public get id(): string {
        return this._id;
    }
    public set id(value: string) {
        this._id = value;
    }

    public get taskId(): string {
        return this._taskId;
    }
    public set taskId(value: string) {
        this._taskId = value;
    }

    static fromJSON(json: any | string): Task {
        if (typeof json === 'string') {
            return JSON.parse(json, Task.reviver);
        } else {
            let task = Object.create(Task.prototype);
            task = (<any>Object).assign(task, json, {
                _variables: Variables.fromJSON(json.variablesMap)
            });
            return task;
        }
    }

    static reviver(key: string, value: any): any {
        return key === "" ? Task.fromJSON(value) : value;
    }
}