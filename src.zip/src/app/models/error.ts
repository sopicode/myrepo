import { FormControl } from "@angular/forms";

export class Error {

    private _field: string;
    private _message: string;
    private _errorKey: string; // error key may contain values like required,invalid...

    /**
     * Getter field
     * @return {string}
     */
	public get field(): string {
		return this._field;
	}

    /**
     * Getter message
     * @return {string}
     */
	public get message(): string {
		return this._message;
	}

    /**
     * Getter errorKey
     * @return {string}
     */
	public get errorKey(): string {
		return this._errorKey;
	}

    /**
     * Setter field
     * @param {string} value
     */
	public set field(value: string) {
		this._field = value;
	}

    /**
     * Setter message
     * @param {string} value
     */
	public set message(value: string) {
		this._message = value;
	}

    /**
     * Setter errorKey
     * @param {string} value
     */
	public set errorKey(value: string) {
		this._errorKey = value;
	}
    

}
