export class Deal {

    private _id: string;
    private _proposedClosingDate: string;
    private _shortName: string;
    private _dealTypeCode: string;
    private _statusCode: string;
    private _regionId: number;
    private _productGroupId: number;
    private _majorProductId: number;
    private _projectName: string;
    private _longName: string;
    
    public get longName(): string {
        return this._longName;
    }
    public set longName(value: string) {
        this._longName = value;
    }

    public get id(): string {
        return this._id;
    }
    public set id(value: string) {
        this._id = value;
    }

    public get proposedClosingDate(): string {
        return this._proposedClosingDate;
    }
    public set proposedClosingDate(value: string) {
        this._proposedClosingDate = value;
    }

    public get shortName(): string {
        return this._shortName;
    }
    public set shortName(value: string) {
        this._shortName = value;
    }

    public get dealTypeCode(): string {
        return this._dealTypeCode;
    }
    public set dealTypeCode(value: string) {
        this._dealTypeCode = value;
    }

    public get regionId(): number {
        return this._regionId;
    }
    public set regionId(value: number) {
        this._regionId = value;
    }

    public get statusCode(): string {
        return this._statusCode;
    }
    public set statusCode(value: string) {
        this._statusCode = value;
    }

    public get productGroupId(): number {
        return this._productGroupId;
    }
    public set productGroupId(value: number) {
        this._productGroupId = value;
    }

    public get majorProductId(): number {
        return this._majorProductId;
    }
    public set majorProductId(value: number) {
        this._majorProductId = value;
    }

    public get projectName(): string {
        return this._projectName;
    }
    public set projectName(value: string) {
        this._projectName = value;
    }

    static fromJSON(json: string): Deal {
        let deal = Object.create(Deal.prototype);
        return Object.assign(deal, json);
    }

}
