import { TableModel } from "./table-model";

export class ContactDetail extends TableModel {

    private _company: string;
    private _title: string;
    private _preTitle: string;
    private _firstName: string;
    private _initial: string;
    private _lastName: string;
    private _suffix: string;
    private _phone: string;
    private _mobile: string;
    private _fax: string;
    private _email: string;
    private _addressLine1: string;
    private _addressLine2: string;
    private _addressLine3: string;
    private _city: string;
    private _country: string;
    private _postalCode: string;
    private _state: string;
    private _firreAddressNumber: string;
    private _acsNameKey: string;
    private _nexenClientId: string;
    private _eagleIntPartyId: string;
    private _proxyEdgeId: string;
    private _contactId: number;
    private _isBillingContact: boolean;
    private _isSelected: boolean;
    private _name: string;

    /**
     * Getter company
     * @return {string}
     */
    public get company(): string {
        return this._company;
    }

    /**
     * Getter title
     * @return {string}
     */
    public get title(): string {
        return this._title;
    }

    /**
     * Getter preTitle
     * @return {string}
     */
    public get preTitle(): string {
        return this._preTitle;
    }

    /**
     * Getter firstName
     * @return {string}
     */
    public get firstName(): string {
        return this._firstName;
    }

    /**
     * Getter initial
     * @return {string}
     */
    public get initial(): string {
        return this._initial;
    }

    /**
     * Getter lastName
     * @return {string}
     */
    public get lastName(): string {
        return this._lastName;
    }

    /**
     * Getter suffix
     * @return {string}
     */
    public get suffix(): string {
        return this._suffix;
    }

    /**
     * Getter phone
     * @return {string}
     */
    public get phone(): string {
        return this._phone;
    }

    /**
     * Getter mobile
     * @return {string}
     */
    public get mobile(): string {
        return this._mobile;
    }

    /**
     * Getter fax
     * @return {string}
     */
    public get fax(): string {
        return this._fax;
    }

    /**
     * Getter email
     * @return {string}
     */
    public get email(): string {
        return this._email;
    }

    /**
     * Getter addressLine1
     * @return {string}
     */
    public get addressLine1(): string {
        return this._addressLine1;
    }

    /**
     * Getter addressLine2
     * @return {string}
     */
    public get addressLine2(): string {
        return this._addressLine2;
    }

    /**
     * Getter addressLine3
     * @return {string}
     */
    public get addressLine3(): string {
        return this._addressLine3;
    }

    /**
     * Getter city
     * @return {string}
     */
    public get city(): string {
        return this._city;
    }

    /**
     * Getter country
     * @return {string}
     */
    public get country(): string {
        return this._country;
    }

    /**
     * Getter postalCode
     * @return {string}
     */
    public get postalCode(): string {
        return this._postalCode;
    }

    /**
     * Getter state
     * @return {string}
     */
    public get state(): string {
        return this._state;
    }

    /**
     * Getter firreAddressNumber
     * @return {string}
     */
    public get firreAddressNumber(): string {
        return this._firreAddressNumber;
    }

    /**
     * Getter acsNameKey
     * @return {string}
     */
    public get acsNameKey(): string {
        return this._acsNameKey;
    }

    /**
     * Getter nexenClientId
     * @return {string}
     */
    public get nexenClientId(): string {
        return this._nexenClientId;
    }

    public get eagleIntPartyId(): string {
        return this._eagleIntPartyId;
    }

    /**
     * Getter proxyEdgeId
     * @return {string}
     */
    public get proxyEdgeId(): string {
        return this._proxyEdgeId;
    }

    /**
     * Getter contactId
     * @return {number}
     */
    public get contactId(): number {
        return this._contactId;
    }

    /**
     * Getter isBillingContact
     * @return {boolean}
     */
    public get isBillingContact(): boolean {
        return this._isBillingContact;
    }

    /**
     * Getter isSelected
     * @return {boolean}
     */
    public get isSelected(): boolean {
        return this._isSelected;
    }

    /**
     * Getter name
     * @return {string}
     */
    public get name(): string {
        if (this._firstName || this._lastName) {
            let firstName = this._firstName ? this._firstName + " " : '';
            let lastName = this._lastName ? this._lastName : '';
            return firstName + lastName;
        }
        else {
            return this._title;
        }
    }

    /**
     * Setter company
     * @param {string} value
     */
    public set company(value: string) {
        this._company = value;
    }

    /**
     * Setter title
     * @param {string} value
     */
    public set title(value: string) {
        this._title = value;
    }

    /**
     * Setter preTitle
     * @param {string} value
     */
    public set preTitle(value: string) {
        this._preTitle = value;
    }

    /**
     * Setter firstName
     * @param {string} value
     */
    public set firstName(value: string) {
        this._firstName = value;
    }

    /**
     * Setter initial
     * @param {string} value
     */
    public set initial(value: string) {
        this._initial = value;
    }

    /**
     * Setter lastName
     * @param {string} value
     */
    public set lastName(value: string) {
        this._lastName = value;
    }

    /**
     * Setter suffix
     * @param {string} value
     */
    public set suffix(value: string) {
        this._suffix = value;
    }

    /**
     * Setter phone
     * @param {string} value
     */
    public set phone(value: string) {
        this._phone = value;
    }

    /**
     * Setter mobile
     * @param {string} value
     */
    public set mobile(value: string) {
        this._mobile = value;
    }

    /**
     * Setter fax
     * @param {string} value
     */
    public set fax(value: string) {
        this._fax = value;
    }

    /**
     * Setter email
     * @param {string} value
     */
    public set email(value: string) {
        this._email = value;
    }

    /**
     * Setter addressLine1
     * @param {string} value
     */
    public set addressLine1(value: string) {
        this._addressLine1 = value;
    }

    /**
     * Setter addressLine2
     * @param {string} value
     */
    public set addressLine2(value: string) {
        this._addressLine2 = value;
    }

    /**
     * Setter addressLine3
     * @param {string} value
     */
    public set addressLine3(value: string) {
        this._addressLine3 = value;
    }

    /**
     * Setter city
     * @param {string} value
     */
    public set city(value: string) {
        this._city = value;
    }

    /**
     * Setter country
     * @param {string} value
     */
    public set country(value: string) {
        this._country = value;
    }

    /**
     * Setter postalCode
     * @param {string} value
     */
    public set postalCode(value: string) {
        this._postalCode = value;
    }

    /**
     * Setter state
     * @param {string} value
     */
    public set state(value: string) {
        this._state = value;
    }

    /**
     * Setter firreAddressNumber
     * @param {string} value
     */
    public set firreAddressNumber(value: string) {
        this._firreAddressNumber = value;
    }

    /**
     * Setter acsNameKey
     * @param {string} value
     */
    public set acsNameKey(value: string) {
        this._acsNameKey = value;
    }

    /**
     * Setter nexenClientId
     * @param {string} value
     */
    public set nexenClientId(value: string) {
        this._nexenClientId = value;
    }

    public set eagleIntPartyId(value: string) {
        this._eagleIntPartyId = value;
    }

    /**
     * Setter proxyEdgeId
     * @param {string} value
     */
    public set proxyEdgeId(value: string) {
        this._proxyEdgeId = value;
    }

    /**
     * Setter contactId
     * @param {number} value
     */
    public set contactId(value: number) {
        this._contactId = value;
    }

    /**
     * Setter isBillingContact
     * @param {boolean} value
     */
    public set isBillingContact(value: boolean) {
        this._isBillingContact = value;
    }

    /**
     * Setter isSelected
     * @param {boolean} value
     */
    public set isSelected(value: boolean) {
        this._isSelected = value;
    }

    /**
     * Setter name
     * @param {string} value
     */
    public set name(value: string) {
        this._name = value;
    }

    static reviver(key: string, value: any): any {
        return key === "" ? ContactDetail.fromJSON(value) : value;
    }

    static fromJSON(json: string): ContactDetail {
        if (typeof json === 'string') {
            return JSON.parse(json, ContactDetail.reviver);
        } else {
            let contact = Object.create(ContactDetail.prototype);
            return Object.assign(contact, json);
        }
    }

}
