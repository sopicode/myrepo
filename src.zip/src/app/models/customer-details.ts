import { TableModel } from "./table-model";

export class CustomerDetail extends TableModel {
    private _legalName: string;
    private _cid: string;
    private _countryName: string;
    private _addressLine1: string;
    private _addressLine2: string;
    private _city: string;
    private _country: string;
    private _dealId: string;
    private _dealPartyRoleId: number;
    private _entitySubTypeCode: string;
    private _entitySubTypeDesc: string;
    private _entityTypeCode: string;
    private _entityTypeDesc: string;
    private _goldTierId: string;
    private _id: number;
    private _ipid: string;
    private _isCountryWithholdingTaxApplicable: boolean;
    private _isEU: boolean;
    private _isSelected: boolean;
    private _legalEntityIndicator: string;
    private _locationId: number;
    private _partyId: number;
    private _partyRoleId: number;
    private _partyRoleTypeCode: string;
    private _partyRoleTypeDescription: string;
    private _relationId: string;
    private _state: string;
    private _vat: string;
    private _zip: string;


    /**
     * Getter legalName
     * @return {string}
     */
    public get legalName(): string {
        return this._legalName;
    }

    /**
     * Getter cid
     * @return {string}
     */
    public get cid(): string {
        return this._cid;
    }

    /**
     * Getter countryName
     * @return {string}
     */
    public get countryName(): string {
        return this._countryName;
    }

    /**
     * Getter addressLine1
     * @return {string}
     */
    public get addressLine1(): string {
        return this._addressLine1;
    }

    /**
     * Getter addressLine2
     * @return {string}
     */
    public get addressLine2(): string {
        return this._addressLine2;
    }

    /**
     * Getter city
     * @return {string}
     */
    public get city(): string {
        return this._city;
    }

    /**
     * Getter country
     * @return {string}
     */
    public get country(): string {
        return this._country;
    }

    /**
     * Getter dealId
     * @return {string}
     */
    public get dealId(): string {
        return this._dealId;
    }

    /**
     * Getter dealPartyRoleId
     * @return {number}
     */
    public get dealPartyRoleId(): number {
        return this._dealPartyRoleId;
    }

    /**
     * Getter entitySubTypeCode
     * @return {string}
     */
    public get entitySubTypeCode(): string {
        return this._entitySubTypeCode;
    }

    /**
     * Getter entitySubTypeDesc
     * @return {string}
     */
    public get entitySubTypeDesc(): string {
        return this._entitySubTypeDesc;
    }

    /**
     * Getter entityTypeCode
     * @return {string}
     */
    public get entityTypeCode(): string {
        return this._entityTypeCode;
    }

    /**
     * Getter entityTypeDesc
     * @return {string}
     */
    public get entityTypeDesc(): string {
        return this._entityTypeDesc;
    }

    /**
     * Getter goldTierId
     * @return {string}
     */
    public get goldTierId(): string {
        return this._goldTierId;
    }

    /**
     * Getter id
     * @return {number}
     */
    public get id(): number {
        return this._id;
    }

    /**
     * Getter ipid
     * @return {string}
     */
    public get ipid(): string {
        return this._ipid;
    }

    /**
     * Getter isCountryWithholdingTaxApplicable
     * @return {boolean}
     */
    public get isCountryWithholdingTaxApplicable(): boolean {
        return this._isCountryWithholdingTaxApplicable;
    }

    /**
     * Getter isEU
     * @return {boolean}
     */
    public get isEU(): boolean {
        return this._isEU;
    }

    /**
     * Getter isSelected
     * @return {boolean}
     */
    public get isSelected(): boolean {
        return this._isSelected;
    }

    /**
     * Getter legalEntityIndicator
     * @return {string}
     */
    public get legalEntityIndicator(): string {
        return this._legalEntityIndicator;
    }

    /**
     * Getter locationId
     * @return {number}
     */
    public get locationId(): number {
        return this._locationId;
    }

    /**
     * Getter partyId
     * @return {number}
     */
    public get partyId(): number {
        return this._partyId;
    }

    /**
     * Getter partyRoleId
     * @return {number}
     */
    public get partyRoleId(): number {
        return this._partyRoleId;
    }

    /**
     * Getter partyRoleTypeCode
     * @return {string}
     */
    public get partyRoleTypeCode(): string {
        return this._partyRoleTypeCode;
    }

    /**
     * Getter partyRoleTypeDescription
     * @return {string}
     */
    public get partyRoleTypeDescription(): string {
        return this._partyRoleTypeDescription;
    }

    /**
     * Getter relationId
     * @return {string}
     */
    public get relationId(): string {
        return this._relationId;
    }

    /**
     * Getter state
     * @return {string}
     */
    public get state(): string {
        return this._state;
    }

    /**
     * Getter vat
     * @return {string}
     */
    public get vat(): string {
        return this._vat;
    }

    /**
     * Getter zip
     * @return {string}
     */
    public get zip(): string {
        return this._zip;
    }

    /**
     * Setter legalName
     * @param {string} value
     */
    public set legalName(value: string) {
        this._legalName = value;
    }

    /**
     * Setter cid
     * @param {string} value
     */
    public set cid(value: string) {
        this._cid = value;
    }

    /**
     * Setter countryName
     * @param {string} value
     */
    public set countryName(value: string) {
        this._countryName = value;
    }

    /**
     * Setter addressLine1
     * @param {string} value
     */
    public set addressLine1(value: string) {
        this._addressLine1 = value;
    }

    /**
     * Setter addressLine2
     * @param {string} value
     */
    public set addressLine2(value: string) {
        this._addressLine2 = value;
    }

    /**
     * Setter city
     * @param {string} value
     */
    public set city(value: string) {
        this._city = value;
    }

    /**
     * Setter country
     * @param {string} value
     */
    public set country(value: string) {
        this._country = value;
    }

    /**
     * Setter dealId
     * @param {string} value
     */
    public set dealId(value: string) {
        this._dealId = value;
    }

    /**
     * Setter dealPartyRoleId
     * @param {number} value
     */
    public set dealPartyRoleId(value: number) {
        this._dealPartyRoleId = value;
    }

    /**
     * Setter entitySubTypeCode
     * @param {string} value
     */
    public set entitySubTypeCode(value: string) {
        this._entitySubTypeCode = value;
    }

    /**
     * Setter entitySubTypeDesc
     * @param {string} value
     */
    public set entitySubTypeDesc(value: string) {
        this._entitySubTypeDesc = value;
    }

    /**
     * Setter entityTypeCode
     * @param {string} value
     */
    public set entityTypeCode(value: string) {
        this._entityTypeCode = value;
    }

    /**
     * Setter entityTypeDesc
     * @param {string} value
     */
    public set entityTypeDesc(value: string) {
        this._entityTypeDesc = value;
    }

    /**
     * Setter goldTierId
     * @param {string} value
     */
    public set goldTierId(value: string) {
        this._goldTierId = value;
    }

    /**
     * Setter id
     * @param {number} value
     */
    public set id(value: number) {
        this._id = value;
    }

    /**
     * Setter ipid
     * @param {string} value
     */
    public set ipid(value: string) {
        this._ipid = value;
    }

    /**
     * Setter isCountryWithholdingTaxApplicable
     * @param {boolean} value
     */
    public set isCountryWithholdingTaxApplicable(value: boolean) {
        this._isCountryWithholdingTaxApplicable = value;
    }

    /**
     * Setter isEU
     * @param {boolean} value
     */
    public set isEU(value: boolean) {
        this._isEU = value;
    }

    /**
     * Setter isSelected
     * @param {boolean} value
     */
    public set isSelected(value: boolean) {
        this._isSelected = value;
    }

    /**
     * Setter legalEntityIndicator
     * @param {string} value
     */
    public set legalEntityIndicator(value: string) {
        this._legalEntityIndicator = value;
    }

    /**
     * Setter locationId
     * @param {number} value
     */
    public set locationId(value: number) {
        this._locationId = value;
    }

    /**
     * Setter partyId
     * @param {number} value
     */
    public set partyId(value: number) {
        this._partyId = value;
    }

    /**
     * Setter partyRoleId
     * @param {number} value
     */
    public set partyRoleId(value: number) {
        this._partyRoleId = value;
    }

    /**
     * Setter partyRoleTypeCode
     * @param {string} value
     */
    public set partyRoleTypeCode(value: string) {
        this._partyRoleTypeCode = value;
    }

    /**
     * Setter partyRoleTypeDescription
     * @param {string} value
     */
    public set partyRoleTypeDescription(value: string) {
        this._partyRoleTypeDescription = value;
    }

    /**
     * Setter relationId
     * @param {string} value
     */
    public set relationId(value: string) {
        this._relationId = value;
    }

    /**
     * Setter state
     * @param {string} value
     */
    public set state(value: string) {
        this._state = value;
    }

    /**
     * Setter vat
     * @param {string} value
     */
    public set vat(value: string) {
        this._vat = value;
    }

    /**
     * Setter zip
     * @param {string} value
     */
    public set zip(value: string) {
        this._zip = value;
    }


    static reviver(key: string, value: any): any {
        return key === "" ? CustomerDetail.fromJSON(value) : value;
    }

    static fromJSON(json: string): CustomerDetail {
        if (typeof json === 'string') {
            return JSON.parse(json, CustomerDetail.reviver);
        } else {
            let customer = Object.create(CustomerDetail.prototype);
            return Object.assign(customer, json);
        }
    }

}