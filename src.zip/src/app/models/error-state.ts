export interface ErrorState {
    show: boolean;
    errorObject: any;
}
