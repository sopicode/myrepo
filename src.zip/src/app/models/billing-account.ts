import { BillingAccountService } from "./billing-account-service";
import { Role } from "./role";
import { FeeServiceDetail } from "./fee-service-detail";
import { Link } from "./link";
import { LegalEntity } from "./legalEntity";

export class BillingAccount {

    private _id: number;
    private _billingRequestId: number;
    private _billingKey: string;
    private _acctShortName: string;
    private _acctLongName: string;
    private _currencyCd: string;
    private _invcLanguageCode: string;
    private _costCenterCode: string;
    private _cyclicalInvcDstrbtn: string;
    private _initInvcDstrbtn: string;
    private _billDay: string;
    private _billingFrequency: string;
    private _gvrnmntClntIndctr: string;
    private _onetimeBillingIndctr: boolean;
    private _billingStartDate: string;
    private _maturityDate: string;
    private _nextBillDate: string;
    private _initInvcRqrdIndctr: boolean;
    private _suppressInvcIndctr: boolean;
    private _upfrntFeesIndctr: boolean;
    private _separateBillingDisplayIndctr: boolean;
    private _feeScheduleMatchIndctr: boolean;
    private _billingAccountServices: BillingAccountService[];
    private _legalName: string;
    private _partyId: number;
    private _roles: Role[];
    private _links: Link[];
    private _clientCategoryIndctr: boolean;
    private _isEU: boolean;
    private _feeAndServiceDetails: FeeServiceDetail[];
    private _duplicateAccountKey: string;
    private _isCopyAccount: boolean;

    public get isCopyAccount(): boolean {
        return this._isCopyAccount;
    }
    public set isCopyAccount(value: boolean) {
        this._isCopyAccount = value;
    }

    public get id(): number {
        return this._id;
    }
    public set id(value: number) {
        this._id = value;
    }
    public get billingRequestId(): number {
        return this._billingRequestId;
    }
    public set billingRequestId(value: number) {
        this._billingRequestId = value;
    }
    public get billingKey(): string {
        return this._billingKey;
    }
    public set billingKey(value: string) {
        this._billingKey = value;
    }
    public get acctShortName(): string {
        return this._acctShortName;
    }
    public set acctShortName(value: string) {
        this._acctShortName = value;
    }
    public get acctLongName(): string {
        return this._acctLongName;
    }
    public set acctLongName(value: string) {
        this._acctLongName = value;
    }
    public get currencyCd(): string {
        return this._currencyCd;
    }
    public set currencyCd(value: string) {
        this._currencyCd = value;
    }
    public get invcLanguageCode(): string {
        return this._invcLanguageCode;
    }
    public set invcLanguageCode(value: string) {
        this._invcLanguageCode = value;
    }
    public get costCenterCode(): string {
        return this._costCenterCode;
    }
    public set costCenterCode(value: string) {
        this._costCenterCode = value;
    }
    public get cyclicalInvcDstrbtn(): string {
        return this._cyclicalInvcDstrbtn;
    }
    public set cyclicalInvcDstrbtn(value: string) {
        this._cyclicalInvcDstrbtn = value;
    }
    public get initInvcDstrbtn(): string {
        return this._initInvcDstrbtn;
    }
    public set initInvcDstrbtn(value: string) {
        this._initInvcDstrbtn = value;
    }
    public get billDay(): string {
        return this._billDay;
    }
    public set billDay(value: string) {
        this._billDay = value;
    }
    public get billingFrequency(): string {
        return this._billingFrequency;
    }
    public set billingFrequency(value: string) {
        this._billingFrequency = value;
    }
    public get gvrnmntClntIndctr(): string {
        return this._gvrnmntClntIndctr;
    }
    public set gvrnmntClntIndctr(value: string) {
        this._gvrnmntClntIndctr = value;
    }
    public get onetimeBillingIndctr(): boolean {
        return this._onetimeBillingIndctr;
    }
    public set onetimeBillingIndctr(value: boolean) {
        this._onetimeBillingIndctr = value;
    }
    public get billingStartDate(): string {
        return this._billingStartDate;
    }
    public set billingStartDate(value: string) {
        this._billingStartDate = value;
    }
    public get maturityDate(): string {
        return this._maturityDate;
    }
    public set maturityDate(value: string) {
        this._maturityDate = value;
    }
    public get nextBillDate(): string {
        return this._nextBillDate;
    }
    public set nextBillDate(value: string) {
        this._nextBillDate = value;
    }
    public get initInvcRqrdIndctr(): boolean {
        return this._initInvcRqrdIndctr;
    }
    public set initInvcRqrdIndctr(value: boolean) {
        this._initInvcRqrdIndctr = value;
    }
    public get suppressInvcIndctr(): boolean {
        return this._suppressInvcIndctr;
    }
    public set suppressInvcIndctr(value: boolean) {
        this._suppressInvcIndctr = value;
    }
    public get upfrntFeesIndctr(): boolean {
        return this._upfrntFeesIndctr;
    }
    public set upfrntFeesIndctr(value: boolean) {
        this._upfrntFeesIndctr = value;
    }
    public get separateBillingDisplayIndctr(): boolean {
        return this._separateBillingDisplayIndctr;
    }
    public set separateBillingDisplayIndctr(value: boolean) {
        this._separateBillingDisplayIndctr = value;
    }
    public get feeScheduleMatchIndctr(): boolean {
        return this._feeScheduleMatchIndctr;
    }
    public set feeScheduleMatchIndctr(value: boolean) {
        this._feeScheduleMatchIndctr = value;
    }
    public get billingAccountServices(): BillingAccountService[] {
        return this._billingAccountServices;
    }
    public set billingAccountServices(value: BillingAccountService[]) {
        this._billingAccountServices = value;
    }
    public get legalName(): string {
        return this._legalName;
    }
    public set legalName(value: string) {
        this._legalName = value;
    }
    public get partyId(): number {
        return this._partyId;
    }
    public set partyId(value: number) {
        this._partyId = value;
    }
    public get roles(): Role[] {
        return this._roles;
    }
    public set roles(value: Role[]) {
        this._roles = value;
    }
    public get links(): Link[] {
        return this._links;
    }
    public set links(value: Link[]) {
        this._links = value;
    }
    public get clientCategoryIndctr(): boolean {
        return this._clientCategoryIndctr;
    }
    public set clientCategoryIndctr(value: boolean) {
        this._clientCategoryIndctr = value;
    }
    public get feeAndServiceDetails(): FeeServiceDetail[] {
        return this._feeAndServiceDetails;
    }
    public set feeAndServiceDetails(value: FeeServiceDetail[]) {
        this._feeAndServiceDetails = value;
    }
    public get isEU(): boolean {
        return this._isEU;
    }
    public set isEU(value: boolean) {
        this._isEU = value;
    }

    public get duplicateAccountKey(): string {
        return this._duplicateAccountKey;
    }
    public set duplicateAccountKey(value: string) {
        this._duplicateAccountKey = value;
    }

    static reviver(key: string, value: any): any {
        return key === "" ? BillingAccount.fromJSON(value) : value;
    }

    static fromJSON(json: any | string): BillingAccount {
        if (typeof json === 'string') {
            return JSON.parse(json, BillingAccount.reviver);
        } else {
            let billingAcct = Object.create(BillingAccount.prototype);
            billingAcct = (<any>Object).assign(billingAcct, json, {
                _billingAccountServices: BillingAccount.buildBillingAccountServices(json.billingAccountServices),
                _roles: BillingAccount.buildRoles(json.roles),
                _feeAndServiceDetails: BillingAccount.buildFeeAndServiceDetails(json.feeAndServiceDetails)
            });
            return billingAcct;
        }
    }

    static buildBillingAccountServices(billingAccountServiceList: any): BillingAccountService[] {
        let billingAccountServices: BillingAccountService[] = [];
        if (Array.isArray(billingAccountServiceList)) {
            for (let billingAccountService of billingAccountServiceList) {
                billingAccountServices.push(BillingAccountService.fromJSON(billingAccountService));
            }
        } else if (billingAccountServiceList) {
            billingAccountServices.push(BillingAccountService.fromJSON(billingAccountServiceList));
        }
        return billingAccountServices;
    }

    static buildLegalEntities(legalEntityList: any): LegalEntity[] {
        let legalEntitiesList: LegalEntity[] = [];
        if (Array.isArray(legalEntityList)) {
            for (let legal of legalEntityList) {
                legalEntitiesList.push(LegalEntity.fromJSON(legal));
            }
        } else if (legalEntityList) {
            legalEntitiesList.push(LegalEntity.fromJSON(legalEntityList));
        }
        return legalEntitiesList;
    }


    static buildRoles(roleList: any): Role[] {
        let roles: Role[] = [];
        if (Array.isArray(roleList)) {
            for (let role of roleList) {
                roles.push(Role.fromJSON(role));
            }
        } else if (roleList) {
            roles.push(Role.fromJSON(roleList));
        }
        return roles;
    }

    static buildFeeAndServiceDetails(feeAndServiceList: any): FeeServiceDetail[] {
        let feeAndServiceDetails: FeeServiceDetail[] = [];
        if (Array.isArray(feeAndServiceList)) {
            for (let feeAndServiceDetail of feeAndServiceList) {
                feeAndServiceDetails.push(FeeServiceDetail.fromJSON(feeAndServiceDetail));
            }
        } else if (feeAndServiceList) {
            feeAndServiceDetails.push(FeeServiceDetail.fromJSON(feeAndServiceList));
        }
        return feeAndServiceDetails;
    }

}
