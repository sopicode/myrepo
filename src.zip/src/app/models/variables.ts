export class Variables {
    private _action: string;
    private _approveBillingTaskName: string;
    private _billingGroup: string;
    private _billingRequestId: number;
    private _billingSequence: number;
    private _billingTaskInitiator: string;
    private _isApproveTask: boolean;
    private _isApproveTaskRequired: string;
    private _makerCheckerErrorMessage: string;
    private _serviceManager: string;
    private _specialBillingLegalEntity: string;
    private _isApproved: boolean;
    private _billingStatus: string;
    private _billingSuccess: boolean;
    private _rejectionComments: string;
    private _rejectReason: string;
    private _billingKey: string;
    private _billingKeyList: any;
    private _isDataMismatch: boolean;
    private _ebwConnectionErrorMessage: string;
    private _ebwAcknowledged: boolean;

    public get ebwAcknowledged(): boolean {
        return this._ebwAcknowledged;
    }
    public set ebwAcknowledged(value: boolean) {
        this._ebwAcknowledged = value;
    }

    public get ebwConnectionErrorMessage(): string {
        return this._ebwConnectionErrorMessage;
    }
    public set ebwConnectionErrorMessage(value: string) {
        this._ebwConnectionErrorMessage = value;
    }

    public get rejectReason(): string {
        return this._rejectReason;
    }
    public set rejectReason(value: string) {
        this._rejectReason = value;
    }

    public get rejectionComments(): string {
        return this._rejectionComments;
    }
    public set rejectionComments(value: string) {
        this._rejectionComments = value;
    }
    
    public get billingSuccess(): boolean {
        return this._billingSuccess;
    }
    public set billingSuccess(value: boolean) {
        this._billingSuccess = value;
    }

    public get isDataMismatch(): boolean {
        return this._isDataMismatch;
    }
    public set isDataMismatch(value: boolean) {
        this._isDataMismatch = value;
    }

    public get billingStatus(): string {
        return this._billingStatus;
    }
    public set billingStatus(value: string) {
        this._billingStatus = value;
    }
    
    public get isApproved(): boolean {
        return this._isApproved;
    }
    public set isApproved(value: boolean) {
        this._isApproved = value;
    }

    public get action(): string {
        return this._action;
    }
    public set action(value: string) {
        this._action = value;
    }

    public get approveBillingTaskName(): string {
        return this._approveBillingTaskName;
    }
    public set approveBillingTaskName(value: string) {
        this._approveBillingTaskName = value;
    }

    public get billingGroup(): string {
        return this._billingGroup;
    }
    public set billingGroup(value: string) {
        this._billingGroup = value;
    }

    public get billingSequence(): number {
        return this._billingSequence;
    }
    public set billingSequence(value: number) {
        this._billingSequence = value;
    }

    public get billingTaskInitiator(): string {
        return this._billingTaskInitiator;
    }
    public set billingTaskInitiator(value: string) {
        this._billingTaskInitiator = value;
    }

    public get isApproveTask(): boolean {
        return this._isApproveTask;
    }
    public set isApproveTask(value: boolean) {
        this._isApproveTask = value;
    }

    public get isApproveTaskRequired(): string {
        return this._isApproveTaskRequired;
    }
    public set isApproveTaskRequired(value: string) {
        this._isApproveTaskRequired = value;
    }

    public get makerCheckerErrorMessage(): string {
        return this._makerCheckerErrorMessage;
    }
    public set makerCheckerErrorMessage(value: string) {
        this._makerCheckerErrorMessage = value;
    }

    public get billingRequestId(): number {
        return this._billingRequestId;
    }
    public set billingRequestId(value: number) {
        this._billingRequestId = value;
    }

    public get serviceManager(): string {
        return this._serviceManager;
    }
    public set serviceManager(value: string) {
        this._serviceManager = value;
    }

    public get specialBillingLegalEntity(): string {
        return this._specialBillingLegalEntity;
    }
    public set specialBillingLegalEntity(value: string) {
        this._specialBillingLegalEntity = value;
    }
    public get billingKey(): string {
        return this._billingKey;
    }
    public set billingKey(value: string) {
        this._billingKey = value;
    }
    public get billingKeyList(): any {
        return this._billingKeyList;
    }
    public set billingKeyList(value: any) {
        this._billingKeyList = value;
    }
    static fromJSON(json: string): Variables {
        let variablesMap = Object.create(Variables.prototype);
        return Object.assign(variablesMap, json);
    }

} 