import { TableModel } from "./table-model";

export class BillingInvoiceDetails extends TableModel {
    private _invoiceNumber: string;
    public get invoiceNumber(): string {
        return this._invoiceNumber;
    }
    public set invoiceNumber(value: string) {
        this._invoiceNumber = value;
    }
    private _invoiceAmount: string;
    public get invoiceAmount(): string {
        return this._invoiceAmount;
    }
    public set invoiceAmount(value: string) {
        this._invoiceAmount = value;
    }
    private _invoiceType: string;
    public get invoiceType(): string {
        return this._invoiceType;
    }
    public set invoiceType(value: string) {
        this._invoiceType = value;
    }

    static fromJSON(json: string): BillingInvoiceDetails {
        let invoiceDetails = Object.create(BillingInvoiceDetails.prototype);
        return Object.assign(invoiceDetails, json);
    }

}