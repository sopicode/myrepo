import { NgModule } from '@angular/core';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { SharedModule } from './shared.module';

import { AppComponent } from './app.component';
import { LoaderInterceptorService } from './services/loader-interceptor.service';
import { TestInterceptorService } from './services/test-interceptor.service';

@NgModule({
  declarations: [
    
  ],
  imports: [
    SharedModule
  ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: LoaderInterceptorService,
      multi: true
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: TestInterceptorService,
      multi: true
    }
  ],
  bootstrap: [AppComponent]
})
export class TestModule { }