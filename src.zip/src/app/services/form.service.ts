import { Injectable } from '@angular/core';
import { HelperService } from './helper.service';
import { FormGroup, FormControl, FormArray } from '@angular/forms';
import { Error } from '../models/error';

@Injectable({
  providedIn: 'root'
})
export class FormService {

  constructor(private helperService: HelperService) { }

  validateForm(formToValidate: FormGroup, errors: Error[]) {
    let errorMessages: string[] = [];
    this.validateAllFormFields(formToValidate, errors, errorMessages);
    return errorMessages;
  }

  validateAllFormFields(formGroup: any, errors: Error[], errorMessages: string[]) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        this.addErrors(field,control,errors,errorMessages);
      }
      if (control instanceof FormGroup || control instanceof FormArray) {
        this.validateAllFormFields(control, errors, errorMessages);
        if(control.errors){
          this.addErrors(field,control,errors,errorMessages);
        }
      }
    });
  }

  addErrors(field,control,errors,errorMessages){
    if (control.invalid) {
      for (const key in control.errors) {
        let err: Error = new Error();
        if (/^\d+$/.test(field) && (control instanceof FormGroup || control instanceof FormArray)) {
          err.field = "";
        } else {
          err.field = field;
        }
        err.errorKey = key;
        let error: Error = this.helperService.findError(errors, err);
        if (error) {
          errorMessages.push(error.message);
        }
      }
    }
  }

  /* Validate all form fields before posting form data to server*/
  validateFormFields(formGroup: any) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup || control instanceof FormArray) {
        control.markAsTouched({ onlySelf: true });
        this.validateFormFields(control);
      }
    });
  }

  collectData(formGroup: any, data: any, collectNonEmptyValue?: boolean) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl || control instanceof FormArray) {
        if (control["hidden"]) {
          data[field] = null;
        } else {
          if (control instanceof FormArray) {
            if ((!collectNonEmptyValue || (collectNonEmptyValue && control.getRawValue()))) {
              data[field] = control.getRawValue();
            }
          } else {
            if ((!collectNonEmptyValue || (collectNonEmptyValue && control.value))) {
              data[field] = control.value;
            }
          }
        }
      } else if (control instanceof FormGroup) {
        this.collectData(control, data);
      }
    });
  }
}
