import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { environment } from './../../environments/environment';
import { of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { HelperService } from './helper.service';

@Injectable({
  providedIn: 'root'
})
export class ReferencesService {

  private referencesUrl: string;

  constructor(private http: HttpClient, private helperService: HelperService) {
    this.referencesUrl = helperService.getBaseUrl() + "/references/";
  }

  getProductGroups(): any {
    let productGroupsUrl = this.referencesUrl + "product-groups";
    return this.getRequest(productGroupsUrl);
  }

  getDealTypes(): any {
    let dealTypesUrl = this.referencesUrl + "deal-types";
    return this.getRequest(dealTypesUrl);
  }

  getMajorProducts(productGroupId: number, majorProductId: number): any {
    let majorProductsUrl = this.referencesUrl + "product-groups/" + productGroupId + "/major-products/" + majorProductId;
    return this.getRequest(majorProductsUrl);
  }

  getCountry(): any {
    let countryList = this.referencesUrl + "countries";
    return this.getRequest(countryList);
  }

  getBillingTeamGroups(groupType: string): any {
    let teamGroupList = this.referencesUrl + "groupTypes/" + groupType + "/groups";
    return this.getRequest(teamGroupList);
  }

  getBillingCurrencies(): any {
    let billingCurrenciesUrl = this.referencesUrl + "billing-currencies";
    return this.getRequest(billingCurrenciesUrl);
  }

  getCostCenters(): any {
    let costCentersUrl = this.referencesUrl + "cost-centers";
    return this.getRequest(costCentersUrl);
  }

  getInvoiceDistributionTypes(): any {
    let invoiceDistributionTypesUrl = this.referencesUrl + "invoice-distribution-types";
    return this.getRequest(invoiceDistributionTypesUrl);
  }

  getBillDayTypes(): any {
    let billDayTypesUrl = this.referencesUrl + "bill-day-types";
    return this.getRequest(billDayTypesUrl);
  }

  getSystemNames(): any {
    let systemNamesUrl = this.referencesUrl + "system-names";
    return this.getRequest(systemNamesUrl);
  }

  getSystemPurpose(): any {
    let systemPuposeUrl = this.referencesUrl + "system-purpose";
    return this.getRequest(systemPuposeUrl);
  }

  getSubSystemNames(): any {
    let subSystemNamesUrl = this.referencesUrl + "subsystem-names";
    return this.getRequest(subSystemNamesUrl);
  }

  getProrationRules(): any {
    let prorationRulesUrl = this.referencesUrl + "proration-rules";
    return this.getRequest(prorationRulesUrl);
  }

  getFeeAccrlMethods(): any {
    let feeAccrlMethodsUrl = this.referencesUrl + "fee-accrl-methods";
    return this.getRequest(feeAccrlMethodsUrl);
  }

  getBillingFrequencies(): any {
    let billingFrequenciesUrl = this.referencesUrl + "billing-frequencies/N";
    return this.getRequest(billingFrequenciesUrl);
  }

  getBillingFrequencySource(): any {
    let billingFrequenciesUrl = this.referencesUrl + "billing-frequencies/Y";
    return this.getRequest(billingFrequenciesUrl);
  }

  getBillingDocumentTypes(): any {
    let billingDocTypesUrl = this.referencesUrl + "billing-document-types";
    return this.getRequest(billingDocTypesUrl);
  }

  getBillingInvoiceLanguage(): any {
    let billingInvoiceLangUrl = this.referencesUrl + "billing-invoice-language";
    return this.getRequest(billingInvoiceLangUrl);
  }

  getTitle(): any {
    let titleUrl = this.referencesUrl + "individual-titles";
    return this.getRequest(titleUrl);
  }

  getPreTitle(): any {
    let preTitleUrl = this.referencesUrl + "pre-titles";
    return this.getRequest(preTitleUrl);
  }

  getSuffix(): any {
    let suffixUrl = this.referencesUrl + "suffixes";
    return this.getRequest(suffixUrl);
  }

  getCountrySubDivisions(code): any {
    let subDivUrl = this.referencesUrl + "countries/" + code + "/subdivisions";
    return this.getRequest(subDivUrl);
  }

  getPartyRoleTypes(): any {
    let partyRoleTypesUrl = this.referencesUrl + "party-role-types";
    return this.getRequest(partyRoleTypesUrl);
  }

  getFeeTemplate(): any {
    let feeTemplateUrl = this.referencesUrl + "fee-templates";
    return this.getRequest(feeTemplateUrl);
  }

  getwithholdingTaxBearerCode(): any {
    let withHoldingUrl = this.referencesUrl + "withholding-tax-bearer";
    return this.getRequest(withHoldingUrl);
  }

  getwithHoldingTypeCode(): any {
    let withHoldingTypeCodeUrl = this.referencesUrl + "withholding-types";
    return this.getRequest(withHoldingTypeCodeUrl);
  }

  getSpecialLegalEntitiesByIndicator(indicator: string): any {
    let specialBillingLegalEntitiesUrl = this.referencesUrl + "special-billing-roles/" + indicator;
    return this.getRequest(specialBillingLegalEntitiesUrl);
  }

  getSpecialLegalEntities(): any{
    let specialBillingLegalEntitiesUrl = this.referencesUrl + "special-billing-rules";
    return this.getRequest(specialBillingLegalEntitiesUrl);
  }

  getRequest(url: string): any {
    return this.http.get(url).pipe(
      catchError((err: HttpErrorResponse) => {
        return of({});
      }))
  }

  getReason(categoryCode: string): any {
    let reasonUrl = this.referencesUrl + "reason/" + categoryCode;
    return this.getRequest(reasonUrl);
  }
  
}
