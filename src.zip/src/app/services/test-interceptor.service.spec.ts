import { TestBed, inject } from '@angular/core/testing';

import { TestInterceptorService } from './test-interceptor.service';

describe('TestInterceptorService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [TestInterceptorService]
    });
  });

  it('should be created', inject([TestInterceptorService], (service: TestInterceptorService) => {
    expect(service).toBeTruthy();
  }));
});
