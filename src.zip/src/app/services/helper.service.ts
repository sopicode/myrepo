import { Injectable } from '@angular/core';
import { _ } from 'underscore';
import { Error } from '../models/error';
import { FormArray, FormGroup, ValidatorFn } from '@angular/forms';

@Injectable({
  providedIn: 'root'
})
export class HelperService {

  constructor() { }

  public find(options: any[], key: string, value: any): any {
    return _.find(options, function (o) { return o[key] === value; })
  }

  public findError(errors: Error[], error: Error) {
    return _.find(errors, function (err) { return err.field == error.field && err.errorKey == error.errorKey; })
  }

  public filter(options: any[], key: string, value: any): any {
    return _.filter(options, function (o) { return o[key] !== value; });
  }

  public filterByKey(options: any[], key: string, value: any): any {
    return _.filter(options, function (o) { return o[key] === value; });
  }

  public some(data: any[], filter: any): boolean {
    return _.some(data, filter);
  }

  public groupBy(data:any[],property:string){
    return _.groupBy(data,property);
  }

  public filterByArray(data1:any[],data2:any,key1:string,key2:string){
    return _.filter(data1, function(obj1){
      return _.find(data2, function(obj2){
          return obj1[key1] === obj2[key2];
      });
    });
  }

  public removeFromArray(data1:any[],data2:any,key1:string,key2:string){
    return _.filter(data1, function(obj1){
      var containsKey = _.find(data2, function(obj2){
          return obj1[key1] === obj2[key2];
      });
      return !containsKey;
    });
  }

  buildError(field: string, message: string, errorKey: string) {
    let error: Error = new Error();
    error.field = field;
    error.errorKey = errorKey;
    error.message = message;
    return error;
  }

  buildOption(key: any, value: string) {
    let option: any = {};
    option.key = key;
    option.value = value;
    return option;
  }

  clearFormArray = (formArray: FormArray) => {
    while (formArray.length !== 0) {
      formArray.removeAt(0)
    }
  }

  // disabling the form control to stop validation and set hidden attribute
  hideFormControl(form: FormGroup, formControlName: string) {
    let formControl = form.controls[formControlName];
    formControl.disable();
    formControl['hidden'] = true;
  }

  // disabling the form control to enable validations and reset hidden attribute value
  showFormControl(form: FormGroup, formControlName: any) {
    let formControl = form.controls[formControlName];
    formControl.enable();
    formControl['hidden'] = false;
  }

  // add validations
  addValidation(form: FormGroup, formControlName: any, validators: ValidatorFn | ValidatorFn[]) {
    let formControl = form.controls[formControlName];
    formControl.setValidators(validators);
    formControl.updateValueAndValidity();
  }

  // remove validations
  removeValidation(form: FormGroup, formControlName: string) {
    let formControl = form.controls[formControlName];
    formControl.setValidators(null);
    formControl.updateValueAndValidity();
  }

  getBaseUrl(): string {
    const origin = window.location.origin;
    if (origin.indexOf('localhost') !== -1) {
      return 'https://trust.dev.bnymellon.net';
    } else {
      return origin;
    }
  }

  public filterActiveValues(options: any[]) {
    return _.filter(options, function (option) {
      if (_.has(option, 'isActive')) {
        if (option.isActive) {
          return option;
        }
        return false;
      }
      return option;
    });
  }

}
