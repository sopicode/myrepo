import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { HelperService } from './helper.service';

@Injectable({
  providedIn: 'root'
})
export class DealService {

  private dealsUrl: string;

  constructor(private http: HttpClient, private helperService: HelperService) {
    this.dealsUrl = helperService.getBaseUrl() + "/deals/";
  }

  getDealInformation(dealId: string): any {
    let dealInfoUrl = this.dealsUrl + dealId + "/deal-information?includeBAC=true";
    return this.getRequest(dealInfoUrl);
  }

  getRagRating(dealId: string): any {
    let ragRatingsUrl = this.dealsUrl + dealId + "/rag-ratings";
    return this.getRequest(ragRatingsUrl);
  }

  getDealAssignments(dealId: string): any {
    let dealAssignmentsUrl = this.dealsUrl + dealId + "/deal-assignments";
    return this.getRequest(dealAssignmentsUrl);
  }

  getFormData(dataSourceEndpoint: string): any {
    return this.getRequest(this.dealsUrl + dataSourceEndpoint);
  }

  postForm(dealId: string, navigationEndPoint: string, reqBody: any): any {
    let formDataUrl;
    if (dealId != null) {
      formDataUrl = this.dealsUrl + dealId + "/" + navigationEndPoint;
    } else {
      formDataUrl = this.dealsUrl + navigationEndPoint;
    }
    return this.http.post(formDataUrl, reqBody);
  }

  getBillingAdminManager(dealId: string, groupId: number): any {
    let adminManagerUrl = this.dealsUrl + dealId + "/groups/" + groupId + "/billing-team-users";
    return this.getRequest(adminManagerUrl);
  }

  getLegalEntities(dealId: string): any {
    let legalEntitiesUrl = this.dealsUrl + dealId + "/legal-entities";
    return this.getRequest(legalEntitiesUrl);
  }

  getPartiesRoles(dealId: string, partyId: number): any {
    let partiesRolesUrl = this.dealsUrl + dealId + "/parties/" + partyId + "/roles";
    return this.getRequest(partiesRolesUrl);
  }

  getBillingContacts(dealId: string, billingRequestId: number, partyId: number) {
    let billingContactsUrl = this.dealsUrl + dealId + "/billing-requests/" + billingRequestId + "/party/" + partyId + "/billing-contacts";
    return this.getRequest(billingContactsUrl);
  }

  getDocument(fileId: string) {
    let documentUrl = this.dealsUrl + "document/download/" + fileId;
    return this.getRequest(documentUrl);
  }

  getBillingKeyComponentDetails(dealId: string, billingKey: string) {
    let billingKeyUrl = this.dealsUrl + dealId + "/billing-accounts/" + billingKey + "/billing-account-details";
    return this.getRequest(billingKeyUrl);
  }

  getBillingKeyInvoiceDetails(dealId: string, billingKey: string) {
    let billingInvoiceUrl = this.dealsUrl + dealId + "/billing-accounts/" + billingKey + "/billing-invoices";
    return this.getRequest(billingInvoiceUrl);
  }

  getVariables(processInstanceId: string) {
    let variablesUrl = this.dealsUrl + "runtime/process-instances/" + processInstanceId + "/variables";
    return this.getRequest(variablesUrl);
  }

  getBillingLegalEntities(dealId: string, isSpecialBilling: string): any {
    let legalEntitiesUrl = this.dealsUrl + dealId + "/billing-legal-entities";
    if (isSpecialBilling) {
      legalEntitiesUrl = legalEntitiesUrl + "?isSpecialBilling=" + isSpecialBilling;
    }
    return this.getRequest(legalEntitiesUrl);
  }

  getBillingRoles(dealId: string, partyId: number, isSpecialBilling: string): any {
    let legalEntitiesUrl = this.dealsUrl + dealId + "/parties/" + partyId + "/billing-roles";
    if (isSpecialBilling) {
      legalEntitiesUrl = legalEntitiesUrl + "?specialBillingIndicator=" + isSpecialBilling;
    }
    return this.getRequest(legalEntitiesUrl);
  }

  checkLock(dealId: string, taskId: string) {
    let checkLockUrl = this.dealsUrl + "check-lock";
    let reqBody: any = {};
    reqBody["dealId"] = dealId;
    reqBody["taskId"] = taskId;
    reqBody["lockType"] = "task";
    reqBody["lockAction"] = "check";
    return this.http.post(checkLockUrl, reqBody);
  }

  acquireLock(dealId: string, taskId: string) {
    let acquireLockUrl = this.dealsUrl + "acquire-lock";
    let reqBody: any = {};
    reqBody["dealId"] = dealId;
    reqBody["taskId"] = taskId;
    reqBody["lockType"] = "task";
    reqBody["lockAction"] = "lock";
    return this.http.post(acquireLockUrl, reqBody);
  }

  releaseLock(dealId: string, taskId: string) {
    let releaseLockUrl = this.dealsUrl + "release-lock";
    let reqBody: any = {};
    reqBody["dealId"] = dealId;
    reqBody["taskId"] = taskId;
    reqBody["lockType"] = "task";
    reqBody["lockAction"] = "unlock";
    return this.http.post(releaseLockUrl, reqBody);
  }

  getRequest(url: string): any {
    return this.http.get(url).pipe(
      catchError((err: HttpErrorResponse) => {
        return of({});
      }))
  }


}