import { Injectable } from '@angular/core';
import { ErrorState } from '../models/error-state';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ErrorService {

  private errorSubject = new Subject<ErrorState>();
  errorState = this.errorSubject.asObservable();
  constructor() { }

  show(errorObject:any) {
    this.errorSubject.next(<ErrorState>{ show: true,errorObject:errorObject});
  }
  hide() {
    this.errorSubject.next(<ErrorState>{ show: false });
  }
}
