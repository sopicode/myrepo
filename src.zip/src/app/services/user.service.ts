import { Injectable } from '@angular/core';
import { HttpClient,HttpErrorResponse } from '@angular/common/http';
import { of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { HelperService } from './helper.service';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  private profileUrl: string;

  constructor(private http: HttpClient, private helperService: HelperService) { 
    this.profileUrl = helperService.getBaseUrl() + "/profiles/me";
  }

  getProfileInformation(): any {
    return this.getRequest(this.profileUrl);
  }

  getRequest(url: string): any {
    return this.http.get(url).pipe(
      catchError((err: HttpErrorResponse) => {
        return of({});
      }))
  }


}