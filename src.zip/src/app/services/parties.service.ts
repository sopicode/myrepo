import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { HelperService } from './helper.service';

@Injectable({
  providedIn: 'root'
})
export class PartiesService {

  private partiesUrl: string;

  constructor(private http: HttpClient, private helperService: HelperService) {
    this.partiesUrl = helperService.getBaseUrl() + "/parties/";
  }

  getSMUsers(): any {
    let smUsersUrl = this.partiesUrl + "user-roles/ROLE_SM/users";
    return this.getRequest(smUsersUrl);
  }

  getSMAssignerUsers(): any {
    let smAssignerUsersUrl = this.partiesUrl + "user-roles/ROLE_SMA/users";
    return this.getRequest(smAssignerUsersUrl);
  }

  getDealRegionUrl(): any {
    let dealRegionUrl = this.partiesUrl + "user-regions";
    return this.getRequest(dealRegionUrl);
  }

  getIndividualContactDetails(contactId: number): any {
    let contactDetailUrl = this.partiesUrl + "individuals/" + contactId + "/contact-details";
    return this.getRequest(contactDetailUrl);
  }

  getUsersByGroupId(groupId:number):any {
    let usersByGroupIdUrl =  this.partiesUrl + "groups/" + groupId + "/user-details";
    return this.getRequest(usersByGroupIdUrl);
  }

  getListOfUsers(searchText:string): any {
    let userSearchUrl = this.partiesUrl+"search-users?isActive=true&limit=50&search="+searchText+"&sortBy=firstName&sortOrder=ASC";
    return this.getRequest(userSearchUrl);
  }

  getRequest(url: string): any {
    return this.http.get(url).pipe(
      catchError((err: HttpErrorResponse) => {
        return of({});
      }))
  }

  postForm(navigationEndPoint: string, reqBody: any): any {
    let formDataUrl = this.partiesUrl + navigationEndPoint;
    return this.http.post(formDataUrl, reqBody);
  }


}
