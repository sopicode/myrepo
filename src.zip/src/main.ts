import { enableProdMode, getPlatform, destroyPlatform } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { AppModule } from './app/app.module';
import { environment } from './environments/environment';

import 'inputmask/dist/jquery.inputmask.bundle'
import 'bignumber.js/bignumber'
import './styles.scss'

if (environment.production) {
  enableProdMode();
}

// to run billing ui independently (uncomment below line)
/*
platformBrowserDynamic([
  { provide: "task", useValue: { "id": "CT1802214", "taskName": "Confirm Billing Set Up Request", "taskId": "7185454","formKey":"billing-request-details","processInstanceId":"7185441"} },
  { provide: "unmountFunc", useValue: unmount }]).bootstrapModule(AppModule)
  .catch(err => console.log(err));
  
*/
const spaProps = {
  bootstrappedModule: null
};

export function bootstrap(props) {
  return Promise.resolve();
}

export function mount(props) {
  createDomElement();
  return platformBrowserDynamic([{ provide: "task", useValue: props }, { provide: "unmountFunc", useValue: unmount }])
    .bootstrapModule(AppModule).then(module => {
      return spaProps.bootstrappedModule = module;
    });
}

export function unmount(props) {
  return new Promise((resolve, reject) => {
    let win: any = window;
    delete win.getAngularTestability;
    delete win.getAllAngularTestabilities;
    delete win.getAllAngularRootElements;
    delete win.frameworkStabilizers;
    spaProps.bootstrappedModule.destroy();
    destroyPlatform();
    delete spaProps.bootstrappedModule;
    resolve();
    let el = window.document.getElementById('billing');
    if (el) {
      el.remove();
    }
    if (window.location.hash.indexOf('/dmg-ui') != -1 && !((window.location.hash.includes("&currentSection=fees-billing-overview", null)) || (window.location.hash.includes("&currentSection=transaction-fee-billing-overview", null)))) {
      win.location.reload();
    }
  });
}

export function invoke(functionName, data) {
  var loader = document.querySelector('.portal-loader');
  if (loader) {
    loader.classList.add('hide');
  }
  this.bootstrap().then(this.mount(data));
}

function createDomElement() {
  // Make sure there is a div for us to render into
  let el = window.document.getElementById('billing');
  let container = window.document.querySelector('portal-app-body');
  if (!container) {
    container = window.document.body;
  }
  if (el) {
    el.remove();
  }
  el = window.document.createElement('app-root');
  el.id = 'billing';
  el.className = 'billing';
  container.appendChild(el);

  return el;
}

